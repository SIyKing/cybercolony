// Offline support: pages are network-first (so updates arrive), everything else same-origin is
// cache-first (Vite file names are content-hashed, so a cached asset never goes stale).
// ponytail: the Google Fonts stylesheet is cross-origin and not cached; offline falls back to system fonts.
const CACHE = 'dustfall-v2';

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(['./', './manifest.webmanifest'])));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  const put = res => {
    if (res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
    return res;
  };
  e.respondWith(req.mode === 'navigate'
    ? fetch(req).then(put).catch(() => caches.match(req).then(r => r || caches.match('./')))
    : caches.match(req).then(r => r || fetch(req).then(put)));
});
