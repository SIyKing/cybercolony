# cybercolony

Dustfall Colony: an isometric colony sim on the Moon, Mars and further worlds, built as an iPhone-first web app (PWA).

```sh
npm install
npm run dev      # dev server, also on your LAN so you can open it on an iPhone
npm run build    # type-check + production build into dist/
npm run preview  # serve dist/ (service worker active)
npm test         # simulation unit tests (Vitest)
```

## Structure

Vite, TypeScript and Phaser 3, with the interface in plain HTML and CSS. Each folder only uses the ones above it in this list, and `src/main.ts` loads the modules in that order.

| Folder | What lives there |
|---|---|
| `src/sim/` | The game rules: economy, research, raids, campaign, quests, story, bank, contests, saves, worlds, lore (the words of each world). Typed, no DOM, unit-tested |
| `src/game/` | The running game: `env` (page, camera, toasts), `state` (what changes while playing, as `app`), `colony` (state wrappers, saving, the tick), `placing`, `start` (new or saved colony), `input` (touch and mouse), `boot` (frame loop) |
| `src/art/` | The hand-drawn Canvas 2D art: `kit` (look, palettes, materials), `buildings`, `ground`, `units` (drones, ships, rovers), `sky` (the planet over each world) |
| `src/render/` | `stage` (the Phaser stage) and `scene` (bakes the art into textures and draws each frame) |
| `src/ui/` | The HTML interface: `icons`, `hud`, `cast` (the story characters), `sheets` (build, info, research, battle, bank, contests), `avatar`, `dressing`, `menus` (story, colony menu, Solar System) |

The rules in `src/sim/` are fully typed. The modules in `src/game/`, `src/art/`, `src/render/scene.ts` and `src/ui/` came out of the original one-file game and still start with `@ts-nocheck`; they get real types one module at a time.
