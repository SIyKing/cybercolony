# Dustfall Colony: story outline

The game is split into chapters tied to colony levels. Characters speak in short dialogues at key
moments, and each goal says why it matters. Chapter 1 is in the game (`src/sim/story.ts` for the
dialogue, `why` in `src/sim/quests.ts` for the reasons). The later chapters are the plan.

## Characters

| Who | Role | Voice |
|---|---|---|
| **The Commander** | The player, shown with the player's own avatar | Says little and decides. |
| **Ines Okoro** | Chief engineer | Dry and practical. Gives the bad news first. |
| **Tavi Rao** | Hacker crew lead; later runs the Hacker Center contests | Quick and curious. Trusts nothing with a signal. |
| **Warlord Kesh** | Rival warlord of the Tharsis Rim, boss of sector 8 | Treats the planet as private property. |

Later chapters also use the bosses already in the campaign: Warlord Varn (Valles Deep, sector 16),
Overlord Saro (Hellas Basin, sector 24) and Admiral Vex (Martian Orbit, sector 32).

## Chapters

### Chapter 1: Landing (levels 1–3), in the game
Survive and find water. The ship is lost in a storm. Ines digs for ice, then replaces the cracked
greenhouse. Tavi spots drones on the scope, and the crew builds its first gun. After the first raid
the wrecks show no markings, so the colony builds a fleet to go looking. At level 3 Tavi traces the
drones to the Tharsis Rim, and Warlord Kesh demands tribute.

### Chapter 2: The raiders (levels 4–6)
Who sends the drones? Kesh is the obvious answer, but beating Kesh (sector 8) does not stop them.
Tavi finds that Kesh was buying drones from someone in Valles Deep.

### Chapter 3: The warlords (levels 7–10)
The warlords of Tharsis, Valles and Hellas, tied to the campaign sectors. Varn and Saro fall in
turn, and the planet is free. The drones still come, and their signal now starts in orbit.

### Chapter 4: Beyond Mars (levels 11–20)
Ties in #19 and the level lines that already exist in `STORY`: the shield, the first rain, the
spaceport, the orbital ring, and the last fight with Admiral Vex over Deimos.
