import { defineConfig } from 'vite';

// Relative base so the build works from any path (GitHub Pages, a subfolder, a file share).
export default defineConfig({ base: './' });
