// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** Resource icons (inline SVG) */
import { app } from '../game/state';
import { fmt } from '../game/env';

/* ---------- icons ---------- */
export const ICON={
 metal:'<svg viewBox="0 0 24 24"><path d="M12 2l8.5 5v10L12 22l-8.5-5V7z" fill="#b8c2cc" stroke="#6f7a86" stroke-width="1.5"/><circle cx="12" cy="12" r="3.5" fill="#5b6570"/></svg>',
 water:'<svg viewBox="0 0 24 24"><path d="M12 2.5C12 2.5 5 10.5 5 15a7 7 0 0014 0c0-4.5-7-12.5-7-12.5z" fill="#4fb4ff" stroke="#1f6fb5" stroke-width="1.5"/><path d="M9 15a3 3 0 003 3" stroke="#d9f0ff" stroke-width="1.6" fill="none" stroke-linecap="round"/></svg>',
 food:'<svg viewBox="0 0 24 24"><path d="M5 19C5 9 11 4 20 4c0 9-5 15-15 15z" fill="#6fd17a" stroke="#2d8a3e" stroke-width="1.5"/><path d="M5 19L14 10" stroke="#2d8a3e" stroke-width="1.6"/></svg>',
 crystal:'<svg viewBox="0 0 24 24"><path d="M12 2l6 6-6 14-6-14z" fill="#ff7ad9" stroke="#b02f8f" stroke-width="1.5"/><path d="M6 8h12M12 2v20" stroke="#ffd1f1" stroke-width="1"/></svg>',
 credit:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5" fill="#ffd34a" stroke="#b58300" stroke-width="1.5"/><path d="M15.5 8.5a5 5 0 100 7" stroke="#8a5d00" stroke-width="2" fill="none" stroke-linecap="round"/></svg>',
 energy:'<svg viewBox="0 0 24 24"><path d="M13 2L4 14h7l-1 8 9-12h-7z" fill="#ffd34a" stroke="#b58300" stroke-width="1.5" stroke-linejoin="round"/></svg>',
 pop:'<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4" fill="#ffc94a" stroke="#b58300" stroke-width="1.5"/><path d="M4 21c0-4.5 3.6-7 8-7s8 2.5 8 7z" fill="#e8eef2" stroke="#8d99a3" stroke-width="1.5"/></svg>',
};
export function costHTML(c){return'<span class="cost">'+Object.keys(c).filter(k=>c[k]>0).map(k=>`<span class="${app.S.res[k]<c[k]?'short':''}">${ICON[k]}${fmt(c[k])}</span>`).join('')+'</span>'}
