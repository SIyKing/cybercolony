/** Story character busts (#37): drawn SVG, 96 by 120, in the soft rose and lavender look. One recipe per character, three moods. */
import type { Mood } from '../sim/story';

interface Bust {
  skin: string; hair: string; style: 'puff' | 'undercut' | 'bald' | 'slick' | 'bun' | 'crop';
  suit: string; trim: string; extra: ('helmet' | 'headset' | 'visor' | 'armor' | 'scar' | 'earpiece' | 'tie' | 'beard')[];
}
const BUSTS: Record<string, Bust> = {
  eng: { skin: '#8a5a3c', hair: '#2a1a14', style: 'puff', suit: '#eef2f8', trim: '#ff8fc8', extra: ['helmet'] },
  tavi: { skin: '#c99a74', hair: '#bba8ff', style: 'undercut', suit: '#3a2448', trim: '#bba8ff', extra: ['headset', 'visor'] },
  kesh: { skin: '#b8846a', hair: '#1a1210', style: 'bald', suit: '#2a2230', trim: '#ff3b4e', extra: ['armor', 'scar', 'beard'] },
  kade: { skin: '#f0cdb4', hair: '#d8d0c8', style: 'slick', suit: '#24242e', trim: '#ff3b4e', extra: ['tie', 'earpiece'] },
  chief: { skin: '#f2d2bc', hair: '#e8b06a', style: 'bun', suit: '#dfe6f2', trim: '#7fb0ff', extra: ['helmet'] },
  ctrl: { skin: '#5e3c2a', hair: '#141010', style: 'crop', suit: '#f6eef8', trim: '#ffd2a6', extra: ['headset'] },
};

/** brows (how far the inner and the outer end drop) and the mouth per mood */
const FACE: Record<Mood, { brow: [number, number]; mouth: string }> = {
  calm: { brow: [0, 0], mouth: 'M42 70 Q48 74 54 70' },
  worried: { brow: [-3, 1], mouth: 'M42 72 Q48 69 54 72' },
  angry: { brow: [3, -1], mouth: 'M41 72 L55 71' },
};

export function bustSVG(id: string, mood: Mood = 'calm'): string {
  const b = BUSTS[id] || BUSTS.eng, f = FACE[mood], has = (x: Bust['extra'][number]) => b.extra.includes(x);
  const hairBack = { puff: '<circle cx="48" cy="34" r="20"/><circle cx="48" cy="52" r="21"/>', undercut: '', bald: '', slick: '', bun: '<circle cx="48" cy="26" r="9"/><ellipse cx="48" cy="50" rx="21" ry="22"/>', crop: '' }[b.style];
  const hairTop = {
    puff: '<path d="M29 50 Q30 30 48 30 Q66 30 67 50 Q60 38 48 38 Q36 38 29 50Z"/>',
    undercut: '<path d="M30 50 Q28 30 50 29 Q70 30 66 44 Q56 34 40 42 Q34 46 30 50Z"/><path d="M30 50 L30 44" stroke-width="2"/>',
    bald: '<path d="M30 46 Q32 31 48 31 Q64 31 66 46 Q58 36 48 36 Q38 36 30 46Z" opacity=".25"/>',
    slick: '<path d="M30 48 Q30 30 48 30 Q66 30 66 48 Q64 38 54 36 Q42 34 34 40 Q31 44 30 48Z"/>',
    bun: '<path d="M29 52 Q29 31 48 31 Q67 31 67 52 Q62 38 48 37 Q36 38 29 52Z"/>',
    crop: '<path d="M30 46 Q31 30 48 30 Q65 30 66 46 Q60 35 48 35 Q36 35 30 46Z"/>',
  }[b.style];
  const eye = (x: number) => `<ellipse cx="${x}" cy="57" rx="3.2" ry="${mood === 'angry' ? 1.9 : 2.6}" fill="#2a1830"/><circle cx="${x + 1}" cy="56" r=".9" fill="#fff"/>`;
  const [inn, out] = f.brow, brows = `<path d="M36 ${51 + out} L46 ${51 + inn}"/><path d="M50 ${51 + inn} L60 ${51 + out}"/>`;
  let s = `<svg viewBox="6 10 84 105" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">`;
  s += `<g fill="${b.hair}">${hairBack}</g>`;
  // shoulders and suit, shoulder stripes in the trim colour
  s += `<path d="M8 120 Q10 94 32 88 L64 88 Q86 94 88 120Z" fill="${b.suit}"/>`;
  s += `<path d="M14 100 Q22 92 32 90" stroke="${b.trim}" stroke-width="3" fill="none"/><path d="M82 100 Q74 92 64 90" stroke="${b.trim}" stroke-width="3" fill="none"/>`;
  s += `<path d="M38 88 L48 100 L58 88" fill="none" stroke="rgba(0,0,0,.25)" stroke-width="1.5"/>`;
  if (has('tie')) s += `<path d="M44 88 L48 92 L52 88 L50 108 L48 112 L46 108Z" fill="${b.trim}"/><path d="M38 88 L46 104 L44 88Z M58 88 L50 104 L52 88Z" fill="#fff" opacity=".85"/>`;
  if (has('armor')) s += `<path d="M6 108 Q8 90 30 88 L32 100 Q18 100 6 108Z M90 108 Q88 90 66 88 L64 100 Q78 100 90 108Z" fill="#3e3446"/><circle cx="20" cy="97" r="2" fill="${b.trim}"/><circle cx="76" cy="97" r="2" fill="${b.trim}"/><rect x="42" y="102" width="12" height="3" rx="1.5" fill="${b.trim}"/>`;
  // neck, head, ears
  s += `<rect x="41" y="70" width="14" height="20" rx="5" fill="${b.skin}"/><rect x="41" y="80" width="14" height="6" fill="rgba(0,0,0,.15)"/>`;
  s += `<ellipse cx="30" cy="58" rx="3" ry="5" fill="${b.skin}"/><ellipse cx="66" cy="58" rx="3" ry="5" fill="${b.skin}"/>`;
  s += `<ellipse cx="48" cy="55" rx="18" ry="22" fill="${b.skin}"/>`;
  if (has('beard')) s += `<path d="M31 60 Q33 78 48 79 Q63 78 65 60 Q60 70 48 70 Q36 70 31 60Z" fill="${b.hair}" opacity=".55"/>`;
  s += `<g fill="${b.hair}">${hairTop}</g>`;
  if (b.style === 'undercut') s += `<path d="M64 40 Q67 46 66 54" stroke="${b.hair}" stroke-width="1" opacity=".4" fill="none"/>`;
  // face: cheeks, eyes, brows, nose, mouth
  s += `<ellipse cx="38" cy="64" rx="4" ry="2.4" fill="#ff8fc8" opacity=".28"/><ellipse cx="58" cy="64" rx="4" ry="2.4" fill="#ff8fc8" opacity=".28"/>`;
  s += eye(41) + eye(55);
  s += `<g stroke="${b.hair === '#bba8ff' ? '#6a4a9a' : b.hair}" stroke-width="2" stroke-linecap="round" fill="none">${brows}</g>`;
  s += `<path d="M48 58 Q46 64 48 65" stroke="rgba(0,0,0,.25)" stroke-width="1.2" fill="none"/>`;
  s += `<path d="${f.mouth}" stroke="#7a3048" stroke-width="2" stroke-linecap="round" fill="none"/>`;
  if (has('scar')) s += `<path d="M58 46 L62 58" stroke="#7a3a34" stroke-width="1.4"/>`;
  if (has('visor')) s += `<rect x="32" y="52" width="32" height="9" rx="4.5" fill="#bba8ff" opacity=".45" stroke="#e6dcff" stroke-width=".8"/>`;
  if (has('headset')) s += `<path d="M29 56 Q29 30 48 30 Q67 30 67 56" stroke="#2a2030" stroke-width="2.4" fill="none"/><rect x="25" y="52" width="6" height="11" rx="3" fill="#2a2030"/><path d="M28 62 Q32 72 40 71" stroke="#2a2030" stroke-width="1.6" fill="none"/><circle cx="40" cy="71" r="1.8" fill="${b.trim}"/>`;
  if (has('earpiece')) s += `<circle cx="66" cy="58" r="1.8" fill="#ff3b4e"/><path d="M66 60 Q68 70 64 80" stroke="#c8c0c8" stroke-width=".8" fill="none"/>`;
  // the helmet under the arm: a white dome with a rose visor, bottom left
  if (has('helmet')) s += `<circle cx="20" cy="106" r="16" fill="#f6f8fc" stroke="#c8d0e0" stroke-width="1"/><path d="M8 104 Q20 94 32 104 Q20 112 8 104Z" fill="${b.trim}" opacity=".8"/><path d="M12 101 Q16 98 20 98" stroke="#fff" stroke-width="1.5" fill="none"/>`;
  return s + '</svg>';
}
