// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** HUD: resource bar, status strip, goal */
import { RES, TECH } from '../sim/defs';
import * as Bk from '../sim/bank';
import { costText } from '../sim/step';
import { app } from '../game/state';
import { $, fmt, toast } from '../game/env';
import { ICON } from './icons';
import { QUESTS, caps, dayInfo, has, hq, labB, labSpeed, stormLeft, stormSun, techCount } from '../game/colony';
import { advice } from './sheets';

/* ---------- UI: resources ---------- */
const resEl=$('res');
const CH=['metal','water','food','crystal','energy','pop','credit'];
resEl.innerHTML=CH.map(k=>`<div class="chip" id="c-${k}">${ICON[k]}<div class="v"><b>0</b><i>&nbsp;</i></div></div>`).join('')+'<button id="hudX" aria-label="Show all resources"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg></button>';
/* the resource row and the goal card remember how you left them, per device, like battery saver */
const HUD_KEY='dustfall-hud',GOAL_KEY='dustfall-goal-hide';app.hudOpen=false;app.goalHide=-1;try{app.hudOpen=localStorage.getItem(HUD_KEY)==='1';app.goalHide=+(localStorage.getItem(GOAL_KEY)??-1)}catch(e){}
function setHud(on){app.hudOpen=on;resEl.classList.toggle('open',on);const x=$('hudX');x.setAttribute('aria-expanded',on);x.setAttribute('aria-label',on?'Show fewer resources':'Show all resources');try{localStorage.setItem(HUD_KEY,on?'1':'0')}catch(e){}}
export function hideGoal(q){app.goalHide=q;try{localStorage.setItem(GOAL_KEY,q)}catch(e){}updUI()}
setHud(app.hudOpen);$('hudX').onclick=()=>setHud(!app.hudOpen);
$('storm').onclick=()=>toast('Dust storm: solar arrays give '+Math.round(stormSun()*100)+'% power until it passes'+(stormSun()<.7?'. Research Self-Cleaning Panels to keep 70%':''));
const chipEls={};const CHIPHELP={metal:'Metal: build Metal Extractors. Used for almost every building.',water:'Water: build Water Extractors. Colonists drink it every minute.',food:'Food: build Greenhouses. Colonists need it to keep working.',crystal:'Crystals: put a Crystal Drill on a pink deposit. Shooting down drones also drops crystals.',credit:'Credits: colonists pay taxes once you build a Bank. Spend them to finish building and research early, on clothes, on contest fees and on the biggest buildings.',energy:'Power: Solar Arrays and Reactors make it, most buildings use it. Below zero, everything runs slow.',pop:'Colonists: Habitats house them. Jobs shows how many workers your buildings need.'};
for(const k of CH){const el=$('c-'+k);chipEls[k]={el,b:el.querySelector('b'),i:el.querySelector('i')};el.setAttribute('role','button');el.tabIndex=0;el.onclick=()=>toast(CHIPHELP[k])}
function badge(el,on,why,na){el.classList.toggle('dot',on);el.classList.toggle('na',na);el.setAttribute('aria-label',el.textContent.trim()+(on?': '+why:na?': not built yet':''))}
export function updUI(){
  const c=caps();
  for(const k of RES){const r=app.S.rate[k]||0;chipEls[k].b.textContent=fmt(app.S.res[k]);
    const i=chipEls[k].i;i.textContent=(r>=0?'+':'')+(Math.abs(r)<10?r.toFixed(1):Math.round(r))+'/s · '+fmt(c[k]);i.className=r<-.01?'neg':r>.01?'pos':'';chipEls[k].el.classList.toggle('low',r<-.01)}
  {const r=Bk.taxIncome(app.S);chipEls.credit.b.textContent=fmt(app.S.res.credit);chipEls.credit.i.textContent=(Bk.bankLvl(app.S)?'+'+(r<10?r.toFixed(1):Math.round(r))+'/min':'no Bank')+(app.S.bank.saved>=1?' · '+fmt(app.S.bank.saved)+' saved':'');chipEls.credit.i.className=r>0?'pos':''}
  chipEls.energy.b.textContent=Math.round(app.S.eP||0)+' / '+Math.round(app.S.eU||0);
  chipEls.energy.i.textContent=(app.S.fe<1?'low power':'power ok');chipEls.energy.i.className=app.S.fe<1?'neg':'pos';
  chipEls.pop.b.textContent=app.S.pop+(app.hudOpen?' / '+(app.S.cap||0):'');$('hudX').classList.toggle('warn',app.S.fe<1);
  chipEls.pop.i.textContent=(app.S.work||0)+((app.S.work||0)===1?' job':' jobs');chipEls.pop.i.className=app.S.fw<1?'neg':'';
  {$('lvlB').textContent='Lv '+hq().lvl;$('lvlI').textContent='☀ Sol '+dayInfo().sol}
  {const s=Math.ceil(stormLeft()),el=$('storm');el.hidden=!s;if(s)el.textContent='Dust storm '+Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}
  $('top').classList.toggle('bad',advice().some(x=>x.bad));
  const q=QUESTS[app.S.quest];$('goalT').textContent=q?q.t:'All goals done. Keep growing!';$('goalR').textContent=q?'+'+costText(q.r):'';$('goalW').textContent=q&&q.why||'';
  $('goalC').hidden=app.goalHide===app.S.quest;$('goalMin').hidden=app.goalHide!==app.S.quest;
  $('toast').style.top=$('top').getBoundingClientRect().bottom+6+'px';
  badge($('resB'),labSpeed()>0&&!app.S.rs&&techCount()<TECH.length,'the lab is idle',!labB());
  badge($('battleB'),has('hangar')&&app.S.cool<=0&&!app.mission,'the fleet is ready',!has('hangar'));
  {const on=app.S.quest===0&&!app.S.b.some(b=>b.type==='extractor')&&!app.sheetMode&&$('talk').hidden&&$('intro').hidden;$('coach').hidden=!on;$('buildB').classList.toggle('pulse',on)}
  const r=$('raid');
  if(app.S.raidOn){r.className='on';r.textContent='Raid! '+app.drones.length+' drones'}
  else if(app.S.b.length<5){r.className='';r.textContent='Skies quiet'}
  else{const s=Math.ceil(app.S.raidT);r.className=s<=30?'warn':'';r.textContent='Raid in '+Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}
}app.sheetMode=null;
