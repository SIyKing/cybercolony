/** Avatar: one of the portraits in public/assets/portraits */
import { app } from '../game/state';
import { $ } from '../game/env';

export interface Av { g: 'f' | 'm'; face: number }
const PF = Array.from({ length: 6 }, (_, i) => `${import.meta.env.BASE_URL}assets/portraits/p${String(i).padStart(2, '0')}.jpg`);
export const FACES = { f: [0, 1, 2], m: [3, 4, 5] };
/** old saves can hold a face index from the bigger drawn set */
export const faceOf = (av: Av) => av.face % FACES[av.g].length;
export const avatarSVG = (av: Av) => `<img src="${PF[FACES[av.g][faceOf(av)]]}" alt="">`;
export function updAvatarBtn() { const b = $('avB'); if (b) b.innerHTML = avatarSVG(app.S.av) }
