// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** Avatar picker and story log */
import * as Story from '../sim/story';
import { app } from '../game/state';
import { $, closeSheet, sheet } from '../game/env';
import { save } from '../game/colony';
import { FACES, avatarSVG, faceOf, updAvatarBtn } from './avatar';

export function openDress(){
  closeSheet();$('dress').hidden=false;$('bar').hidden=true;renderDress();
  setTimeout(()=>{const b=$('dress').querySelector('.dr-face.on');if(b)b.focus({preventScroll:true})},30);
}
export function closeDress(){$('dress').hidden=true;$('bar').hidden=!!(app.placing||app.editMode);updAvatarBtn()}
function renderDress(){
  const av=app.S.av,el=$('dress'),cur=faceOf(av);
  el.innerHTML=`<div class="dr-wrap">
    <header class="dr-head"><h2 id="drTitle">Your avatar</h2><button class="dr-x" id="drClose" aria-label="Close">✕</button></header>
    <div class="dr-body">
      <figure class="dr-mirror"><div class="dr-glass">${avatarSVG(av)}</div><figcaption><b>Commander</b></figcaption></figure>
      <section class="dr-wardrobe" aria-label="Avatar"><div class="dr-scroll">
        <div class="dr-seg" role="group" aria-label="Avatar">${[['f','Female'],['m','Male']].map(([g,n])=>`<button data-g="${g}" class="${av.g===g?'on':''}" aria-pressed="${av.g===g}">${n}</button>`).join('')}</div>
        <h3 class="dr-sub">Face</h3><div class="dr-grid faces">${FACES[av.g].map((_,i)=>`<button class="dr-face${cur===i?' on':''}" data-face="${i}" aria-label="Face ${i+1}" aria-pressed="${cur===i}">${avatarSVG({g:av.g,face:i})}</button>`).join('')}</div>
      </div></section>
    </div></div>`;
  $('drClose').onclick=closeDress;
  el.querySelectorAll('[data-g]').forEach(b=>b.onclick=()=>{av.g=b.dataset.g;av.face=faceOf(av);save();updAvatarBtn();renderDress()});
  el.querySelectorAll('[data-face]').forEach(b=>b.onclick=()=>{av.face=+b.dataset.face;save();updAvatarBtn();renderDress()});
}
export function openLog(){
  app.sheetMode='log';app.selected=null;const seen=Story.BEATS.slice(0,app.S.beat);
  sheet.innerHTML=`<div class="sh-head"><h3>Story log</h3><button class="x" aria-label="Close">✕</button></div>`+(seen.map(b=>`<h4 class="sec">${b.chapter||b.title}</h4>`+b.lines.map(([k,t])=>{const c=Story.CAST[k];return`<p class="lg"><b style="color:${c.col}">${c.name}:</b> ${t}</p>`}).join('')).join('')||'<p class="muted">Nothing here yet.</p>');
  sheet.querySelector('.x').onclick=closeSheet;sheet.scrollTop=0;
}
