// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** Story dialogue, colony menu, Solar System */
import * as Story from '../sim/story';
import { MAXL, N, RANKS, RES, RNAME, SECT_N } from '../sim/defs';
import * as Save from '../sim/save';
import * as W from '../sim/worlds';
import * as Cargo from '../sim/cargo';
import { app } from '../game/state';
import { $, SAVER_KEY, centerOn, closeSheet, fmt, fmtT, sheet, toast } from '../game/env';
import { WORLD, dayInfo, defaultAv, hq, save } from '../game/colony';
import { goWorld } from '../art/kit';
import { setEdit } from '../game/placing';
import { avatarSVG, updAvatarBtn } from './avatar';
import { bustSVG } from './cast';
import { closeDress, openDress, openLog } from './dressing';
import { openBattle, openBuild, openContest, openGoal, openInfo, openResearch, sheetSig } from './sheets';
import { hideGoal } from './hud';
import { fresh } from '../game/start';

/* ---------- story dialogue: the colony waits while people talk, and they wait for the last toast, so a reward is seen first ---------- */
app.talkB=null;app.talkI=0;
function showLine(){const[k,t,m]=app.talkB.lines[app.talkI],c=Story.CAST[k],P=$('talkP');
  // the comm screen: a drawn bust (the commander is the player's avatar), and the speaker's signal effect restarts with each line
  P.innerHTML=c.bust?bustSVG(c.bust,m||c.mood):avatarSVG(app.S.av);P.dataset.fx=c.fx;P.classList.remove('on');void P.offsetWidth;P.classList.add('on');$('talkN').textContent=c.name;$('talkN').style.color=c.col;$('talkR').textContent=c.role;$('talkT').textContent=t;
  $('talkG').textContent=app.talkI<app.talkB.lines.length-1?'Next':'Continue'}
function playBeat(b){app.talkB=b;app.talkI=0;$('talkC').textContent=b.chapter||b.title;$('talk').hidden=false;showLine();$('talkG').focus()}
export function endTalk(){app.S.beat++;app.talkB=null;$('talk').hidden=true;save()}
$('talkG').onclick=()=>{if(!app.talkB)return;if(++app.talkI<app.talkB.lines.length)showLine();else endTalk()};
$('talkS').onclick=()=>{if(app.talkB)endTalk()};
export function nextBeat(){
  // draw the commander once ahead of time, so the photo is loaded before anyone talks
  if(!app.talkPre&&app.S){app.talkPre=1;$('talkP').innerHTML=avatarSVG(app.S.av)}
  if(app.toastT<=0&&$('talk').hidden&&$('intro').hidden&&$('dress').hidden&&!app.S.raidOn&&!app.sheetMode&&!app.placing&&!app.movingB&&!app.editMode){const b=Story.dueBeat(app.S);if(b)playBeat(b)}}
function openMenu(){
  app.sheetMode='menu';app.selected=null;
  sheet.innerHTML=`<div class="sh-head"><h3>Colony</h3><button class="x" aria-label="Close">✕</button></div>
  <p class="muted">${RANKS[hq().lvl-1]} (colony level ${hq().lvl} of ${MAXL}) · Sol ${dayInfo().sol} · sectors conquered ${app.S.stage||0} of ${SECT_N} · raids beaten ${app.S.raids} · battles won ${app.S.wins}. Your colony saves on this device.</p>
  <div class="btns"><button class="b2 gold" id="sysB">Solar System</button><button class="b2 ghost" id="logB">Story log</button><button class="b2 ghost" id="homeB">Center on base</button><button class="b2 red" id="resetB">Start a new colony</button></div>
  <div class="btns"><button class="b2 ghost" id="saverB" aria-pressed="${app.saver}">Battery saver: ${app.saver?'on':'off'}</button></div>
  <p class="muted">Battery saver keeps the game at 30 frames a second and turns off dust devils, smoke and sparks.</p>
  <p class="muted">Moving to another browser, or to the home-screen app (it has its own storage on iPhone)? Copy your save code here and load it there.</p>
  <div class="btns"><button class="b2 ghost" id="expB">Copy save code</button><button class="b2 ghost" id="impB">Load a save code</button></div>
  <div id="impBox" hidden><textarea id="impT" rows="4" spellcheck="false" autocomplete="off" aria-label="Save code" placeholder="Paste a save code"></textarea>
  <div class="btns"><button class="b2" id="impGo">Load this colony</button></div></div>`;
  sheet.querySelector('.x').onclick=closeSheet;
  $('expB').onclick=()=>{save();const code=JSON.stringify(app.S);
    const show=()=>{$('impBox').hidden=false;$('impGo').hidden=true;$('impT').value=code;$('impT').select();toast('Copy the selected code')};
    if(navigator.clipboard)navigator.clipboard.writeText(code).then(()=>toast('Save code copied'),show);else show()};
  $('impB').onclick=()=>{$('impBox').hidden=false;$('impGo').hidden=false;$('impT').value='';$('impT').focus()};
  let impArmed=false;$('impGo').onclick=()=>{
    const r=Save.parseSave($('impT').value.trim(),defaultAv);if(!r){toast('That is not a Dustfall Colony save code');return}
    if(!impArmed){impArmed=true;$('impGo').textContent='Tap again: this replaces your colony';return}
    app.S=r.S;save();location.reload()};
  $('logB').onclick=openLog;$('sysB').onclick=openWorlds;
  $('homeB').onclick=()=>{centerOn(N/2,N/2);closeSheet()};
  $('saverB').onclick=e=>{app.saver=!app.saver;try{localStorage.setItem(SAVER_KEY,app.saver?'1':'0')}catch(x){}
    e.currentTarget.textContent='Battery saver: '+(app.saver?'on':'off');e.currentTarget.setAttribute('aria-pressed',app.saver)};
  let armed=false;$('resetB').onclick=()=>{if(!armed){armed=true;$('resetB').textContent='Tap again: this erases your colony';return}
    app.drones=[];app.fx=[];app.colonists=[];app.missiles=[];app.rovers=[];app.mission=null;app.contest=null;fresh();hideGoal(-1);updAvatarBtn();save();centerOn(N/2,N/2);closeSheet();toast('A new landing site')};
  sheet.classList.add('open');
}
/* ---------- Solar System: one colony per world; Moon and Mars are open, the rest open with colony levels ---------- */
export function worldCards(list,best){return list.map(w=>{const d=W.WORLDS[w],open=W.isOpen(w,best);
  return`<button class="world${w===WORLD?' here':''}" data-w="${w}"${open?'':' disabled'}><i class="disc" style="background:${d.disc}"></i><b>${d.name}</b><small>${open?d.blurb:'Opens when a colony reaches level '+d.unlock}</small><small class="perk">${d.perk}</small>${w===WORLD?'<em>You are here</em>':''}</button>`}).join('')}
export function wireWorlds(el){el.querySelectorAll('.world').forEach(b=>b.onclick=()=>goWorld(b.dataset.w))}
/* the map: the Sun at the left edge and the planets in a row, in a 100 x 44 box (x, y). Hosts are planets without a colony,
 * drawn for the look; colony worlds sit at their own spot or beside their host (dx, dy). s is the disc size in % of the long side */
const H=44,SUN=[-13,22],HOSTS={
  earth:{x:14,y:20,s:2.6,c:'earth'},jupiter:{x:41,y:22,s:10,c:'jupiter'},saturn:{x:54,y:22,s:7.5,c:'saturn'},
  uranus:{x:65.5,y:22,s:4.6,c:'uranus',n:'Uranus'},neptune:{x:74,y:22,s:4.6,c:'neptune',n:'Neptune'},
  pluto:{x:82,y:23.5,s:1.6,c:'pluto',n:'Pluto'},haumea:{x:87,y:20.5,s:1.5,c:'haumea',n:'Haumea'},
  makemake:{x:91.5,y:23.5,s:1.5,c:'makemake',n:'Makemake'},eris:{x:96,y:20.5,s:1.6,c:'eris',n:'Eris'}};
const SPOTS={moon:{host:'earth',dx:3,dy:-2.6,s:1.5},mars:{x:20.5,y:27,s:2.1},ceres:{x:29,y:16.5,s:1.6},
  europa:{host:'jupiter',dx:-4.5,dy:8.5,s:1.5},titan:{host:'saturn',dx:5.5,dy:7.5,s:1.8}};
const spotXY=w=>{const p=SPOTS[w];if(!p.host)return[p.x,p.y];const h=HOSTS[p.host];return[h.x+p.dx,h.y+p.dy]};
/* a phone held upright gets the map turned: the Sun at the top, the outer planets at the bottom. pos gives a spot in % of the map box */
let tall=false;
const pos=([x,y])=>tall?[y/H*100,x]:[x,y/H*100];
const at=(p,s)=>{const[l,t]=pos(p);return`left:${l}%;top:${t}%;--s:${s}`};
/* a belt of n rocks between radius r0 and r1 around the Sun, within span radians of the row; seeded, so it looks the same every time */
function belt(n,r0,r1,span,seed,hue){let q=seed;const rnd=()=>(q=q*16807%2147483647)/2147483647;let o='';
  for(let i=0;i<n;i++){const a=(rnd()-.5)*2*span,r=r0+(r1-r0)*(rnd()+rnd())/2,z=.04+rnd()**4*.3;
    o+=`<ellipse cx="${(SUN[0]+r*Math.cos(a)).toFixed(2)}" cy="${(SUN[1]+r*Math.sin(a)).toFixed(2)}" rx="${z.toFixed(2)}" ry="${(z*(.55+rnd()*.45)).toFixed(2)}" fill="hsl(${hue} 10% ${Math.round(30+rnd()*50)}%)"/>`}
  return o}
/* the Sun: a glow, a flame edge (a disc pushed around by noise), and a plasma surface (noise spots clipped to the disc) */
const[SX,SY]=SUN,SUN_SVG=`<defs><radialGradient id="ssGlow"><stop offset=".55" stop-color="#ff8a20" stop-opacity=".5"/><stop offset="1" stop-color="#ff5a00" stop-opacity="0"/></radialGradient>
  <radialGradient id="ssDisc" cx=".55" cy=".5" r=".55"><stop offset="0" stop-color="#fff2b8"/><stop offset=".45" stop-color="#ffb43a"/><stop offset=".8" stop-color="#f2600e"/><stop offset="1" stop-color="#b82e00"/></radialGradient>
  <filter id="ssFlame" x="-30%" y="-30%" width="160%" height="160%"><feTurbulence type="fractalNoise" baseFrequency=".45" numOctaves="3" seed="5"/><feDisplacementMap in="SourceGraphic" scale="3.2" xChannelSelector="R" yChannelSelector="G"/><feGaussianBlur stdDeviation=".25"/></filter>
  <filter id="ssPlasma" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".55" numOctaves="4" seed="9"/>
    <feColorMatrix values="0 0 0 0 .6  0 0 0 0 .1  0 0 0 0 0  3 0 0 0 -1.35"/><feComposite in2="SourceGraphic" operator="in"/></filter>
  <filter id="ssSpots" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="2"/>
    <feColorMatrix values="0 0 0 0 1  0 0 0 0 .82  0 0 0 0 .35  0 2.4 0 0 -1.35"/><feComposite in2="SourceGraphic" operator="in"/></filter></defs>
  <circle cx="${SX}" cy="${SY}" r="36" fill="url(#ssGlow)"/><circle cx="${SX}" cy="${SY}" r="22" fill="#ff7a14" opacity=".8" filter="url(#ssFlame)"/>
  <circle cx="${SX}" cy="${SY}" r="21" fill="url(#ssDisc)"/><circle cx="${SX}" cy="${SY}" r="21" filter="url(#ssPlasma)"/><circle cx="${SX}" cy="${SY}" r="21" filter="url(#ssSpots)"/>`;
const dist=([x,y])=>Math.hypot(x-SUN[0],y-SUN[1]);
const ART=`<circle class="ss-dust" cx="${SUN[0]}" cy="${SUN[1]}" r="41.5"/><circle class="ss-dust k" cx="${SUN[0]}" cy="${SUN[1]}" r="95"/>
  <g class="ss-orb">${[...Object.values(HOSTS).map(h=>[h.x,h.y]),spotXY('mars')].map(p=>`<circle cx="${SUN[0]}" cy="${SUN[1]}" r="${dist(p).toFixed(2)}"/>`).join('')}</g>
  ${belt(560,38.5,44.5,.75,7,30)}${belt(320,90,100,.3,11,220)}${SUN_SVG}`;
function solarMap(best){
  tall=innerHeight>innerWidth; // ponytail: picked when the screen opens; turning the phone with it open keeps the old layout
  const lv=w=>W.colonyLevel(lsGet,w);
  const hosts=Object.values(HOSTS).map(h=>`<i class="ss-host ${h.c}" style="${at([h.x,h.y],h.s)}">${h.n?`<span>${h.n}</span>`:''}</i>`).join('');
  const pls=W.WORLD_ORDER.map(w=>{const d=W.WORLDS[w],open=W.isOpen(w,best),l=lv(w);
    return`<button class="ss-pl${w===WORLD?' here':''}${open?'':' locked'}" data-w="${w}" style="${at(spotXY(w),SPOTS[w].s)};--bg:${d.disc}" aria-label="${d.name}${w===WORLD?', you are here':''}${open?'':', locked'}">
      <i class="d"></i><span>${d.name}${l?' <b>'+l+'</b>':''}</span></button>`}).join('');
  return`<div class="ss-wrap${tall?' tall':''}"><div class="ss-map"><svg viewBox="0 0 ${tall?H+' 100':'100 '+H}" aria-hidden="true">
    <g${tall?' transform="matrix(0 1 1 0 0 0)"':''}>${ART}</g></svg><i class="ss-hud"></i>
    <em class="ss-tag" style="${at(tall?[26,8]:[29,41],0)}">Asteroid belt</em><em class="ss-tag" style="${at(tall?[79,8]:[84,3],0)}">Kuiper belt</em>
    ${hosts}${pls}</div><div class="ss-info" aria-live="polite" hidden></div></div>`}
/* the card beside the tapped world: below it in the top half of the map, above it in the bottom half; w=null hides it */
function showWorld(w,best){
  const el=sheet.querySelector('.ss-info');
  sheet.querySelectorAll('.ss-pl').forEach(b=>b.setAttribute('aria-pressed',b.dataset.w===w));
  el.hidden=!w;if(!w)return;
  const d=W.WORLDS[w],open=W.isOpen(w,best),l=W.colonyLevel(lsGet,w);
  const st=w===WORLD?`You are here · colony level ${l||1}`:!open?'Opens when a colony reaches level '+d.unlock:l?'Your colony: level '+l:'No colony yet: land and start one';
  const btn=w===WORLD?'<button class="b2 ghost" id="ssGo">Back to the colony</button>':open?`<button class="b2 gold" id="ssGo">${l?'Fly to '+d.name:'Land on '+d.name}</button>`:'<button class="b2" disabled>Locked</button>';
  el.innerHTML=`<i class="d" style="--bg:${d.disc}"></i><div><b>${d.name}</b><small>${d.blurb}</small><small class="perk">${d.perk}</small><small class="st${open?'':' lock'}">${st}</small></div>${btn}`;
  const go=el.querySelector('#ssGo');if(go)go.onclick=()=>goWorld(w);
  const map=sheet.querySelector('.ss-map'),mw=map.offsetWidth,mh=map.offsetHeight,[x,y]=pos(spotXY(w)),px=x/100*mw,py=y/100*mh,r=SPOTS[w].s/200*Math.max(mw,mh)+24;
  const left=Math.max(0,Math.min(mw-el.offsetWidth,px-el.offsetWidth/2)),below=py<mh/2;
  el.classList.toggle('up',!below);el.style.left=left+'px';el.style.setProperty('--ax',(px-left)+'px');
  el.style.top=below?(py+r)+'px':'';el.style.bottom=below?'':(mh-py+r-20)+'px';
}
function openWorlds(){app.sheetMode='worlds';app.selected=null;
  let best=0;try{best=W.bestLevel(k=>localStorage.getItem(k))}catch(e){}
  sheet.innerHTML=`<div class="sh-head"><h3>Solar System</h3><button class="x" aria-label="Close">✕</button></div>
  <p class="muted">Every world is its own colony. Tap a world to see it; the others keep running while you are away.</p>
  ${solarMap(best)}${cargoHTML()}`;
  sheet.querySelector('.x').onclick=closeSheet;
  let sel=null;const pick=w=>{sel=w;showWorld(w,best)};
  sheet.querySelectorAll('.ss-pl').forEach(b=>b.onclick=e=>{e.stopPropagation();pick(sel===b.dataset.w?null:b.dataset.w)});
  sheet.querySelector('.ss-map').onclick=()=>pick(null);
  sheet.querySelectorAll('[data-send]').forEach(b=>b.onclick=()=>{const to=$('cgTo').value,r=b.dataset.send,n=Math.floor(Math.min(Cargo.hold(app.S.b),app.S.res[r]));
    const why=Cargo.send(app.S,WORLD,to,r,lsGet,lsSet);if(why){toast(why);return}save();toast('Frigate launched: '+fmt(n)+' '+RNAME[r]+' to '+W.WORLDS[to].name);openWorlds()});
  sheet.classList.add('open','space')}
/* ---------- cargo (#41): shipments in flight live beside the saves, so they land even when sent from another colony ---------- */
const lsGet=k=>{try{return localStorage.getItem(k)}catch(e){return null}},lsSet=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
function cargoHTML(){
  const h=Cargo.hold(app.S.b),l=Cargo.inFlight(lsGet).filter(x=>x.from===WORLD||x.to===WORLD),to=Cargo.ports(WORLD,lsGet),out=l.some(x=>x.from===WORLD);
  const fl=l.map(x=>`<p class="muted">${fmt(x.n)} ${RNAME[x.res]}: ${W.WORLDS[x.from].name} → ${W.WORLDS[x.to].name}, ${x.at>Date.now()?'lands in '+fmtT((x.at-Date.now())/1000):'landed, waiting for storage space'}</p>`).join('');
  let body;
  if(!h)body='<p class="muted">Build a Hangar or Spaceport to send cargo to your other colonies.</p>';
  else if(out)body='<p class="muted">The frigate is out. It can fly again once this load has landed.</p>';
  else if(!to.length)body='<p class="muted">None of your other colonies has a Hangar or Spaceport to land at yet.</p>';
  else body=`<label class="muted">To <select id="cgTo">${to.map(w=>`<option value="${w}">${W.WORLDS[w].name} (${fmtT(Cargo.tripSecs(WORLD,w))})</option>`).join('')}</select></label>
    <div class="bk-rows">${RES.map(k=>{const n=Math.floor(Math.min(h,app.S.res[k]));return`<div class="bk-row"><span class="bk-n">${RNAME[k]}</span><span></span><button class="b2" data-send="${k}"${n<1?' disabled':''}>Send ${fmt(n)}</button></div>`}).join('')}</div>`;
  return`<h4 class="sec">Cargo</h4><p class="muted">The frigate carries one load to another colony. Hold: ${fmt(h)} (200 per Hangar level, 1000 per Spaceport level). Close worlds are quick; Titan is far.</p>${body}${fl}`}
export function landCargo(){
  const got=Cargo.land(app.S,WORLD,lsGet,lsSet);if(!got.length)return;save();
  for(const x of got)toast('Cargo from '+W.WORLDS[x.from].name+' landed: +'+fmt(x.n)+' '+RNAME[x.res]);
}
// refresh the open sheet only when something it shows has changed, so taps aren't lost
app.lastSig='';
export function refreshSheet(){
  if(!app.sheetMode||app.sheetMode==='menu'||app.sheetMode==='worlds')return;
  if(app.sheetMode==='info'&&!(app.selected&&app.S.b.includes(app.selected))){closeSheet();return}
  const sig=sheetSig();if(sig===app.lastSig)return;app.lastSig=sig;
  if(app.sheetMode==='info'){const k=sheet.scrollTop;openInfo(app.selected);sheet.scrollTop=k}
  else if(app.sheetMode==='battle')openBattle();
  else if(app.sheetMode==='contest')openContest();
  else if(app.sheetMode==='research'){const k=sheet.scrollTop,rows=[...sheet.querySelectorAll('.techrow')].map(r=>r.scrollLeft);openResearch();sheet.scrollTop=k;sheet.querySelectorAll('.techrow').forEach((r,i)=>r.scrollLeft=rows[i]||0)}
  else if(app.sheetMode==='build'){const sc=sheet.querySelector('.cards');const l=sc?sc.scrollLeft:0;openBuild(app.buildFocus,true);const n=sheet.querySelector('.cards');if(n)n.scrollLeft=l}
}
$('buildB').onclick=()=>{app.sheetMode==='build'?closeSheet():openBuild(app.S.quest===0?'extractor':undefined)};
$('resB').onclick=()=>{app.sheetMode==='research'?closeSheet():openResearch()};
$('editB').onclick=()=>setEdit(!app.editMode);
$('battleB').onclick=()=>{app.sheetMode==='battle'?closeSheet():openBattle()};
$('menuB').onclick=openMenu;
$('goal').onclick=()=>{app.sheetMode==='goal'?closeSheet():openGoal()};
$('goalX').onclick=()=>hideGoal(app.S.quest);
$('goalMin').onclick=()=>hideGoal(-1);
addEventListener('pointerdown',e=>{if(e.target.closest&&e.target.closest('button'))navigator.vibrate?.(8)}); // no-op on iPhone, which has no web vibration: the press animation is the feedback there
$('avB').onclick=()=>{$('dress').hidden?openDress():closeDress()};app.toastT=0;
