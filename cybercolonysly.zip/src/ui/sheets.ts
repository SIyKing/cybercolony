// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** Sheets: goal help, build, building info, bank, battle, contests, research */
import * as R from '../sim/research';
import { BRANCHES, DEF, MAXL, ORDER, RANKS, RES, RNAME, SECTORS, SECT_N, STORY, TECH, TIER } from '../sim/defs';
import { costText } from '../sim/step';
import * as Bk from '../sim/bank';
import * as C from '../sim/campaign';
import * as E from '../sim/economy';
import * as K from '../sim/contest';
import { app } from '../game/state';
import { $, P, cam, closeSheet, fmt, fmtT, sheet, toast } from '../game/env';
import { ICON, costHTML } from './icons';
import { QUESTS, bCost, canPay, caps, fleetPower, has, hooks, hq, labB, labSpeed, launch, lootOf, maxHp, maxLvl, pay, repCost, save, sector, sparkle, techCount, techState, upCost } from '../game/colony';
import { HQSTYLES, HSTYLES, PICS, PSTYLES, hqStyle, upTime } from '../art/buildings';
import { THUMB } from '../render/scene';
import { startMove, startPlacing } from '../game/placing';

function startResearch(id){
  const T=R.startResearch(app.S,id);if(!T)return;
  if(T==='cost'){toast('Not enough resources for '+TECH.find(x=>x.id===id).name);return}
  toast('Research started: '+T.name);save();openResearch();
}

/* ---------- goal guide and colony advisor ---------- */
const BUILDN={'Ice Extractor':'extractor','Greenhouse':'greenhouse','Ore Mine':'mine','Defense Turret':'turret','Crystal Drill':'drill','Hangar':'hangar','Research Lab':'lab','Missile Battery':'missile','Fusion Reactor':'reactor','Railgun':'railgun','Space Elevator':'elevator','Shield Generator':'shieldgen','Terraforming Plant':'terraform','Spaceport':'spaceport','Orbital Ring':'ring','Solar Mirror':'mirror'};
function goalHelp(q){
  if(!q)return null;const t=q.t;
  for(const n in BUILDN)if(t.includes(n))return{txt:`Open Build and place ${/^[AEIOU]/.test(n)?'an':'a'} ${n}.`+(BUILDN[n]==='drill'?' It must sit on a pink crystal deposit.':''),btn:'Show me',run:()=>openBuild(BUILDN[n])};
  if(/colony level/.test(t))return{txt:'Tap the Command Center and upgrade it.',btn:'Open Command Center',run:()=>{const h=hq();app.selected=h;openInfo(h)}};
  if(/colonists/.test(t))return{txt:'Colonists move in when there is housing, food and water. Build Habitats and keep food and water rising.',btn:'Build a Habitat',run:()=>openBuild('habitat')};
  if(/raid/.test(t))return{txt:'Raids come on their own. The timer at the top shows when. Turrets shoot the drones down.',btn:'Build a Turret',run:()=>openBuild('turret')};
  if(/battle|sector|Warlord|Overlord/.test(t))return{txt:'Open Battle and attack a target with a good win chance.',btn:'Open Battle',run:openBattle};
  if(/Research/.test(t))return{txt:'Start research in the Research Lab.',btn:'Open Research',run:openResearch};
  if(/level 5/.test(t))return{txt:'Tap a building and upgrade it. Raise the colony level to unlock higher levels.',btn:'Open Command Center',run:()=>{const h=hq();app.selected=h;openInfo(h)}};
  return null;
}
export function advice(){
  const out=[],r=app.S.rate||{},c=caps();
  if((app.S.fe||1)<1)out.push({bad:1,txt:'Power is too low, so buildings work slower.',btn:'Build Solar Array',run:()=>openBuild('solar')});
  if((app.S.fw||1)<1)out.push({bad:1,txt:'Not enough workers for every job. Build Habitats so more colonists move in.',btn:'Build Habitat',run:()=>openBuild('habitat')});
  if((r.food||0)<0){const fs=app.S.res.food/-r.food;out.push({bad:fs<90,txt:`Food is falling (${r.food.toFixed(1)}/s).`+(fs<90?` Runs out in about ${Math.ceil(fs)} seconds.`:` Lasts about ${Math.round(fs/60)} minutes.`),btn:'Build Greenhouse',run:()=>openBuild('greenhouse')})}
  if((r.water||0)<0){const ws=app.S.res.water/-r.water;out.push({bad:ws<90,txt:`Water is falling (${r.water.toFixed(1)}/s).`+(ws<90?` Runs out in about ${Math.ceil(ws)} seconds.`:` Lasts about ${Math.round(ws/60)} minutes.`),btn:'Build Ice Extractor',run:()=>openBuild('extractor')})}
  if(app.S.pop>=(app.S.cap||0)&&(app.S.cap||0)>0)out.push({txt:'All homes are full. Build or upgrade Habitats to grow.',btn:'Build Habitat',run:()=>openBuild('habitat')});
  const full=RES.filter(k=>app.S.res[k]>=c[k]*.97);if(full.length)out.push({txt:`Storage is full for ${full.map(k=>RNAME[k]).join(', ')}. Spend it or build a Depot.`,btn:'Build Depot',run:()=>openBuild('storage')});
  if(!app.S.b.some(b=>b.type==='turret')&&app.S.b.length>=4)out.push({bad:app.S.raidT<60,txt:'You have no turrets. Raids will damage your buildings.',btn:'Build Turret',run:()=>openBuild('turret')});
  const dmg=app.S.b.filter(b=>b.state==='damaged');if(dmg.length)out.push({bad:1,txt:`${dmg.length} building${dmg.length>1?'s are':' is'} knocked out and needs repair.`,btn:'Show',run:()=>{app.selected=dmg[0];openInfo(dmg[0])}});
  return out;
}
export function openGoal(){
  app.sheetMode='goal';app.selected=null;const q=QUESTS[app.S.quest],h=goalHelp(q),a=advice();
  sheet.innerHTML=`<div class="sh-head"><h3>${q?'Current goal':'All goals done'}</h3><button class="x" aria-label="Close">✕</button></div>
    ${q?`<p style="margin:0 0 4px;font-weight:800;font-size:1rem">${q.t}</p>${q.why?`<p class="muted">${q.why}</p>`:''}${q.story?`<p class="muted">${q.story}</p>`:''}<p class="muted">Reward: ${costText(q.r)}. ${h?h.txt:''}</p>${h?`<div class="btns"><button class="b2 gold" id="goGo">${h.btn}</button></div>`:''}`:'<p class="muted">You finished every goal. Keep growing your colony.</p>'}
    <h4 class="sec">Colony advice</h4>${a.length?`<div class="adv">${a.map((x,i)=>`<div class="advi${x.bad?' bad':''}"><span>${x.txt}</span><button class="b2 ghost" data-adv="${i}">${x.btn}</button></div>`).join('')}</div>`:'<p class="muted">Everything is running well.</p>'}`;
  sheet.querySelector('.x').onclick=closeSheet;
  const g=$('goGo');if(g)g.onclick=()=>h.run();
  sheet.querySelectorAll('[data-adv]').forEach(b=>b.onclick=()=>a[+b.dataset.adv].run());
  sheet.classList.add('open');app.lastSig=sheetSig();
}
app.buildFocus=null;
export function openBuild(focus,keep){app.buildFocus=typeof focus==='string'?focus:null;
  app.sheetMode='build';app.selected=null;
  const h=hq();
  const whyOf=k=>{const d=DEF[k];return d.unique&&app.S.b.some(b=>b.type===k)?'Already built':d.reqHQ&&h.lvl<d.reqHQ?'Needs colony level '+d.reqHQ:''};
  const rank=k=>whyOf(k)?2:canPay(bCost(k))?0:1;const ord=ORDER.slice().sort((a,b)=>rank(a)-rank(b));
  sheet.innerHTML=`<div class="sh-head"><h3>Build</h3><button class="x" aria-label="Close">✕</button></div><div class="cards">`+ord.map(k=>{const d=DEF[k];
    const why=whyOf(k);const poor=!why&&!canPay(bCost(k));
    return`<button class="card${why?' lock na':poor?' na':''}" data-k="${k}" aria-disabled="${!!(why||poor)}"><img src="${THUMB[k]}" alt=""><span class="n">${d.name}</span><span class="d">${why||d.desc}</span>${costHTML(bCost(k))}</button>`}).join('')+`</div>`;
  sheet.querySelector('.x').onclick=closeSheet;
  sheet.querySelectorAll('.card').forEach(c=>c.onclick=()=>{const k=c.dataset.k,w=whyOf(k);if(w){toast(DEF[k].name+': '+w.toLowerCase()+'.');return}if(!canPay(bCost(k))){toast('Not enough '+missingTxt(bCost(k))+' for '+DEF[k].name+'.');return}startPlacing(k)});
  sheet.classList.add('open');app.lastSig=sheetSig();
  if(app.buildFocus){const c=sheet.querySelector(`.card[data-k="${app.buildFocus}"]`);if(c){c.classList.add('hl');if(!keep)setTimeout(()=>c.scrollIntoView({behavior:'smooth',inline:'center',block:'nearest'}),60)}}
}
function prodText(b){
  const d=DEF[b.type],L=b.lvl;const out=[];
  if(d.prod)for(const r in d.prod){let v=d.prod[r]*L;if(d.rock&&app.tiles[b.gx][b.gy].t==='rock')v*=2;out.push('+'+v.toFixed(2).replace(/\.?0+$/,'')+' '+RNAME[r]+'/s')}
  if(d.use)for(const r in d.use)out.push('−'+(d.use[r]*L).toFixed(1)+' '+RNAME[r]+'/s');
  if(d.popCap)out.push('houses '+d.popCap*L);
  if(d.store)out.push('+'+d.store*L+' storage');
  if(d.gun)out.push('guns '+Math.round(d.gun.dmg*L)+' dmg');
  if(b.type==='hangar')out.push('fleet +'+12*L);
  if(b.type==='fashion')out.push('+'+Math.min(100,8*L)+'% move-in speed');
  if(b.type==='bank')out.push(Bk.taxRate(L,1).toFixed(2).replace(/\.?0+$/,'')+' credits per colonist per minute');
  if(d.boost)out.push('+'+Math.round(d.boost*L*100)+'% output · research ×'+(1+.25*(L-1)).toFixed(2));
  return out.join(' · ')||'—';
}
function unlocks(n){const out=ORDER.filter(k=>DEF[k].reqHQ===n).map(k=>DEF[k].name);out.push('level '+Math.min(MAXL,n+1)+' buildings');if(n<=5||n>10)out.push('more land');return out.join(', ')}
function hqNote(b){return`<span class="muted"><b style="color:var(--gold)">${RANKS[b.lvl-1]}</b>${b.lvl<MAXL?' · next level unlocks '+unlocks(b.lvl+1):' · top colony level'}${STORY[b.lvl]?'<br>'+STORY[b.lvl]:''}</span>`}
function designPicker(b){const hqb=b.type==='hq',hab=b.type==='habitat',list=hqb?HQSTYLES:hab?HSTYLES:PSTYLES,cur=hqb?hqStyle(b):b.style||(hab?'dome':'painted'),key=b.type+':';return`<h4 class="sec">Design</h4><div class="stys${hqb?' hq':''}">${list.map(H=>`<button class="sty${cur===H.id?' on':''}" data-sty="${H.id}" aria-pressed="${cur===H.id}"><img src="${THUMB[key+H.id]}" alt=""><span>${H.n}</span></button>`).join('')}</div>${!hab?'':'<button class="b2 ghost" id="styAll" style="margin-top:8px">Use this design for all habitats</button>'}`}
export function openInfo(b){
  app.sheetMode='info';const d=DEF[b.type];
  const st=b.state==='building'?'Under construction':b.state==='repair'?'Being repaired':b.state==='damaged'?'Knocked out, needs repair':b.upg>0?'Upgrading to level '+(b.lvl+1):(d.prod&&b.type!=='hq'&&(app.S.fe<1||app.S.fw<1))?'Running slow: '+(app.S.fe<1?'not enough power':'not enough workers'):'Working';
  const en=d.energy?(d.energy>0?'+':'−')+Math.abs(d.energy*b.lvl)+' power':'none';
  const mx=maxLvl(b),uc=upCost(b);
  let btns='';
  if(b.state==='damaged')btns+=`<button class="b2 gold" id="repB" ${canPay(repCost(b))?'':'disabled'}>Repair ${costHTML(repCost(b))}</button>`;
  else if(b.state==='active'&&!b.upg){
    if(b.lvl<mx)btns+=`<button class="b2${canPay(uc)?'':' na'}" id="upB">Upgrade ${costHTML(uc)}</button>`;
    else btns+=`<span class="muted">${b.lvl>=(d.maxL||MAXL)?'Max level.':'Raise the colony level to go higher.'}</span>`;
  }
  {const left=Bk.buildLeft(app.S,b);if(left>0&&(app.S.res.credit>0||Bk.bankLvl(app.S))){const rc=Bk.rushCost(left);btns+=`<button class="b2 gold" id="rushB" ${canPay(rc)?'':'disabled'}>Finish now ${costHTML(rc)}</button>`}}
  if(b.type==='hangar'&&b.state==='active')btns+=`<button class="b2 gold" id="toBattle">Open battles</button>`;
  if(b.type==='hacker'&&b.state==='active')btns+=`<button class="b2 gold" id="toContest">Contests</button>`;
  if(b.type==='lab')btns+=`<button class="b2 purple" id="toRes">${app.S.rs?'Research · '+Math.floor(100*(1-app.S.rs.left/app.S.rs.total))+'%':'Open research'}</button>`;
  btns+=`<button class="b2 ghost" id="movB">Move</button>`;
  if(b.type!=='hq')btns+=`<button class="b2 red" id="delB">Demolish</button>`;
  sheet.innerHTML=`<div class="sh-head"><div class="shh"><img class="shi" src="${THUMB[b.type]}" alt=""><div><h3>${d.name} · Lv ${b.lvl}</h3><span class="sst">${st}</span></div></div><button class="x" aria-label="Close">✕</button></div>
  <div class="info"><div class="txt">${b.type==='hq'?hqNote(b):''}
  <dl class="stats"><dt>Output</dt><dd>${prodText(b)}</dd><dt>Power</dt><dd>${en}</dd><dt>Workers</dt><dd>${d.workers||0}</dd><dt>Health</dt><dd>${Math.ceil(b.hp)} / ${maxHp(b)}</dd></dl>
  <div class="hp"><i style="width:${(100*b.hp/maxHp(b)).toFixed(0)}%"></i></div>${b.state==='building'||b.state==='repair'||b.upg>0?`<div class="muted" style="font-size:.75rem;margin-top:4px">${b.upg>0?'Upgrade':'Done'} in ${fmtT(b.upg>0?b.upg:Math.max(0,(1-(b.prog||0))*DEF[b.type].time))}</div>`:''}</div></div>${b.type==='habitat'||PICS[b.type]?designPicker(b):''}${b.type==='bank'&&b.state==='active'?bankPanel(b):''}<div class="btns sh-acts">${btns}</div>`;
  if(b.type==='bank'&&b.state==='active')wireBank();
  sheet.querySelector('.x').onclick=closeSheet;
  const up=$('upB');if(up)up.onclick=()=>{if(!canPay(uc)){toast('Need more '+missingTxt(uc)+' to upgrade.');return}pay(uc);b.upg=upTime(b);toast(d.name+' upgrading to level '+(b.lvl+1)+' · '+fmtT(b.upg));openInfo(b);save()};
  {const s2=d.size;const p=P(b.gx+s2/2,b.gy+s2/2,20);if(innerHeight<760){cam.y=p[1]+app.VH*.18/cam.z;cam.x=p[0]}}
  const ru=$('rushB');if(ru)ru.onclick=()=>{if(Bk.rushBuilding(app.S,b))save()};
  const rp=$('repB');if(rp)rp.onclick=()=>{const c=repCost(b);if(!canPay(c))return;pay(c);b.state='repair';b.prog=0;openInfo(b);save()};
  const tb=$('toBattle');if(tb)tb.onclick=openBattle;
  const tc=$('toContest');if(tc)tc.onclick=openContest;
  const trs=$('toRes');if(trs)trs.onclick=openResearch;
  const mv=$('movB');if(mv)mv.onclick=()=>startMove(b);
  sheet.querySelectorAll('[data-sty]').forEach(e=>e.onclick=()=>{b.style=e.dataset.sty;sparkle(b);openInfo(b);save()});
  const sa=$('styAll');if(sa)sa.onclick=()=>{let n=0;for(const h of app.S.b)if(h.type==='habitat'&&h!==b){h.style=b.style||'dome';n++}toast(n?'Design applied to '+n+' more habitat'+(n>1?'s':''):'This is your only habitat');save()};
  const del=$('delB');if(del){let armed=false;del.onclick=()=>{
    if(!armed){armed=true;del.textContent='Tap again to demolish';return}
    for(const k in d.cost)app.S.res[k]=Math.min(caps()[k]??Infinity,app.S.res[k]+Math.floor(d.cost[k]*.5));
    if(b.type==='bank')Bk.withdraw(app.S,app.S.bank.saved); // nothing else could reach the savings
    app.S.b.splice(app.S.b.indexOf(b),1);closeSheet();toast(d.name+' demolished · half the cost refunded');save()}}
  sheet.classList.add('open');app.lastSig=sheetSig();
}
/* ---------- bank: rules in src/sim/bank.ts. liveBank updates values in place, so taps aren't lost to a redraw ---------- */
function bankPanel(b){const L=b.lvl;
  return`<h4 class="sec">Taxes</h4><p class="muted" id="bkTax"></p>
  <h4 class="sec">Market</h4><div class="bk-rows">${RES.map(k=>`<div class="bk-row"><span class="bk-n">${ICON[k]}${RNAME[k]}</span>
    <button class="b2" data-bks="${k}">Sell ${fmt(Bk.lotSize(k,L))} <span data-bkp="s${k}"></span></button><button class="b2 ghost" data-bkb="${k}">Buy ${fmt(Bk.lotSize(k,L))} <span data-bkp="b${k}"></span></button></div>`).join('')}</div>
  <p class="muted">Prices are per unit and move all the time. Sell high, buy low.</p>
  <h4 class="sec">Savings</h4><p class="muted" id="bkSav"></p>
  <div class="btns"><button class="b2 gold" id="bkDep">Deposit all</button><button class="b2 ghost" id="bkWit">Withdraw all</button></div>`}
function wireBank(){
  sheet.querySelectorAll('[data-bks]').forEach(e=>e.onclick=()=>{const k=e.dataset.bks,got=Bk.sell(app.S,k,Bk.lotSize(k,Bk.bankLvl(app.S)));if(got){toast('Sold '+RNAME[k]+' for '+fmt(got)+' credits');save();liveBank()}});
  sheet.querySelectorAll('[data-bkb]').forEach(e=>e.onclick=()=>{const k=e.dataset.bkb,n=Bk.buy(app.S,k,Bk.lotSize(k,Bk.bankLvl(app.S)));if(n){toast('Bought '+fmt(n)+' '+RNAME[k]);save();liveBank()}});
  $('bkDep').onclick=()=>{if(Bk.deposit(app.S,app.S.res.credit)){save();liveBank()}};
  $('bkWit').onclick=()=>{if(Bk.withdraw(app.S,app.S.bank.saved)){save();liveBank()}};
  liveBank();
}
export function liveBank(){
  const t=$('bkTax');if(!t)return;const L=Bk.bankLvl(app.S);if(!L)return;
  t.textContent=`${app.S.pop} colonists pay ${fmt(Bk.taxIncome(app.S))} credits a minute. Keep them fed, watered and housed: an unhappy colony pays half.`;
  $('bkSav').textContent=`${fmt(app.S.bank.saved)} of ${fmt(Bk.vaultCap(L))} credits saved, earning ${Math.round(Bk.INTEREST*100)}% a minute. Raids can only steal credits you haven't deposited.`;
  const cap=caps();
  for(const k of RES){const n=Bk.lotSize(k,L),bp=Bk.buyPrice(app.S,k);
    sheet.querySelector(`[data-bkp="s${k}"]`).textContent='@'+Bk.sellPrice(app.S,k).toFixed(2);sheet.querySelector(`[data-bkp="b${k}"]`).textContent='@'+bp.toFixed(2);
    sheet.querySelector(`[data-bks="${k}"]`).disabled=app.S.res[k]<1;sheet.querySelector(`[data-bkb="${k}"]`).disabled=app.S.res[k]>=cap[k]-1||app.S.res.credit<bp+1}
  $('bkDep').disabled=app.S.res.credit<=0||app.S.bank.saved>=Bk.vaultCap(L);$('bkWit').disabled=app.S.bank.saved<=0;
}
export function openBattle(){
  app.sheetMode='battle';app.selected=null;
  const hh=has('hangar'),p=fleetPower(),st=app.S.stage||0,busy=app.S.cool>0||!!app.mission,hk=C.enemyPower(app.S,100)<100,
    pw=v=>hk?`<s>${v}</s> <b>${C.enemyPower(app.S,v)}</b>`:`<b>${v}</b>`,chance=v=>Math.round(100*C.winChance(app.S,v));
  const pips=Array.from({length:SECT_N},(_,i)=>`<span class="pip${i<st?' done':''}${(i+1)%8===0?' boss':''}${i===st?' next':''}" title="${SECTORS[i]}"></span>`).join('');
  let camp;
  if(st>=SECT_N)camp=`<p class="muted">All ${SECT_N} sectors are conquered. The planet is yours.</p>`;
  else{const s=sector(st),ch=chance(s.power);
    camp=`<div class="rival camp"><span class="n">Sector ${st+1}: ${s.name}${s.boss?'<span class="boss-tag">Boss</span>':''}</span><span class="odds">${s.region} · power ${pw(s.power)}${hh?` · win chance <b>${ch}%</b>`:''}</span><span class="odds">Loot</span>${costHTML(lootOf(s.loot)).replace(/class="short"/g,'')}
      ${hh?`<button class="b2 gold" data-camp="1" ${busy?'disabled':''}>Attack sector</button>`:''}</div>`}
  const head=hh?`<div style="display:flex;align-items:baseline;gap:10px;flex-wrap:wrap"><span class="pw">${p}</span><span class="muted">fleet power · from the hangar, turrets, missile batteries, Command Center and colonists</span></div>`
    +(E.hackM(app.S)<1?`<p class="muted">Hacker Center: enemy power −${Math.round(100*(1-E.hackM(app.S)))}%.</p>`:'')
    +(app.S.contests.hacked?`<p class="muted">Hacked: another −10% in your next fight, from your contest win.</p>`:'')
    +(app.S.cool>0?`<p class="muted">Fleet is refuelling: ready in ${Math.ceil(app.S.cool)}s.</p>`:app.mission?`<p class="muted">Fleet is in flight…</p>`:'')
    :`<p class="muted">Build a Hangar to send your fleet out. It needs colony level 2.</p><button class="b2 gold" id="goHangar">${hq().lvl>=2?'Build a Hangar':'Upgrade the Command Center'}</button>`;
  const sk=hh?`<h4 class="sec">Skirmish</h4><div class="rivals">`+app.S.rivals.map((r,i)=>{const ch=chance(r.power);
      return`<div class="rival"><span class="n">${r.name}</span><span class="odds">Power ${pw(r.power)} · win chance <b>${ch}%</b></span><span class="odds">Loot</span>${costHTML(lootOf(r.loot)).replace(/class="short"/g,'')}
      <button class="b2 gold" data-i="${i}" ${busy?'disabled':''}>Attack</button></div>`}).join('')+`</div>`:'';
  sheet.innerHTML=`<div class="sh-head"><h3>Battle</h3><button class="x" aria-label="Close">✕</button></div>${head}
    <h4 class="sec">Campaign · ${Math.min(st,SECT_N)} of ${SECT_N} sectors</h4><div class="pips">${pips}</div>${camp}${sk}`;
  sheet.querySelector('.x').onclick=closeSheet;
  sheet.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>launch('sk',+b.dataset.i));
  sheet.querySelectorAll('[data-camp]').forEach(b=>b.onclick=()=>launch('camp'));
  const gh=$('goHangar');if(gh)gh.onclick=()=>{if(hq().lvl>=2)openBuild('hangar');else{app.selected=hq();openInfo(hq())}};
  sheet.classList.add('open');app.lastSig=sheetSig();
}
/* ---------- hacker contests: rules in src/sim/contest.ts ---------- */
const CT_SYM=[['▲','#5dffb0','triangle'],['●','#ff4fd8','circle'],['■','#7ff7ff','square'],['◆','#ffc94a','diamond'],['★','#ff8a5c','star'],['✚','#b79bff','cross']];
const ctCell=s=>s==null?'<span class="ct-c"></span>':`<span class="ct-c" style="color:${CT_SYM[s][1]}" role="img" aria-label="${CT_SYM[s][2]}">${CT_SYM[s][0]}︎</span>`;
const ctRes=r=>`<div class="rival"><span class="n">${r.rival}</span><span class="odds">You <b>${r.score||'no crack'}</b> · rival <b>${r.rivalScore}</b> · ${r.win?'won':'lost'}</span></div>`;
export function openContest(){
  app.sheetMode='contest';app.selected=null;let body;
  const x=app.S.contests,r=K.contestRival(app.S),fee=K.contestFee(r);
  if(app.contest){const c=app.contest,cur=c.tries.length;
    const rows=Array.from({length:K.MAX_TRIES},(_,i)=>{const t=c.tries[i],g=t?t.code:i===cur?app.draft:[];
      const pips=t?`<span class="ct-pips" role="img" aria-label="${t.exact} exact, ${t.near} misplaced">${'<i class="x"></i>'.repeat(t.exact)}${'<i class="n"></i>'.repeat(t.near)}</span>`:'';
      return`<div class="ct-row${i===cur?' cur':''}">${Array.from({length:K.CODE_LEN},(_,j)=>ctCell(g[j])).join('')}${pips}</div>`}).join('');
    body=`<p class="muted">Crack the code before ${c.rival} does: ${K.CODE_LEN} symbols, repeats allowed. Rival score <b>${c.rivalScore}</b>.</p>
    <div class="rcur"><div class="rtop"><span class="n">Trace</span><span class="tm" id="ctT">${fmtT(c.left)}</span></div><div class="rbar"><i id="ctBar" style="width:${(100*c.left/c.time).toFixed(1)}%"></i></div></div>
    <div class="ct-rows">${rows}</div><p class="muted"><span class="ct-pips"><i class="x"></i></span> right place · <span class="ct-pips"><i class="n"></i></span> wrong place</p>
    <div class="ct-keys">${CT_SYM.map((s,i)=>`<button data-sy="${i}" style="color:${s[1]}" aria-label="${s[2]}" ${app.draft.length>=K.CODE_LEN?'disabled':''}>${s[0]}︎</button>`).join('')}</div>
    <div class="btns"><button class="b2 ghost" id="ctBack" ${app.draft.length?'':'disabled'}>Delete</button><button class="b2 gold" id="ctSend" ${app.draft.length<K.CODE_LEN?'disabled':''}>Send code</button></div>`;
  }else{const lvl=K.hackerLvl(app.S),ready=lvl>0&&x.cool<=0;
    body=(lvl?`<p class="muted">Your hackers race a rival to crack a code. Level ${lvl} gives you ${fmtT(K.contestTime(lvl))} and ${K.MAX_TRIES} tries. Beat the rival's score to win the reward and hack your next fight: −10% enemy power.</p>`:`<p class="muted">The Hacker Center must be working to enter contests.</p>`)
    +`<div class="rival camp"><span class="n">${r.name}</span><span class="odds">Rival score <b>${K.rivalScore(app.S,r)}</b></span><span class="odds">Reward</span>${costHTML(lootOf(r.loot)).replace(/class="short"/g,'')}
      <button class="b2 gold" id="ctGo" ${ready&&canPay(fee)?'':'disabled'}>${x.cool>0?'Next contest in '+fmtT(x.cool):'Enter'} ${costHTML(fee)}</button>${app.S.res.credit>0||Bk.bankLvl(app.S)?`<button class="b2" id="ctGoC" ${ready&&canPay(K.contestCreditFee(r))?'':'disabled'}>Enter ${costHTML(K.contestCreditFee(r))}</button>`:''}</div>`
    +(x.last?`<h4 class="sec">Last contest</h4>${ctRes(x.last)}`:'')
    +`<h4 class="sec">Leaderboard · ${x.wins} win${x.wins===1?'':'s'} in ${x.n}</h4>`
    +(x.board.length?`<div class="rivals">${x.board.map(ctRes).join('')}</div>`:`<p class="muted">No codes cracked yet.</p>`);
  }
  sheet.innerHTML=`<div class="sh-head"><h3>Hacker contest</h3><button class="x" aria-label="Close">✕</button></div>${body}`;
  sheet.querySelector('.x').onclick=closeSheet;
  const go=$('ctGo');if(go)go.onclick=()=>{app.contest=K.startContest(app.S);app.draft=[];if(app.contest)save();openContest()};
  const goC=$('ctGoC');if(goC)goC.onclick=()=>{app.contest=K.startContest(app.S,Math.random,true);app.draft=[];if(app.contest)save();openContest()};
  sheet.querySelectorAll('[data-sy]').forEach(e=>e.onclick=()=>{if(app.draft.length<K.CODE_LEN){app.draft.push(+e.dataset.sy);openContest()}});
  const bk=$('ctBack');if(bk)bk.onclick=()=>{app.draft.pop();openContest()};
  const sd=$('ctSend');if(sd)sd.onclick=()=>{const g=app.draft;app.draft=[];if(K.submitGuess(app.S,app.contest,g,hooks))app.contest=null;openContest()};
  sheet.classList.add('open');app.lastSig=sheetSig();
}
export function liveContest(){
  if(app.sheetMode!=='contest'||!app.contest)return;
  const bar=$('ctBar'),tt=$('ctT');if(bar)bar.style.width=(100*app.contest.left/app.contest.time).toFixed(1)+'%';if(tt)tt.textContent=fmtT(app.contest.left);
}
export function openResearch(){
  app.sheetMode='research';app.selected=null;
  const lab=labB(),sp=labSpeed(),done=techCount();
  let head;
  if(!lab)head=`<p class="muted">Build a Research Lab to start researching. It needs colony level 3. Here is what you can unlock:</p><button class="b2 purple" id="goLab">${hq().lvl>=3?'Build a Research Lab':'Upgrade the Command Center'}</button>`;
  else if(lab.state!=='active')head=`<p class="muted">${lab.state==='damaged'?'The lab was knocked out. Repair it to continue research.':'The lab is still being built.'}</p>`;
  else head=`<p class="muted">Lab level ${lab.lvl} · research speed ×${sp.toFixed(2)} · ${done} of ${TECH.length} researched. Upgrade the lab to research faster and unlock higher tiers.</p>`;
  if(app.S.rs){const T=TECH.find(x=>x.id===app.S.rs.id),pct=100*(1-app.S.rs.left/app.S.rs.total);
    head+=`<div class="rcur"><div class="rtop"><span class="n">${T.name}</span><span class="tm" id="rsT">${sp>0?fmtT(app.S.rs.left/sp)+' left':'paused'}</span></div>
      <div class="rbar"><i id="rsBar" style="width:${pct.toFixed(1)}%"></i></div><span class="e">${T.fx}</span><button class="b2 gold" id="rsRush" hidden></button><button class="b2 red" id="rsCancel">Cancel and refund half</button></div>`}
  const rows=BRANCHES.map((B,bi)=>{const cards=TECH.filter(T=>T.br===bi).map(T=>{const st=techState(T),tr=TIER[T.tier];let foot;
      if(st==='done')foot='<span class="ok">✓ Researched</span>';
      else if(st==='cur')foot='<span class="ok cur">In progress</span>';
      else if(st==='nolab')foot='<span class="lock">Needs a Research Lab</span>';
      else if(st==='pre')foot='<span class="lock">Needs '+TECH.find(x=>x.br===T.br&&x.tier===T.tier-1).name+'</span>';
      else if(st==='lvl')foot='<span class="lock">Needs lab level '+tr.lab+'</span>';
      else foot=`<button class="b2 purple" data-t="${T.id}" ${(app.S.rs||!canPay(tr.cost)||sp<=0)?'disabled':''}>${app.S.rs?'Lab busy':'Research'}</button>`;
      return`<div class="tech ${st}"><span class="tier">Tier ${T.tier}</span><span class="n">${T.name}</span><span class="e">${T.fx}</span>
        ${st==='done'||st==='cur'?'':`<span class="meta">${costHTML(tr.cost)}<span class="tm">${fmtT(tr.time/(sp||1))}</span></span>`}${foot}</div>`}).join('');
    return`<h4 class="sec br"><span class="dot" style="background:${B.c}"></span>${B.n}</h4><div class="techrow" data-row="${bi}">${cards}</div>`}).join('');
  sheet.innerHTML=`<div class="sh-head"><h3>Research</h3><button class="x" aria-label="Close">✕</button></div>${head}${rows}`;
  sheet.querySelector('.x').onclick=closeSheet;
  const gl=$('goLab');if(gl)gl.onclick=()=>{if(hq().lvl>=3)openBuild('lab');else{app.selected=hq();openInfo(hq())}};
  sheet.querySelectorAll('[data-t]').forEach(b=>b.onclick=()=>startResearch(b.dataset.t));
  const rr=$('rsRush');if(rr)rr.onclick=()=>{if(Bk.rushResearch(app.S))save()};
  const cn=$('rsCancel');if(cn){let armed=false;cn.onclick=()=>{if(!armed){armed=true;cn.textContent='Tap again to cancel';return}
    const T=TECH.find(x=>x.id===app.S.rs.id);for(const k in TIER[T.tier].cost)app.S.res[k]=Math.min(caps()[k],app.S.res[k]+Math.floor(TIER[T.tier].cost[k]/2));app.S.rs=null;toast('Research cancelled: '+T.name);save();openResearch()}}
  sheet.classList.add('open');app.lastSig=sheetSig();liveResearch();
}
export function liveResearch(){
  const sp=labSpeed(),l=$('resL');
  if(l)l.textContent=app.S.rs?'Lab '+Math.floor(100*(1-app.S.rs.left/app.S.rs.total))+'%':'Research';
  if(app.sheetMode!=='research'||!app.S.rs)return;
  const bar=$('rsBar'),tt=$('rsT');if(bar)bar.style.width=(100*(1-app.S.rs.left/app.S.rs.total)).toFixed(1)+'%';if(tt)tt.textContent=sp>0?fmtT(app.S.rs.left/sp)+' left':'paused';
  const rr=$('rsRush');if(rr){const c=Bk.rushCost(Bk.researchLeft(app.S));rr.hidden=!(sp>0&&(app.S.res.credit>0||Bk.bankLvl(app.S)));rr.disabled=!E.canPay(app.S,c);rr.innerHTML='Finish now '+costHTML(c)}
}
export function sheetSig(){
  if(app.sheetMode==='info'&&app.selected){const b=app.selected;return['i',b.id,b.style||'',b.state,b.lvl,b.upg>0,Math.ceil(b.hp/10),canPay(upCost(b)),canPay(repCost(b)),app.S.fe<1,app.S.fw<1,Bk.buildLeft(app.S,b)?[E.canPay(app.S,Bk.rushCost(Bk.buildLeft(app.S,b))),Math.ceil(Bk.buildLeft(app.S,b)/3)]:''].join()}
  if(app.sheetMode==='contest')return['c',app.contest?app.contest.tries.length:-1,app.contest?'':[Math.ceil(app.S.contests.cool),canPay(K.contestFee(K.contestRival(app.S))),canPay(K.contestCreditFee(K.contestRival(app.S))),K.hackerLvl(app.S),K.contestRival(app.S).name,app.S.contests.n,K.rivalScore(app.S,K.contestRival(app.S))].join()].join();
  if(app.sheetMode==='battle')return['b',app.S.stage,Math.ceil(app.S.cool),!!app.mission,fleetPower(),C.enemyPower(app.S,100),has('hangar'),app.S.rivals.map(r=>r.name).join()].join();
  if(app.sheetMode==='research'){const l=labB();return['r',app.S.rs?app.S.rs.id:'',techCount(),l?l.lvl+l.state:'',labSpeed()>0,Object.values(TIER).map(T=>canPay(T.cost)?1:0).join('')].join()}
  if(app.sheetMode==='build')return'B'+ORDER.map(k=>canPay(bCost(k))?1:0).join('')+hq().lvl+app.S.b.length;
  return'';
}
function missingTxt(c){const m=Object.keys(c).filter(r=>(app.S.res[r]||0)<c[r]);return m.map(r=>({metal:'metal',water:'water',food:'food',crystal:'crystals',credit:'credits',energy:'power'}[r]||r)).join(' and ')||'resources'}
