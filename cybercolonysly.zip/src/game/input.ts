// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** Touch and mouse input, placing and moving buildings */
import { DEF, N } from '../sim/defs';
import { app } from './state';
import { $, P, cam, clamp, clampCam, closeSheet, cv, toGrid, toWorld } from './env';
import { bHeight } from '../art/buildings';
import { depthB } from '../art/ground';
import { doPlace, setEdit, setGhost, startMove, stopPlacing } from './placing';
import { openInfo } from '../ui/sheets';

function pickBuilding(sx,sy){
  const[wx,wy]=toWorld(sx,sy);
  const list=[...app.S.b].sort((a,b)=>depthB(b)-depthB(a));
  for(const b of list){const s=DEF[b.type].size;
    const L=P(b.gx,b.gy+s)[0],R=P(b.gx+s,b.gy)[0],bot=P(b.gx+s,b.gy+s)[1],top=P(b.gx,b.gy)[1]-bHeight(b)-6;
    if(wx>=L&&wx<=R&&wy>=top&&wy<=bot){
      // reject the empty corners above the footprint's side points
      return b}}
  return null;
}
export const ptrs=new Map();app.drag=null;app.pinch=null;app.moved=false;app.pinched=false;app.fling=null;app.vel={x:0,y:0,t:0};
/* pinch zooms around the point between the fingers and moving both fingers pans; a flick keeps the map gliding */
function mid(){const[a,b]=[...ptrs.values()];return{x:(a.x+b.x)/2,y:(a.y+b.y)/2,d:Math.hypot(a.x-b.x,a.y-b.y)||1}}
cv.addEventListener('pointerdown',e=>{
  cv.setPointerCapture(e.pointerId);ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});app.fling=null;
  if(ptrs.size===1){app.drag={x:e.clientX,y:e.clientY,cx:cam.x,cy:cam.y};app.moved=false;app.pinched=false;app.vel={x:0,y:0,t:performance.now()}}
  else if(ptrs.size===2){const m=mid(),[wx,wy]=toWorld(m.x,m.y);app.pinch={d:m.d,z:cam.z,wx,wy};app.moved=true;app.pinched=true}
});
cv.addEventListener('pointermove',e=>{
  if(app.placing&&e.pointerType==='mouse'&&!ptrs.size){const[g,h]=toGrid(e.clientX,e.clientY);setGhost(Math.floor(g),Math.floor(h))}
  if(!ptrs.has(e.pointerId))return;const last=ptrs.get(e.pointerId);ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(app.pinch&&ptrs.size>=2){const m=mid();cam.z=app.pinch.z*m.d/app.pinch.d;clampCam();cam.x=app.pinch.wx-(m.x-app.VW/2)/cam.z;cam.y=app.pinch.wy-(m.y-app.VH/2)/cam.z;clampCam();return}
  if(app.drag){const dx=e.clientX-app.drag.x,dy=e.clientY-app.drag.y;if(Math.abs(dx)+Math.abs(dy)>8)app.moved=true;
    if(app.moved){cam.x=app.drag.cx-dx/cam.z;cam.y=app.drag.cy-dy/cam.z;clampCam()}
    // finger speed in screen px per second, smoothed so one jittery sample does not decide the flick
    const now=performance.now(),dt=Math.max(1,now-app.vel.t)/1000,k=Math.min(1,dt*12);
    app.vel={x:app.vel.x+((e.clientX-last.x)/dt-app.vel.x)*k,y:app.vel.y+((e.clientY-last.y)/dt-app.vel.y)*k,t:now}}
});
function endPtr(e){
  if(!ptrs.has(e.pointerId))return;
  if(!app.moved&&ptrs.size===1)tap(e.clientX,e.clientY);
  ptrs.delete(e.pointerId);
  if(ptrs.size<2)app.pinch=null;
  if(ptrs.size===1){const p=[...ptrs.values()][0];app.drag={x:p.x,y:p.y,cx:cam.x,cy:cam.y};app.vel={x:0,y:0,t:performance.now()}}
  if(ptrs.size===0){app.drag=null;
    // no glide after a pinch, or when the finger rested before lifting
    if(app.moved&&!app.pinched&&performance.now()-app.vel.t<80&&Math.hypot(app.vel.x,app.vel.y)>150)app.fling={x:clamp(app.vel.x,-3000,3000),y:clamp(app.vel.y,-3000,3000)}}
}
export function glide(dt){if(!app.fling||ptrs.size)return;const x0=cam.x,y0=cam.y;
  cam.x-=app.fling.x*dt/cam.z;cam.y-=app.fling.y*dt/cam.z;clampCam();
  const f=Math.exp(-dt*4.5);app.fling.x*=f;app.fling.y*=f;
  if(Math.hypot(app.fling.x,app.fling.y)<20||(cam.x===x0&&cam.y===y0))app.fling=null}
cv.addEventListener('pointerup',endPtr);cv.addEventListener('pointercancel',endPtr);
// Safari: a pinch on the menus would zoom the whole page; the map does its own zoom
document.addEventListener('gesturestart',e=>e.preventDefault());
cv.addEventListener('wheel',e=>{e.preventDefault();cam.z*=Math.exp(-e.deltaY*.0015);clampCam()},{passive:false});

app.movingB=null;app.editMode=false;
function tap(sx,sy){
  if(app.placing){
    const[g,h]=toGrid(sx,sy);const s=DEF[app.placing].size;
    const x=clamp(Math.floor(g-(s-1)/2),0,N-s),y=clamp(Math.floor(h-(s-1)/2),0,N-s);
    if(app.ghost&&app.ghost.x===x&&app.ghost.y===y&&app.ghost.ok)doPlace();else setGhost(x,y);
    return;
  }
  const b=pickBuilding(sx,sy);
  if(app.editMode){if(b)startMove(b);return}
  if(b){app.selected=b;openInfo(b)}else{app.selected=null;closeSheet()}
}
$('placeB').onclick=doPlace;$('cancelB').onclick=()=>{if(app.placing)stopPlacing();else setEdit(false)};
