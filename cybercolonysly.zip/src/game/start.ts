// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** Starting a colony: a fresh landing or a saved one, with the ground baked for it */
import * as Save from '../sim/save';
import { app } from './state';
import { toast } from './env';
import { KEY, defaultAv, hooks } from './colony';
import { buildTerrainCache } from '../art/ground';

/* ---------- state: rules live in src/sim/, these wrappers bind them to the current game ---------- */

export function fresh(){({S: app.S,tiles: app.tiles}=Save.newGame(defaultAv()));buildTerrainCache(app.S.seed)}
export function load(){
  let raw=null;try{raw=localStorage.getItem(KEY)}catch(e){}
  const r=Save.parseSave(raw,defaultAv);if(!r)return false;
  ({S: app.S,tiles: app.tiles}=r);buildTerrainCache(app.S.seed);
  const got=Save.applyOffline(app.S,(Date.now()-app.S.saved)/1000,hooks);
  if(got)setTimeout(()=>toast(got.length?'While you were away: '+got.join(', '):'Welcome back'),400);
  return true;
}
