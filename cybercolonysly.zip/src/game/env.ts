// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** The page: canvas size, DOM lookup, camera, sheet and toast basics, device settings */
import * as E from '../sim/economy';
import * as Save from '../sim/save';
import { N } from '../sim/defs';
import { app } from './state';

export const cv=document.getElementById('cv');app.ctx=document.createElement('canvas').getContext('2d'); // drawing target for the procedural art; Phaser owns #cv
export const $=id=>document.getElementById(id);
app.VW=0;app.VH=0;app.dpr=1;app.stage=null;
/* the canvas stops at 2x: a 3x phone would draw 9/4 the pixels for a difference players barely see. The HTML interface stays at full sharpness */
function resize(){app.dpr=Math.min(devicePixelRatio||1,2);app.VW=innerWidth;app.VH=innerHeight;if(app.stage)app.stage.resize({x:cam.x,y:cam.y,z:cam.z,vw:app.VW,vh:app.VH,dpr: app.dpr})}
addEventListener('resize',resize);resize();
export const {rng,clamp}=E;export const fmt=Save.fmt;
/* battery saver: a setting of this device, not of the colony, so it is not in the save and survives a new colony */
export const SAVER_KEY='dustfall-saver';app.saver=false;try{app.saver=localStorage.getItem(SAVER_KEY)==='1'}catch(e){}

/* ---------- map projection: one tile is 64x32 px on screen ---------- */
export const HW=32,HH=16,FLOOR=12;

/* ---------- camera ---------- */
export const cam={x:0,y:0,z:1};
export function P(gx,gy,z){return[(gx-gy)*HW,(gx+gy)*HH-(z||0)]}
export function centerOn(gx,gy){const p=P(gx,gy);cam.x=p[0];cam.y=p[1]}
export function clampCam(){const c=P(N/2,N/2);cam.x=clamp(cam.x,c[0]-N*HW*.9,c[0]+N*HW*.9);cam.y=clamp(cam.y,c[1]-N*HH*1.1,c[1]+N*HH*1.1);cam.z=clamp(cam.z,.45,2.4)}
export function toWorld(sx,sy){return[(sx-app.VW/2)/cam.z+cam.x,(sy-app.VH/2)/cam.z+cam.y]}
export function toGrid(sx,sy){const[wx,wy]=toWorld(sx,sy);return[(wx/HW+wy/HH)/2,(wy/HH-wx/HW)/2]}

/* ---------- UI: sheet ---------- */
export const sheet=$('sheet');
export function closeSheet(){sheet.classList.remove('open','space');app.sheetMode=null;app.selected=null}
export function fmtT(s){s=Math.max(0,Math.ceil(s));return s>=60?Math.floor(s/60)+'m '+String(s%60).padStart(2,'0')+'s':s+'s'}

/* ---------- toast ---------- */
export const toastD=$('toastD');
/* ponytail: icon guessed from the wording; pass it from each caller if a guess ever reads wrong */
const TOASTI=[[/^Goal done/,'★'],[/^Not enough|^Need more|^That |A colonist left/,'!'],[/raid|drone/i,'⚠'],[/ready|repaired|moved|Bought|Sold|copied|added|Saved|applied/,'✓'],[/construction|upgrading|Research started|launched/,'⚒']];
export function toast(m){toastD.textContent=m;toastD.dataset.i=(TOASTI.find(x=>x[0].test(m))||[0,'ℹ'])[1];toastD.classList.add('on');app.toastT=3.2}
