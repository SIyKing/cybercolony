/**
 * Everything the game changes while it runs, in one place: the colony (S, tiles), the view size and camera target,
 * the drawing canvas, what the player is doing (placing, editMode, sheetMode, ...) and the live objects.
 * Modules read and write it as app.name.
 */
// ponytail: fields are loosely typed for now; give them real types as their modules lose @ts-nocheck (#2)
export const app: Record<string, any> = {};
// fields: ctx, VW, VH, dpr, stage, saver, S, tiles, shk, drones, fx, floaters, colonists, missiles, devils, mission, contest, draft, devilT, ghost, placing, selected, drag, pinch, moved, pinched, fling, vel, movingB, editMode, TEX, NOISE, EMIT, MASK, thumbMode, PATHS, PATHKEY, TERR, rovers, terrCanvas, groundSig, ghostSig, bakeAt, lastRT, hudOpen, goalHide, sheetMode, buildFocus, AVN, talkB, talkI, lastSig, toastT, landed, prev, saveT, uiT, busyT, frameN, still, camX, camY, camZ
