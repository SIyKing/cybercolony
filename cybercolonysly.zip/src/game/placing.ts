// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** Placing, moving and editing buildings: the ghost preview, the hint bar, paying and building */
import { DEF, N } from '../sim/defs';
import { app } from './state';
import { $, centerOn, clamp, closeSheet, fmtT, toast } from './env';
import { costHTML } from '../ui/icons';
import { addB, bCost, canPay, hq, inArea, occAt, pay, save, sparkle } from './colony';

function validAt(type,x,y){
  const d=DEF[type];
  for(let i=x;i<x+d.size;i++)for(let j=y;j<y+d.size;j++){if(i<0||j<0||i>=N||j>=N||!inArea(i,j))return false;const o=occAt(i,j);if(o&&o!==app.movingB)return false}
  if(d.needs&&app.tiles[x][y].t!==d.needs)return false;
  return true;
}
export function setGhost(x,y){if(!app.placing)return;const s=DEF[app.placing].size;x=clamp(x,0,N-s);y=clamp(y,0,N-s);app.ghost={x,y,ok:validAt(app.placing,x,y)};updHint()}
export function startPlacing(type){
  app.placing=type;app.movingB=null;closeSheet();app.selected=null;
  const h=hq();let best=null;
  for(let r=1;r<8&&!best;r++){let bs=-1e9;for(let x=h.gx-r;x<=h.gx+1+r;x++)for(let y=h.gy-r;y<=h.gy+1+r;y++){if(x>=0&&y>=0&&validAt(type,x,y)){const sc=(x+y)-(h.gx+h.gy)-Math.abs(x-y-(h.gx-h.gy))*.6;if(sc>bs){bs=sc;best=[x,y]}}}}
  if(type==='drill'){best=null;for(let x=0;x<N&&!best;x++)for(let y=0;y<N&&!best;y++)if(validAt(type,x,y))best=[x,y]}
  if(best){setGhost(best[0],best[1]);centerOn(best[0]+.5,best[1]+.5)}else{app.ghost=null}
  showHint(true);updHint();
}
/* pick up an existing building and set it down somewhere else, free of charge */
export function startMove(b){
  app.placing=b.type;app.movingB=b;closeSheet();app.selected=null;
  setGhost(b.gx,b.gy);showHint(true);updHint();
}
function showHint(placingNow){
  $('bar').hidden=true;$('hint').hidden=false;$('placeB').hidden=!placingNow;$('cancelB').textContent=placingNow?'Cancel':'Done';
  if(!placingNow)$('hintT').textContent='Edit mode: tap a building to pick it up and move it.';
}
function updHint(){
  if(!app.placing)return;const d=DEF[app.placing];
  let t=app.movingB?'Tap a free spot to move the preview, then press Place.':'Tap a tile to move the preview, then press Place.';
  if(app.ghost&&!app.ghost.ok){let out=false;for(let i=app.ghost.x;i<app.ghost.x+d.size;i++)for(let j=app.ghost.y;j<app.ghost.y+d.size;j++)if(!inArea(i,j))out=true;
    const oc=occAt(app.ghost.x,app.ghost.y);t=out?'Raise the colony level to build out here.':d.needs==='crystal'&&(!oc||oc===app.movingB)?'A drill needs a pink crystal deposit.':'That spot is taken.'}
  if(!app.ghost)t='No free spot for this building.';
  $('hintT').textContent=(app.movingB?'Move ':'')+d.name+': '+t;$('placeB').disabled=!(app.ghost&&app.ghost.ok);$('placeB').innerHTML=app.movingB?'Place here':'Place '+costHTML(bCost(app.placing)).replace(/class="short"/g,'');
}
export function stopPlacing(){app.placing=null;app.ghost=null;app.movingB=null;if(app.editMode)showHint(false);else{$('hint').hidden=true;$('bar').hidden=false}}
export function setEdit(on){app.editMode=on;app.placing=null;app.ghost=null;app.movingB=null;closeSheet();if(on)showHint(false);else{$('hint').hidden=true;$('bar').hidden=false;$('placeB').hidden=false;$('cancelB').textContent='Cancel'}}
export function doPlace(){
  if(!app.ghost||!app.ghost.ok)return;const d=DEF[app.placing];
  if(app.movingB){const b=app.movingB;const same=b.gx===app.ghost.x&&b.gy===app.ghost.y;b.gx=app.ghost.x;b.gy=app.ghost.y;
    for(let x=b.gx;x<b.gx+d.size;x++)for(let y=b.gy;y<b.gy+d.size;y++){app.tiles[x][y].plant=0;app.S.cleared.push(x*N+y)}
    if(!same){sparkle(b);toast(d.name+' moved')}stopPlacing();save();return}
  const bc=bCost(app.placing);if(!canPay(bc)){toast('Not enough resources for '+d.name);stopPlacing();return}
  pay(bc);const nb=addB(app.placing,app.ghost.x,app.ghost.y,1,false);toast(d.name+' under construction · ready in '+fmtT(d.time*(typeof buildM==='function'?buildM():1)));stopPlacing();save();
}
