// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** Boot: load or start a colony, then run the frame loop */
import { N } from '../sim/defs';
import { Stage } from '../render/stage';
import { app } from './state';
import { $, cam, centerOn, clamp, clampCam, closeSheet, cv, toast, toastD } from './env';
import { WD, save, sim, syncColonists, updColonists } from './colony';
import { HAZE } from '../art/ground';
import { updAmbient } from '../art/units';
import { PICS } from '../art/buildings';
import { makeThumbs, render, updFx } from '../render/scene';
import { setEdit, stopPlacing } from './placing';
import { updAvatarBtn } from '../ui/avatar';
import { closeDress } from '../ui/dressing';
import { liveBank, liveContest, liveResearch } from '../ui/sheets';
import { updUI } from '../ui/hud';
import { fresh, load } from './start';
import { glide, ptrs } from './input';
import { endTalk, landCargo, nextBeat, refreshSheet, wireWorlds, worldCards } from '../ui/menus';

/* ---------- boot ---------- */
const hadSave=load();
if(!hadSave)fresh();
(()=>{const c=document.createElement('canvas');c.width=c.height=96;const x=c.getContext('2d');const im=x.createImageData(96,96);
  for(let i=0;i<96*96;i++){const v=Math.random();const o=i*4;im.data[o]=im.data[o+1]=im.data[o+2]=v<.55?20:255;im.data[o+3]=v<.55?Math.random()*34:Math.random()*20}
  x.putImageData(im,0,0);app.NOISE=app.ctx.createPattern(c,'repeat')})();
makeThumbs();updAvatarBtn();
for(const p of Object.values(PICS))p.img.decode().then(makeThumbs,()=>{}); // painted buildings arrive after the first thumbnails
centerOn(N/2,N/2+.5);cam.z=clamp(Math.min(app.VW/330,app.VH/520),.6,1.4);clampCam();
app.landed=false;try{app.landed=sessionStorage.getItem('dustfall-land')==='1';sessionStorage.removeItem('dustfall-land')}catch(e){}
if(hadSave||app.landed)$('intro').hidden=true;
if(app.landed&&!hadSave)setTimeout(()=>toast('Touchdown on '+WD.name),400);
$('worldPick').innerHTML=worldCards(['moon','mars'],0);wireWorlds($('worldPick'));
addEventListener('keydown',e=>{if(e.key==='Escape'){if(!$('talk').hidden){endTalk();return}if(!$('dress').hidden){closeDress();return}if(app.placing)stopPlacing();else if(app.editMode)setEdit(false);else closeSheet()}});

app.prev=performance.now();app.saveT=0;app.uiT=0;app.busyT=0;app.frameN=0;app.still=false;app.camX=0;app.camY=0;app.camZ=0;
/* 30 fps while nothing needs more; full rate while the camera moves (and a moment after) and during a raid. 33, not 30: at 60 Hz
   two frames last 33.3 ms, and with a limit of 33.33 timer jitter would often make it wait for a third. A hidden page gets no animation frames, so nothing draws. */
function pace(dt){
  if(cam.x!==app.camX||cam.y!==app.camY||cam.z!==app.camZ||ptrs.size)app.busyT=.3;else app.busyT-=dt;
  app.camX=cam.x;app.camY=cam.y;app.camZ=cam.z;app.frameN++;
  app.still=app.busyT<=0&&!app.shk&&!app.drones.length&&!app.S.raidOn;
  app.stage.setFps(app.saver||app.still?33:0);
}
function frame(now){
  const dt=Math.min(.05,(now-app.prev)/1000);app.prev=now;
  pace(dt);glide(dt);
  if($('intro').hidden&&$('talk').hidden){sim(dt);app.saveT+=dt;if(app.saveT>5){app.saveT=0;save()}}
  syncColonists();updColonists(dt);updAmbient(dt);updFx(dt);
  if(app.toastT>0){app.toastT-=dt;if(app.toastT<=0)toastD.classList.remove('on')}
  app.cargoT=(app.cargoT||0)-dt;if(app.cargoT<=0){app.cargoT=5;landCargo()} // cargo lands even while people talk
  app.uiT-=dt;if(app.uiT<=0){app.uiT=.25;updUI();nextBeat();refreshSheet();liveResearch();liveContest();if(app.sheetMode==='info')liveBank()}
  render(now/1000);
}
app.stage=new Stage(cv,{x:cam.x,y:cam.y,z:cam.z,vw:app.VW,vh:app.VH,dpr: app.dpr},HAZE,frame);
