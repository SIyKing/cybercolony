// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** The running colony: state wrappers, save and load, live objects, simulation tick, colonists */
import { QUESTS as QS } from '../sim/quests';
import * as E from '../sim/economy';
import * as C from '../sim/campaign';
import * as R from '../sim/research';
import * as W from '../sim/worlds';
import { useWorld } from '../sim/lore';
import { step } from '../sim/step';
import { DEF, N, TAU } from '../sim/defs';
import { app } from './state';
import { closeSheet, toast } from './env';

// one storey is about 3.5 m; a colonist is about 1.8 m
export const QUESTS=QS.map(q=>({...q,ok:()=>q.ok(app.S)}));
export const addB=(type,gx,gy,lvl,instant)=>E.addB(app.S,app.tiles,type,gx,gy,lvl,instant);
export const maxHp=b=>E.maxHp(app.S,b);
export const hq=()=>E.hq(app.S);
export const has=t=>E.has(app.S,t);
export const occAt=(x,y)=>E.occAt(app.S,x,y);
export const area=()=>E.area(app.S);
export const inArea=(x,y)=>E.inArea(app.S,x,y);
export const caps=()=>E.caps(app.S);
export const stormLeft=()=>app.S?E.stormLeft(app.S):0;
export const stormSun=()=>E.stormSun(app.S);
export const maxLvl=b=>E.maxLvl(app.S,b);
export const upCost=b=>E.upCost(app.S,b);
export const repCost=b=>E.repCost(app.S,b);
export const canPay=c=>E.canPay(app.S,c);
export const pay=c=>E.pay(app.S,c);
export const bCost=k=>E.bCost(app.S,k);
export const lootOf=l=>E.lootOf(app.S,l);
export const fleetPower=()=>E.fleetPower(app.S);
export const sector=C.sector;
export const tech=id=>E.tech(app.S,id);
export const techCount=()=>R.techCount(app.S);
export const labB=()=>R.labB(app.S);
export const labSpeed=()=>R.labSpeed(app.S);
export const techState=T=>R.techState(app.S,T);

/* ---------- save/load ---------- */
/* the world this device plays; each world is its own colony and save */
export const WORLD=(()=>{let w=null;try{w=localStorage.getItem(W.WORLD_KEY)}catch(e){}return W.isWorld(w)?w:'mars'})(),WD=W.WORLDS[WORLD];
useWorld(WORLD);
export const KEY=W.saveKey(WORLD);
export function save(){
  if(!app.S)return;app.S.saved=Date.now();
  try{localStorage.setItem(KEY,JSON.stringify(app.S))}catch(e){}
}
addEventListener('pagehide',save);
document.addEventListener('visibilitychange',()=>{if(document.hidden)save()});


/* ---------- live objects ---------- */
app.shk=0;app.drones=[];app.fx=[];app.floaters=[];app.colonists=[];app.missiles=[];app.devils=[];app.mission=null;app.contest=null;app.draft=[];app.devilT=8;
app.ghost=null;app.placing=null;app.selected=null;
/* how the simulation reaches the screen */
export const hooks={toast:m=>toast(m),fx:e=>app.fx.push(e),boom:(x,y,z,sc)=>boomAt(x,y,z,sc),shake:v=>{app.shk=Math.max(app.shk,v)},
  weld:b=>weldSpark(b),sparkle:b=>sparkle(b),floater:(b,txt,t)=>app.floaters.push({b,txt,t}),save:()=>save()};

/* ---------- simulation: src/sim/step.ts ---------- */
export function sim(dt){const live={drones: app.drones,missiles: app.missiles,mission: app.mission,contest: app.contest};step(app.S,app.tiles,live,dt,hooks);app.mission=live.mission;app.contest=live.contest}
/* explosion: white flash, fireball, sparks, rising smoke, debris */
function boomAt(x,y,z,sc){
  sc=sc||1;
  app.fx.push({k:'flash',x,y,z,t:.22,r:1.1*sc});
  app.fx.push({k:'fire',x,y,z,t:.5,max:.5,r:.18*sc});
  for(let i=0;i<14*sc;i++){const a=Math.random()*TAU,v=(30+Math.random()*90)*Math.sqrt(sc);
    app.fx.push({k:'p',x,y,z,ox:0,oy:0,vx:Math.cos(a)*v,vy:Math.sin(a)*v*.55-30,t:.35+Math.random()*.45,c:Math.random()<.5?'#ffd27a':'#ff8a3a'})}
  for(let i=0;i<6*sc;i++){const a=Math.random()*TAU;
    app.fx.push({k:'smoke',x:x+Math.cos(a)*.15*sc,y:y+Math.sin(a)*.15*sc,z:z+Math.random()*8,t:1.4+Math.random(),max:2.2,r:.1*sc,g:.18*sc,c:[70,58,52],rise:14+Math.random()*12})}
  for(let i=0;i<5*sc;i++){const a=Math.random()*TAU,v=20+Math.random()*30;
    app.fx.push({k:'deb',x,y,z,ox:0,oy:0,vx:Math.cos(a)*v,vy:Math.sin(a)*v*.5-50,t:.6+Math.random()*.3,rot:Math.random()*TAU})}
}
function weldSpark(b){const s=DEF[b.type].size;const x=b.gx+.2+Math.random()*(s-.4),y=b.gy+.2+Math.random()*(s-.4);
  for(let i=0;i<4;i++){const a=Math.random()*TAU,v=20+Math.random()*30;app.fx.push({k:'p',x,y,z:6+Math.random()*16,ox:0,oy:0,vx:Math.cos(a)*v,vy:-Math.random()*30,t:.25+Math.random()*.25,c:'#fff3b0'})}
  app.fx.push({k:'flash',x,y,z:10,t:.06,r:.25,c:[200,230,255]})}
export function sparkle(b){const s=DEF[b.type].size;
  for(let i=0;i<26*s;i++){const a=Math.random()*TAU,r=Math.random()*.5*s;
    app.fx.push({k:'star',x:b.gx+s/2+Math.cos(a)*r,y:b.gy+s/2+Math.sin(a)*r,z:4+Math.random()*30*s,vz:20+Math.random()*30,t:.8+Math.random()*.7,max:1.5})}
  app.fx.push({k:'ring',x:b.gx+s/2,y:b.gy+s/2,t:.7,max:.7,r:s*.9})}

export function launch(kind,i){
  const m=C.launch(app.S,app.mission,kind,i);if(!m)return;
  app.mission=m;closeSheet();toast('Fleet launched at '+m.name);
}

/* ---------- colonists ---------- */
function freeTile(x,y){return x>=0&&y>=0&&x<N&&y<N&&!occAt(x,y)}
export function syncColonists(){
  const want=Math.min(app.S.pop,48);
  while(app.colonists.length<want){const b=app.S.b[Math.floor(Math.random()*app.S.b.length)];
    let x=b.gx+DEF[b.type].size,y=b.gy;if(!freeTile(x,y)){x=b.gx;y=b.gy+DEF[b.type].size}
    if(!freeTile(x,y)){x=6;y=7}
    app.colonists.push({x:x+.5,y:y+.5,tx:x,ty:y,sp:.6+Math.random()*.4,c:Math.random()<.5?'#ff6fb0':'#a98bff'})}
  app.colonists.length=want;
}
export function updColonists(dt){
  for(const c of app.colonists){
    const dx=c.tx+.5-c.x,dy=c.ty+.5-c.y,d=Math.hypot(dx,dy);
    if(d<.05){let opts=[[1,0],[-1,0],[0,1],[0,-1]].map(([a,b])=>[c.tx+a,c.ty+b]).filter(([x,y])=>freeTile(x,y));if(app.PATHS&&Math.random()<.85){const po=opts.filter(([x,y])=>app.PATHS.set.has(x*N+y));if(po.length)opts=po}
      if(opts.length&&Math.random()<.9){const o=opts[Math.floor(Math.random()*opts.length)];c.tx=o[0];c.ty=o[1]}}
    else{c.x+=dx/d*c.sp*dt;c.y+=dy/d*c.sp*dt}
  }
}

/* ---------- day and night: one sol lasts 5 minutes ---------- */
const DAY=300;
export function dayInfo(){
  const ph=(((app.S?app.S.t:0)/DAY)+.82)%1;
  const dark=0,tw=0; // always day: the night look is turned off
  const hr=(ph*24+12)%24;const sol=Math.floor((app.S?app.S.t:0)/DAY+.82)+1;
  return{ph,dark,tw,hr,sol};
}
export const defaultAv=()=>({g:'f',face:0});
