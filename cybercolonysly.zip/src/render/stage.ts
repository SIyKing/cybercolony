import Phaser from 'phaser';
import { WD, WORLD } from '../game/colony';
import { drawSky, type SkyDiscs } from '../art/sky';

export type RGB = [number, number, number];
export const rgb = (c: RGB) => (c[0] << 16) | (c[1] << 8) | c[2];

/** One light for the night pass: world x, y, radius, colour, alpha. */
export type Light = [number, number, number, RGB, number];
/** A sprite in the night pass: texture, world x, y, w, h, and the texture of what it lights, if any. */
export type Occluder = [string, number, number, number, number, (string | null)?];

export interface ImgOpts {
  w?: number; h?: number;
  /** origin, 0..1; default top-left */
  ox?: number; oy?: number;
  alpha?: number; tint?: number; fill?: boolean; add?: boolean; rot?: number;
}

export interface View { x: number; y: number; z: number; vw: number; vh: number; dpr: number }

const GLOW = 128;
const UNCAPPED = 1000;

/**
 * Phaser stage for the colony. The game describes each frame in immediate mode (img, g, text,
 * night, atmosphere); the stage keeps pools of Phaser objects and hides whatever a frame did not use.
 * Everything lives in world space under one camera; screen-space layers are placed from the view.
 */
export class Stage {
  game: Phaser.Game;
  scene!: Phaser.Scene;
  ready: Promise<void>;
  private view: View = { x: 0, y: 0, z: 1, vw: 1, vh: 1, dpr: 1 };
  private imgs: Phaser.GameObjects.Image[] = [];
  private imgUsed = 0;
  private gfx = new Map<string, Phaser.GameObjects.Graphics>();
  private gfxUsed = new Set<string>();
  private texts = new Map<string, Phaser.GameObjects.Text>();
  private textUsed = new Set<string>();
  private nightRT!: Phaser.GameObjects.RenderTexture;
  private nightSize = '';
  private stamps: Phaser.GameObjects.Image[] = [];
  private occStamps: Phaser.GameObjects.Image[] = [];
  private atmo: Record<string, Phaser.GameObjects.Image> = {};
  private motes: [number, number, number, number][] = [];
  private atmoSize = '';
  /** where the planet hangs on screen, and how visible it is: it fades while buildings stand under it (#43) */
  private planetDiscs: SkyDiscs = [];
  private planetA = 1;
  private planetT = 0;

  /** true when a world-space rectangle shows on screen under the planet or a moon */
  underPlanet(x: number, y: number, w: number, h: number) {
    const z = this.view.z, x0 = (x - this.left) * z, y0 = (y - this.top) * z, x1 = x0 + w * z, y1 = y0 + h * z;
    return this.planetDiscs.some(([cx, cy, r]) => {
      const dx = cx - Math.max(x0, Math.min(cx, x1)), dy = cy - Math.max(y0, Math.min(cy, y1));
      return dx * dx + dy * dy < r * r;
    });
  }

  constructor(canvas: HTMLCanvasElement, v: View, bg: RGB, onFrame: (time: number) => void) {
    this.view = v;
    let done: () => void;
    this.ready = new Promise(r => { done = r; });
    const stage = this;
    this.game = new Phaser.Game({
      type: Phaser.WEBGL, canvas, width: Math.round(v.vw * v.dpr), height: Math.round(v.vh * v.dpr),
      backgroundColor: rgb(bg), banner: false, audio: { noAudio: true }, fps: { limit: UNCAPPED },
      input: { keyboard: false, mouse: false, touch: false, gamepad: false },
      scale: { mode: Phaser.Scale.NONE }, render: { antialias: true, roundPixels: false, powerPreference: 'high-performance' },
      scene: { create(this: Phaser.Scene) { stage.scene = this; stage.init(); done(); }, update(time: number) { onFrame(time); } },
    });
  }

  private init() {
    const s = this.scene;
    // soft radial glows: a light falloff and a hot core
    this.radial('glowSoft', [[0, 1], [.35, .5], [1, 0]]);
    this.radial('glowCore', [[0, 1], [.25, .8], [1, 0]]);
    this.nightRT = this.makeNightRT(4, 4);
    // a dark soft blob for shadows on the ground; fades to fully transparent, so no edge shows
    const b = s.textures.createCanvas('blob', GLOW, GLOW)!, g = b.context.createRadialGradient(GLOW / 2, GLOW / 2, 0, GLOW / 2, GLOW / 2, GLOW / 2);
    g.addColorStop(0, 'rgba(24,10,6,.9)'); g.addColorStop(.55, 'rgba(24,10,6,.45)'); g.addColorStop(1, 'rgba(24,10,6,0)');
    b.context.fillStyle = g; b.context.fillRect(0, 0, GLOW, GLOW); b.refresh();
  }

  // ponytail: RenderTexture.resize() breaks drawing in Phaser 3.90, so a new one is made per screen size
  private makeNightRT(w: number, h: number) {
    return this.scene.add.renderTexture(0, 0, w, h).setOrigin(0, 0).setBlendMode(Phaser.BlendModes.MULTIPLY).setDepth(2000);
  }

  private radial(key: string, stops: [number, number][]) {
    const t = this.scene.textures.createCanvas(key, GLOW, GLOW)!;
    const c = t.context, g = c.createRadialGradient(GLOW / 2, GLOW / 2, 0, GLOW / 2, GLOW / 2, GLOW / 2);
    // opaque, brightness only, black at the rim: drawn with ADD, so black adds nothing and no texture edge can show
    for (let i = 0; i < stops.length - 1; i++) {
      const [o0, a0] = stops[i], [o1, a1] = stops[i + 1];
      for (let k = 0; k <= 16; k++) { const u = k / 16, a = a0 + (a1 - a0) * u, v = Math.round(255 * a * a); g.addColorStop(o0 + (o1 - o0) * u, `rgb(${v},${v},${v})`); }
    }
    c.fillStyle = g; c.fillRect(0, 0, GLOW, GLOW); t.refresh();
  }

  /** A canvas texture to draw into; created or resized as needed. Call refresh(key) when done. */
  canvas(key: string, w: number, h: number): CanvasRenderingContext2D {
    const T = this.scene.textures;
    let t = T.exists(key) ? T.get(key) as Phaser.Textures.CanvasTexture : null;
    if (t && (t.width !== w || t.height !== h)) t.setSize(w, h);
    if (!t) t = T.createCanvas(key, w, h)!;
    return t.context;
  }
  refresh(key: string) { (this.scene.textures.get(key) as Phaser.Textures.CanvasTexture).refresh(); }
  has(key: string) { return this.scene.textures.exists(key); }
  drop(key: string) { if (this.has(key)) this.scene.textures.remove(key); }
  /** Uses an existing canvas as a texture (replacing any texture with that key). */
  addCanvas(key: string, c: HTMLCanvasElement) { this.drop(key); this.scene.textures.addCanvas(key, c); }

  resize(v: View) {
    this.view = v;
    this.game.scale.resize(Math.round(v.vw * v.dpr), Math.round(v.vh * v.dpr));
  }

  /**
   * Limits drawing to this many frames a second; 0 draws every display frame.
   * ponytail: Phaser picks its stepper once, at start, so the game starts with a limit too high to matter (every display frame
   * passes) and this writes the private rate. Recheck on a Phaser upgrade.
   */
  setFps(limit: number) {
    const loop = this.game.loop as unknown as { fpsLimit: number; _limitRate: number };
    loop.fpsLimit = limit || UNCAPPED; loop._limitRate = 1000 / loop.fpsLimit;
  }

  /** Starts a frame: camera centred on world (x, y) at zoom z. */
  begin(x: number, y: number, z: number) {
    const v = this.view; v.x = x; v.y = y; v.z = z;
    const cam = this.scene.cameras.main;
    cam.setZoom(z * v.dpr); cam.centerOn(x, y);
    this.imgUsed = 0; this.gfxUsed.clear(); this.textUsed.clear();
    for (const g of this.gfx.values()) g.clear();
  }

  /** world rectangle currently on screen */
  get left() { return this.view.x - this.view.vw / 2 / this.view.z; }
  get top() { return this.view.y - this.view.vh / 2 / this.view.z; }

  img(key: string, x: number, y: number, depth: number, o: ImgOpts = {}) {
    let im = this.imgs[this.imgUsed++];
    if (!im) { im = this.scene.add.image(0, 0, key); this.imgs.push(im); }
    im.setTexture(key).setPosition(x, y).setOrigin(o.ox ?? 0, o.oy ?? 0).setDepth(depth).setVisible(true)
      .setAlpha(o.alpha ?? 1).setRotation(o.rot ?? 0)
      .setBlendMode(o.add ? Phaser.BlendModes.ADD : Phaser.BlendModes.NORMAL);
    if (o.w != null) im.setDisplaySize(o.w, o.h ?? o.w); else im.setScale(1);
    if (o.tint == null) im.clearTint(); else if (o.fill) im.setTintFill(o.tint); else im.setTint(o.tint);
    return im;
  }

  /** a soft additive glow of radius r (world px), squashed vertically by sy */
  glow(x: number, y: number, r: number, c: RGB, a: number, depth: number, core = false, sy = 1) {
    if (a <= 0 || r <= 0) return;
    this.img(core ? 'glowCore' : 'glowSoft', x, y, depth, { w: r * 2, h: r * 2 * sy, ox: .5, oy: .5, tint: rgb(c), alpha: Math.min(1, a), add: true });
  }

  /** a Graphics layer at this depth, cleared every frame */
  g(depth: number, add = false): Phaser.GameObjects.Graphics {
    const id = depth + (add ? '+' : '');
    let g = this.gfx.get(id);
    if (!g) { g = this.scene.add.graphics().setDepth(depth); if (add) g.setBlendMode(Phaser.BlendModes.ADD); this.gfx.set(id, g); }
    this.gfxUsed.add(id); g.setVisible(true);
    return g;
  }

  text(id: string, str: string, x: number, y: number, depth: number, size: number, color: string, alpha = 1, shadow = false) {
    let t = this.texts.get(id);
    if (!t) {
      t = this.scene.add.text(0, 0, '', { fontFamily: '"Nunito Sans",system-ui,sans-serif', fontStyle: '800', fontSize: size + 'px', color })
        .setOrigin(.5, .5).setResolution(8);
      if (shadow) t.setShadow(1, 1, '#14162e', 0, false, true);
      this.texts.set(id, t);
    }
    if (t.text !== str) t.setText(str);
    t.setPosition(x, y).setDepth(depth).setAlpha(alpha).setVisible(true);
    this.textUsed.add(id);
  }

  /**
   * Night: the scene is multiplied by a dark blue layer, at full device resolution. Sprites are stamped into it back to
   * front: each first wipes what is behind it back to the dark colour, then adds its own lit windows and neon, so a
   * window never shows through something in front of it. Lights are added last; they light whatever they fall on.
   * redraw=false keeps the last layer: only for frames where the camera has not moved, since the layer is placed by it.
   */
  night(dk: number, occ: Occluder[], lights: Light[], redraw = true) {
    const v = this.view;
    if (dk <= .01) { this.nightRT.setVisible(false); return; }
    const sc = v.dpr, w = Math.max(1, Math.ceil(v.vw * sc)), h = Math.max(1, Math.ceil(v.vh * sc));
    if (this.nightSize !== w + 'x' + h) { this.nightSize = w + 'x' + h; this.nightRT.destroy(); this.nightRT = this.makeNightRT(w, h); redraw = true; }
    const rt = this.nightRT;
    if (!redraw && rt.visible) return;
    const nc = rgb([48, 58, 116].map(c => Math.round(255 - (255 - c) * dk)) as RGB);
    rt.clear().fill(nc, 1);
    const k = v.z * sc, ox = (v.vw / 2 - v.x * v.z) * sc, oy = (v.vh / 2 - v.y * v.z) * sc;
    // One draw per run of a blend mode: in one draw, Phaser applied the last object's blend mode to all of them.
    // Each draw is a group: in a plain list Phaser moves every object to the draw call's x, y.
    let batch: Phaser.GameObjects.GameObject[] = [], mode = -1;
    const flush = () => { const list = batch; batch = []; if (list.length) rt.draw([{ isParent: true, getChildren: () => list }] as never); };
    const blend = (m: number) => { if (m !== mode) { flush(); mode = m; } };
    let used = 0;
    const stamp = (key: string, x: number, y: number, bw: number, bh: number) => {
      let st = this.occStamps[used++];
      if (!st) { st = this.scene.make.image({ key }, false).setOrigin(0, 0); this.occStamps.push(st); }
      batch.push(st.setTexture(key).setPosition(ox + x * k, oy + y * k).setDisplaySize(bw * k, bh * k));
      return st;
    };
    for (const [key, x, y, bw, bh, lit] of occ) {
      if (ox + x * k > w || oy + y * k > h || ox + (x + bw) * k < 0 || oy + (y + bh) * k < 0) continue;
      blend(Phaser.BlendModes.NORMAL);
      stamp(key, x, y, bw, bh).setTintFill(nc).setAlpha(1).setBlendMode(Phaser.BlendModes.NORMAL);
      if (!lit) continue;
      blend(Phaser.BlendModes.ADD);
      stamp(lit, x, y, bw, bh).clearTint().setAlpha(.85 * dk).setBlendMode(Phaser.BlendModes.ADD);
    }
    blend(Phaser.BlendModes.ADD);
    let lit = 0;
    for (const [x, y, r, c, a] of lights) {
      const sx = ox + x * k, sy = oy + y * k, rr = r * k;
      if (sx < -rr || sy < -rr || sx > w + rr || sy > h + rr) continue;
      let st = this.stamps[lit++];
      if (!st) { st = this.scene.make.image({ key: 'glowSoft' }, false).setBlendMode(Phaser.BlendModes.ADD).setOrigin(.5, .5); this.stamps.push(st); }
      batch.push(st.setPosition(sx, sy).setDisplaySize(rr * 2, rr * 2 * .62).setTint(rgb(c)).setAlpha(Math.min(1, a * dk)));
      // ponytail: one draw per light costs a flush each (about 80 a frame in a mid-size colony). Many lights in one draw left
      // straight edges at their rectangles; cull small dim lights first if frames drop
      flush();
    }
    flush();
    rt.setVisible(true).setPosition(this.left, this.top).setDisplaySize(v.vw / v.z, v.vh / v.z);
  }

  /** screen-space sky, sun glow, vignette, drifting dust motes and the red raid vignette */
  atmosphere(t: number, dark: number, tw: number, raid: number, storm = 0, covered = false) {
    const v = this.view, M = Math.max(v.vw, v.vh), day = 1 - dark;
    const size = `${Math.round(v.vw)}x${Math.round(v.vh)}`;
    if (size !== this.atmoSize) { this.atmoSize = size; this.bakeAtmosphere(); }
    const place = (k: string, a: number) => {
      const im = this.atmo[k];
      im.setVisible(a > .002).setAlpha(Math.min(1, a)).setPosition(this.left, this.top).setDisplaySize(v.vw / v.z, v.vh / v.z);
    };
    place('sun', day); place('twilight', tw); place('skyDay', day > .5 ? day : 0); place('skyNight', day > .5 ? 0 : 1 - day); place('sky', 1);
    // ease toward hidden or shown over about a third of a second
    const k = Math.min(1, Math.max(0, t - this.planetT) * 6); this.planetT = t;
    this.planetA += ((covered ? 0 : 1) - this.planetA) * k; place('planet', this.planetA);
    place('vignette', .38 + .2 * dark); place('storm', storm * .55); place('raid', raid);
    if (!this.motes.length && WD.air) for (let i = 0; i < 160; i++) this.motes.push([Math.random(), Math.random(), .3 + Math.random() * .7, Math.random() * Math.PI * 2]);
    const g = this.g(3050).setPosition(this.left, this.top).setScale(1 / v.z);
    // calm: the first 46 motes drift; a dust storm (#40) blows all of them, five times as fast and thicker
    const n = Math.round(46 + 114 * storm), speed = 14 + 56 * storm, alpha = .18 + .17 * storm;
    for (let i = 0; i < n && i < this.motes.length; i++) {
      const m = this.motes[i];
      const x = ((m[0] * v.vw + t * speed * m[2]) % (v.vw + 20)) - 10, y = ((m[1] * v.vh + Math.sin(t * .5 + m[3]) * 12) % v.vh);
      g.fillStyle(storm ? 0xf0b48c : 0xffe6cd, alpha * m[2] * (1 - dark * .7)).fillCircle(x, y, 1 + m[2] * (1.4 + storm));
    }
    void M;
  }

  private bakeAtmosphere() {
    const v = this.view, sc = .25, W = Math.max(8, Math.ceil(v.vw * sc)), H = Math.max(8, Math.ceil(v.vh * sc));
    const M = Math.max(v.vw, v.vh);
    const paint = (key: string, f: (c: CanvasRenderingContext2D) => void, depth: number, add = false) => {
      const c = this.canvas('atmo-' + key, W, H);
      c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, W, H); c.setTransform(sc, 0, 0, sc, 0, 0); f(c);
      this.refresh('atmo-' + key);
      if (!this.atmo[key]) this.atmo[key] = this.scene.add.image(0, 0, 'atmo-' + key).setOrigin(0, 0).setDepth(depth);
      if (add) this.atmo[key].setBlendMode(Phaser.BlendModes.NORMAL);
    };
    const radial = (c: CanvasRenderingContext2D, x: number, y: number, r0: number, r1: number, s0: string, s1: string, w = v.vw, h = v.vh) => {
      const g = c.createRadialGradient(x, y, r0, x, y, r1); g.addColorStop(0, s0); g.addColorStop(1, s1); c.fillStyle = g; c.fillRect(0, 0, w, h);
    };
    // airless worlds: white sun, black sky, grey shadow; worlds with air get the warm dust haze
    const A = WD.air, sun = A ? '255,220,180' : '255,255,255', haze = A ? '222,170,135' : '6,8,20', edge = A ? '30,12,10' : '4,6,14';
    paint('sun', c => radial(c, -v.vw * .05, -v.vh * .1, 0, M * 1.1, `rgba(${sun},.2)`, `rgba(${sun},0)`), 3000);
    paint('twilight', c => radial(c, -v.vw * .1, -v.vh * .15, 0, M * .9, 'rgba(120,165,240,.32)', 'rgba(120,165,240,0)'), 3001);
    const sky = (col: string) => (c: CanvasRenderingContext2D) => {
      const g = c.createLinearGradient(0, 0, 0, v.vh * .5); g.addColorStop(0, col); g.addColorStop(1, `rgba(${haze},0)`); c.fillStyle = g; c.fillRect(0, 0, v.vw, v.vh * .5);
    };
    paint('skyDay', sky(`rgba(${haze},${A ? .42 : .55})`), 3002);
    paint('skyNight', sky('rgba(40,48,90,.35)'), 3002);
    paint('vignette', c => radial(c, v.vw / 2, v.vh / 2, M * .35, M * .85, `rgba(${edge},0)`, `rgba(${edge},1)`), 3003);
    // the planet and stars, at full resolution so the planet stays sharp
    const d = v.dpr, sharp = (key: string, depth: number, planet: boolean) => {
      const c = this.canvas('atmo-' + key, Math.ceil(v.vw * d), Math.ceil(v.vh * d));
      c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, v.vw * d, v.vh * d); c.setTransform(d, 0, 0, d, 0, 0);
      const r = drawSky(c, v.vw, v.vh * .45, WORLD, planet); this.refresh('atmo-' + key);
      if (!this.atmo[key]) this.atmo[key] = this.scene.add.image(0, 0, 'atmo-' + key).setOrigin(0, 0).setDepth(depth);
      return r;
    };
    sharp('sky', 3002.5, false); this.planetDiscs = sharp('planet', 3002.6, true);
    // dust storm: a reddish haze over the whole map, thickest at the edges
    paint('storm', c => radial(c, v.vw / 2, v.vh / 2, 0, M * .8, 'rgba(196,104,58,.55)', 'rgba(150,62,30,1)'), 3004);
    paint('raid', c => radial(c, v.vw / 2, v.vh / 2, M * .38, M * .75, 'rgba(255,40,50,0)', 'rgba(255,40,50,1)'), 3100);
  }

  /** hides pooled objects this frame did not use */
  end() {
    for (let i = this.imgUsed; i < this.imgs.length; i++) this.imgs[i].setVisible(false);
    for (const [id, g] of this.gfx) if (!this.gfxUsed.has(id)) g.setVisible(false);
    for (const [id, t] of this.texts) if (!this.textUsed.has(id)) t.setVisible(false);
  }
}
