// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** The frame: baking art into Phaser textures and drawing the scene */
import { DEF, N, TAU } from '../sim/defs';
import { droneZ } from '../sim/raids';
import { app } from '../game/state';
import { HH, HW, P, cam, clamp } from '../game/env';
import { area, dayInfo, maxHp, occAt, stormLeft } from '../game/colony';
import { TEAL, TH, blackout, hex, poly } from '../art/kit';
import { HQSTYLES, PICS, picOf, HSTYLES, drawBuilding, drawShadow, links, upTime } from '../art/buildings';
import { buildPaths, crystalDeposit, depthB, drawAstronaut, drawBoulder, drawLamp, drawPaths } from '../art/ground';
import { collectLights, drawDrone, drawRover, drawShip, missionPos, roverFrame } from '../art/units';

/* ---------- render: the Phaser stage (src/render/stage.ts), fed by the procedural art above ----------
   Buildings, rocks, lamps, colonists, rovers, drones and the ship are drawn once into textures with the
   same canvas code as before; the ground (paths, shadows, crystals, the colony boundary) is one texture
   rebaked when it changes. A building is rebaked when its look changes (level, state, progress, aim)
   and, round-robin, a couple per frame so its animations keep moving. Effects are WebGL graphics. */
const BS=2,GS=1.5; // texture pixels per world pixel: base for buildings, ground
const TEX_MAX=4096,TEX_BUDGET=96e6; // ponytail: 96 MB of on-screen building canvases suits an iPhone; lower it if Safari drops the context
app.terrCanvas=null;app.groundSig='';app.ghostSig='';app.bakeAt=0;
const BC=new Map(),SHAPES=new Map(),BOX=new Map(),DRAW=new Map(),COL=6;
/* texture pixels per world pixel for the current zoom. Steps of 2, so a texture is never minified more than 2:1 (no mipmaps) */
const zoomScale=()=>{const v=cam.z*app.dpr;return v<=2?2:v<=4?4:8};
const onScreen=b=>{const m=40,w=app.VW/cam.z,h=app.VH/cam.z,l=app.stage.left,t=app.stage.top;return b.x<l+w+m&&b.x+b.w>l-m&&b.y<t+h+m&&b.y+b.h>t-m};
function bakeInto(key,box,scale,draw,mask){
  const c=app.stage.canvas(key,Math.max(1,Math.ceil(box.w*scale)),Math.max(1,Math.ceil(box.h*scale)));
  c.setTransform(1,0,0,1,0,0);c.globalAlpha=1;c.globalCompositeOperation='source-over';c.clearRect(0,0,c.canvas.width,c.canvas.height);
  c.setTransform(scale,0,0,scale,-box.x*scale,-box.y*scale);
  const main=app.ctx;app.ctx=mask?blackout(c):c;app.MASK=!!mask;
  try{draw()}finally{app.ctx=main;app.MASK=false}
  app.stage.refresh(key);
}
/* a sprite baked once around the world origin; box is relative to where it is drawn */
function bakeOnce(key,box,draw,cap){if(BOX.has(key))return;BOX.set(key,box);DRAW.set(key,[draw,cap||8])}
/* the texture of a sprite at the current zoom, baked the first time that zoom step needs it */
function tx(key){const[draw,cap]=DRAW.get(key),s=Math.min(zoomScale(),cap),k=key+'@'+s;if(!app.stage.has(k))bakeInto(k,BOX.get(key),s,draw);return k}
function spr(key,x,y,depth,o){const b=BOX.get(key),s=(o&&o.s)||1,k=tx(key),X=x+b.x*s,Y=y+b.y*s,w=b.w*s,h=b.h*s;app.stage.img(k,X,Y,depth,Object.assign({w,h},o));return[k,X,Y,w,h]}

const stateClass=b=>b.state==='building'||b.state==='repair'?'b':b.upg>0?'u':b.state==='damaged'?'d':'a';
/* the drawn extent of a building look, measured once from its pixels */
function shapeOf(b,t){
  const k=b.type+'|'+b.lvl+'|'+(b.style||'')+(picOf(b)?.img.complete?'+':'')+'|'+stateClass(b)+'|'+links(b);let m=SHAPES.get(k);if(m)return m;
  const s=DEF[b.type].size,o=P(b.gx,b.gy),x0=Math.floor(P(b.gx,b.gy+s)[0]-140),x1=Math.ceil(P(b.gx+s,b.gy)[0]+140),y0=Math.floor(o[1]-560),y1=Math.ceil(P(b.gx+s,b.gy+s)[1]+80);
  const c=document.createElement('canvas');c.width=x1-x0;c.height=y1-y0;const cx=c.getContext('2d',{willReadFrequently:true});cx.setTransform(1,0,0,1,-x0,-y0);
  const main=app.ctx;app.ctx=cx;
  try{drawBuilding(b,t)}finally{app.ctx=main}
  const W=c.width,d=cx.getImageData(0,0,W,c.height).data;let a=W,top=c.height,r=-1,q=-1;
  for(let y=0;y<c.height;y++)for(let x=0;x<W;x++)if(d[(y*W+x)*4+3]>2){if(x<a)a=x;if(x>r)r=x;if(y<top)top=y;if(y>q)q=y}
  const pad=14;m=r<0?{dx:-40,dy:-60,w:80,h:80}:{dx:x0+a-pad-o[0],dy:y0+top-pad-o[1],w:r-a+1+pad*2,h:q-top+1+pad*2};
  // the top drawn pixel of every COL-wide column, from the box's top-left: the sky planet fades only where a building really reaches (#43)
  if(r>=0){m.cols=[];for(let x=a;x<=r;x++){const i=Math.floor((x-a+pad)/COL);for(let y=top;y<=q;y++)if(d[(y*W+x)*4+3]>2){const v=y-top+pad;if(!(m.cols[i]<=v))m.cols[i]=v;break}}}
  SHAPES.set(k,m);return m;
}
function bSig(b){const g=DEF[b.type].gun;
  return[b.type,b.gx,b.gy,b.lvl,b.style||'',!!picOf(b)?.img.complete,links(b),b.state,b.state==='building'||b.state==='repair'?Math.round(b.prog*12):0,b.upg>0,
    g?Math.round((b.ang||0)/(TAU/48)):0,!!app.mission,b.type==='missile'&&(b.cd<DEF.missile.gun.cd*.55||!app.S.raidOn),b.type==='lab'&&!!app.S.rs,b.type==='solar'&&stormLeft()>0].join('|')}
function bakeBuilding(b,t,s){
  const m=shapeOf(b,t),o=P(b.gx,b.gy),box={x:o[0]+m.dx,y:o[1]+m.dy,w:m.w,h:m.h},e=BC.get(b.id);
  s=Math.min(s,TEX_MAX/Math.max(box.w,box.h));
  bakeInto('b'+b.id,box,s,()=>drawBuilding(b,t));
  BC.set(b.id,Object.assign(e||{},{sig:bSig(b),box,t,s,cols:m.cols}));
}
function bakeMask(b,t,e){bakeInto('m'+b.id,e.box,Math.min(e.s,4),()=>drawBuilding(b,t),true);e.msig=e.sig;e.mt=t}
function syncBuildings(t,night){
  const ids=new Set(app.S.b.map(b=>b.id));
  for(const id of [...BC.keys()])if(!ids.has(id)){BC.delete(id);app.stage.drop('b'+id);app.stage.drop('m'+id)}
  // sharp on screen, as far as the memory budget allows; base scale off screen
  let want=zoomScale(),area=0;
  for(const e of BC.values())if(onScreen(e.box))area+=e.box.w*e.box.h;
  while(want>BS&&area*want*want*4>TEX_BUDGET)want/=2;
  const sOf=b=>{const e=BC.get(b.id);return !e||onScreen(e.box)?want:BS};
  for(const b of app.S.b){const e=BC.get(b.id);if(!e||e.sig!==bSig(b))bakeBuilding(b,t,sOf(b))}
  // masks exist only at night
  if(!night)for(const[id,e]of BC)if(e.msig){e.msig=null;app.stage.drop('m'+id)}
  const now=performance.now();if(now<app.bakeAt)return;
  // the rest shares a slice of frame time: resolution changes first, then the night masks, then animation, oldest first
  // ponytail: bakes wait 7x their own cost, so about an eighth of the frame at most; moving neon and screens into GPU tints would free the rest
  const rank=b=>{const e=BC.get(b.id),w=Math.min(sOf(b),TEX_MAX/Math.max(e.box.w,e.box.h));return w!==e.s?0:night&&e.msig!==e.sig?1:night&&onScreen(e.box)&&t-e.mt>1?2:onScreen(e.box)&&t-e.t>1/15?3:9};
  const todo=app.S.b.map(b=>[rank(b),b]).filter(r=>r[0]<9).sort((x,y)=>x[0]-y[0]||BC.get(x[1].id).t-BC.get(y[1].id).t);
  for(const[r,b]of todo){if(r===1||r===2)bakeMask(b,t,BC.get(b.id));else bakeBuilding(b,t,sOf(b));if(performance.now()-now>3)break}
  app.bakeAt=performance.now()+(performance.now()-now)*7;
}

/* the ground: everything flat under the buildings */
const GB=(()=>{const l=P(0,N)[0],r=P(N,0)[0],tp=P(0,0)[1],bt=P(N,N)[1];return{x:l-60,y:tp-60,w:r-l+120,h:bt-tp+120}})();
function groundKey(){
  return app.S.b.map(b=>b===app.movingB?'-':b.type+b.gx+','+b.gy+':'+b.lvl+b.state[0]+(b.style||'')).join('|')+'#'+area().a+','+area().b+'#'+!!(app.placing||app.editMode)+'#'+app.S.cleared.length;
}
function bakeGround(){
  bakeInto('ground',GB,GS,()=>{
    const A=area();
    if(A.a>0){app.ctx.beginPath();const o=[P(0,0),P(N,0),P(N,N),P(0,N)],i=[P(A.a,A.a),P(A.a,A.b),P(A.b,A.b),P(A.b,A.a)];
      app.ctx.moveTo(o[0][0],o[0][1]);for(const p of o.slice(1))app.ctx.lineTo(p[0],p[1]);app.ctx.closePath();app.ctx.moveTo(i[0][0],i[0][1]);for(const p of i.slice(1))app.ctx.lineTo(p[0],p[1]);app.ctx.closePath();
      app.ctx.fillStyle='rgba(60,22,10,.16)';app.ctx.fill('evenodd')}
    app.ctx.setLineDash([6,6]);poly([P(A.a,A.a),P(A.b,A.a),P(A.b,A.b),P(A.a,A.b)],null,'rgba(255,236,214,.38)');app.ctx.setLineDash([]);
    if(app.placing||app.editMode){app.ctx.strokeStyle='rgba(255,240,222,.18)';app.ctx.lineWidth=.8;app.ctx.beginPath();
      for(let i=A.a;i<=A.b;i++){let a=P(i,A.a),b=P(i,A.b);app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(b[0],b[1]);a=P(A.a,i);b=P(A.b,i);app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(b[0],b[1])}app.ctx.stroke()}
    drawPaths();
    for(let x=0;x<N;x++)for(let y=0;y<N;y++)if(app.tiles[x][y].t==='crystal'&&!occAt(x,y))crystalDeposit(x,y,0);
    for(const b of app.S.b)if(b!==app.movingB)drawShadow(b,false);
  });
  bakeInto('sunShadow',GB,.75,()=>{for(const b of app.S.b)if(b!==app.movingB)drawShadow(b,true)});
}

/* sprites that never change */
function bakeSprites(){
  bakeOnce('lamp',{x:-6,y:-26,w:18,h:30},()=>drawLamp(0,0,0));
  for(const col of['#ff6fb0','#a98bff'])for(let f=0;f<8;f++)bakeOnce('astro'+col+f,{x:-6,y:-14,w:12,h:17},()=>drawAstronaut({x:0,y:0,c:col},f/8*TAU/9));
  for(const[a,k]of[[0,'x1'],[Math.PI,'x-1'],[Math.PI/2,'y1'],[-Math.PI/2,'y-1']]){
    bakeOnce('rover'+k,{x:-24,y:-28,w:48,h:40},()=>drawRover({x:0,y:0,a,wait:1},0));
    for(let f=0;f<RF;f++)bakeOnce('rover'+k+'m'+f,{x:-24,y:-28,w:48,h:40},()=>drawRover({x:0,y:0,a,wait:0},f/RF*TAU/36))}
  for(const[kind,size]of[['scout',1.35],['heavy',1.8],['lancer',1.15],['siege',2.4],['boss',3]]){const z=droneZ({kind}),[F,T]=DF[kind];
    for(let f=0;f<F;f++)bakeOnce('drone'+kind+f,{x:-52,y:-z-38,w:124,h:z+50},()=>drawDrone({x:0,y:0,kind,size,bob:0,flash:0,hp:1,max:1},f/F*T),4)}
  bakeOnce('ship',{x:-46,y:-40,w:78,h:64},()=>{const keep=app.mission;app.mission={t:6,x:0,y:0};try{drawShip(0)}finally{app.mission=keep}},4);
}
const rockKey=(x,y,k)=>{const key='rock'+x+','+y+','+k;if(!BOX.has(key)){const[sx,sy]=P(x+.5,y+.55);bakeOnce(key,{x:sx-26,y:sy-24,w:58,h:38},()=>drawBoulder(x,y,k),4)}return key};
/* animation frames: rover wheels (3 spokes turning at 12 rad/s repeat every TAU/36 s); drone rotors (a 2-blade line
   at 38 rad/s repeats every PI/38 s); the boss's ring of lights, looped over 3 s (a small jump at the seam) */
const RF=6,DF={scout:[4,Math.PI/38],heavy:[4,Math.PI/38],lancer:[4,Math.PI/38],siege:[4,Math.PI/38],boss:[24,3]};
const roverKey=(v,t)=>{const{ax,dir}=roverFrame(v);return'rover'+(ax?'x':'y')+dir+(v.wait<=0?'m'+Math.floor(t*36/TAU*RF)%RF:'')};
const droneKey=(d,t)=>{const[F,T]=DF[d.kind];return'drone'+d.kind+Math.floor(t/T*F)%F};
const astroKey=(c,t)=>'astro'+c.c+(Math.floor(((((t*9+c.x*5)%TAU)+TAU)%TAU)/TAU*8)%8);

/* the level badge sits at the building's base: on the front corner, or a side corner if a building in front hides that */
function badgeSpot(b){const s=DEF[b.type].size,d=depthB(b);
  const hidden=p=>app.S.b.some(o=>{if(o===b||depthB(o)<=d)return false;const e=BC.get(o.id);if(!e)return false;const q=e.box,m=14;return p[0]>q.x+m&&p[0]<q.x+q.w-m&&p[1]>q.y+m&&p[1]<q.y+q.h-m});
  const spots=[P(b.gx+s-.08,b.gy+s-.08,0),P(b.gx+s-.08,b.gy+.08,0),P(b.gx+.08,b.gy+s-.08,0)];
  return spots.find(p=>!hidden(p))||(b===app.selected?spots[0]:null)}
/* what casts a shadow at night: path lamps, rover headlights and lit buildings. [x, y, reach, strength, owner] */
function nightCasters(){const out=[];
  for(const[x,y]of buildPaths().lamps){const p=P(x,y);out.push([p[0]+3,p[1]-2,60,.9])}
  for(const v of app.rovers){const{pt}=roverFrame(v),p=P(...pt(.42,0));out.push([p[0],p[1],70,.8,v])}
  for(const b of app.S.b)if(b.state==='active'){const s=DEF[b.type].size,p=P(b.gx+s/2,b.gy+s/2);out.push([p[0],p[1],36+34*s,.5])}
  return out}
/* a soft shadow on the ground under a moving thing: from the sun by day, from the strongest nearby light at night */
function moverShadow(x,y,r,who,casters,dk){
  if(dk<.99)app.stage.img('blob',x-r*.3,y,4,{w:r*3.4,h:r*1.3,ox:.2,oy:.5,rot:.12,alpha:.6*(1-dk)});
  if(dk<=.01)return;
  app.stage.img('blob',x,y,4,{w:r*2.2,h:r*1.1,ox:.5,oy:.5,alpha:.5*dk});
  let best=null,bs=0;
  for(const c of casters){if(c[4]===who)continue;const d=Math.hypot(x-c[0],y-c[1]);if(d<c[2]&&c[3]*(1-d/c[2])>bs){bs=c[3]*(1-d/c[2]);best=c}}
  if(!best)return;
  const dx=x-best[0],dy=y-best[1],d=Math.hypot(dx,dy),L=r*clamp(1.6+d/14,2,4);
  app.stage.img('blob',x,y,4,{w:L*1.25,h:r*1.7,ox:.1,oy:.5,rot:Math.atan2(dy,dx),alpha:Math.min(.6,bs*1.4)*dk});
}

function barOf(b){
  let f=null,col=TEAL;
  if(b.state==='building'||b.state==='repair')f=b.prog;
  else if(b.upg>0){f=1-b.upg/upTime(b);col='#ffc94a'}
  else if(b.type==='lab'&&app.S.rs&&b.state==='active'&&!(app.S.raidOn&&b.hp<maxHp(b))){f=1-app.S.rs.left/app.S.rs.total;col='#a98bff'}
  else if((app.S.raidOn||b.state==='damaged')&&b.hp<maxHp(b)){f=b.hp/maxHp(b);col=f>.5?'#7be08a':f>.25?'#ffc94a':'#ff5a5f'}
  return f===null?null:{f:clamp(f,0,1),col};
}
const hx=c=>{const h=hex(c)||[255,255,255];return(h[0]<<16)|(h[1]<<8)|h[2]};
const pts=a=>a.map(([x,y])=>({x,y}));
function dashed(g,q,on,off){for(let i=0;i<q.length;i++){const[a0,b0]=q[i],[a1,b1]=q[(i+1)%q.length],L=Math.hypot(a1-a0,b1-b0);
  for(let s=0;s<L;s+=on+off){const e=Math.min(L,s+on);g.lineBetween(a0+(a1-a0)*s/L,b0+(b1-b0)*s/L,a0+(a1-a0)*e/L,b0+(b1-b0)*e/L)}}}

app.lastRT=0;
export function render(t){
  if(!app.stage||!app.stage.scene)return;
  const D=dayInfo();const dt=Math.min(.1,Math.max(0,t-app.lastRT));app.lastRT=t;let ox=0,oy=0;
  if(app.shk>0){app.shk=Math.max(0,app.shk-dt);const m=app.shk*9;ox=(Math.random()-.5)*m;oy=(Math.random()-.5)*m}
  app.stage.begin(cam.x+ox,cam.y+oy,cam.z);
  bakeSprites();
  if(app.TERR){if(app.terrCanvas!==app.TERR.c){app.terrCanvas=app.TERR.c;app.stage.addCanvas('terr',app.TERR.c)}app.stage.img('terr',app.TERR.x,app.TERR.y,0,{w:app.TERR.w,h:app.TERR.h})}
  const gk=groundKey();if(gk!==app.groundSig){app.groundSig=gk;bakeGround()}
  app.stage.img('ground',GB.x,GB.y,1,{w:GB.w,h:GB.h});
  app.stage.img('sunShadow',GB.x,GB.y,2,{w:GB.w,h:GB.h,alpha:1-D.dark});
  syncBuildings(t,D.dark>.01);
  const casters=D.dark>.01?nightCasters():[],occ=[];

  // flat effects on the ground
  const A=area(),gg=app.stage.g(3);
  for(const[x,y]of[[A.a,A.a],[A.b,A.a],[A.b,A.b],[A.a,A.b]]){const b=P(x,y);gg.lineStyle(1.6,0x7b868d,1).lineBetween(b[0],b[1],b[0],b[1]-12);
    gg.fillStyle((Math.floor(t*1.5+x)%2)?0xff4d4d:0x5a1a1a,1).fillCircle(b[0],b[1]-12,2)}
  for(const f of app.fx)if(f.k==='ring'){const a=1-f.t/f.max;const[x,y]=P(f.x,f.y);gg.lineStyle(2.5*(1-a)+.5,0xffd66e,(1-a)*.9).strokeEllipse(x,y,2*f.r*HW*1.5*(.4+a),2*f.r*HH*1.5*(.4+a))}
  if(app.placing&&app.ghost){const s=DEF[app.placing].size,ok=app.ghost.ok,q=pts([P(app.ghost.x,app.ghost.y),P(app.ghost.x+s,app.ghost.y),P(app.ghost.x+s,app.ghost.y+s),P(app.ghost.x,app.ghost.y+s)]);
    gg.fillStyle(ok?0x2fc0b8:0xff5a5f,.45).fillPoints(q,true).lineStyle(1,ok?0x2fc0b8:0xff5a5f,1).strokePoints(q,true)}
  if(app.selected&&app.S.b.includes(app.selected)){const b=app.selected,s=DEF[b.type].size,a=.5+.5*Math.sin(t*5),q=pts([P(b.gx,b.gy),P(b.gx+s,b.gy),P(b.gx+s,b.gy+s),P(b.gx,b.gy+s)]);
    gg.fillStyle(0xffc94a,.15+a*.15).fillPoints(q,true).lineStyle(2.5,0xffc94a,1).strokePoints(q,true)}

  // drawables, back to front
  const list=[];
  for(const b of app.S.b)if(b!==app.movingB)list.push([depthB(b),0,b]);
  for(let x=0;x<N;x++)for(let y=0;y<N;y++)if(app.tiles[x][y].plant&&!occAt(x,y))list.push([x+y+1,1,x,y,app.tiles[x][y].plant]);
  for(const c of app.colonists)list.push([c.x+c.y,2,c]);
  for(const v of app.rovers)list.push([v.x+v.y,3,v]);
  for(const l of buildPaths().lamps)list.push([l[0]+l[1],5,l]);
  for(const d of app.devils)list.push([d.x+d.y,4,d]);
  list.sort((a,b)=>a[0]-b[0]);
  list.forEach((it,i)=>{const dp=100+it[0]*10+i*1e-4;
    if(it[1]===0){const e=BC.get(it[2].id);app.stage.img('b'+it[2].id,e.box.x,e.box.y,dp,{w:e.box.w,h:e.box.h});occ.push(['b'+it[2].id,e.box.x,e.box.y,e.box.w,e.box.h,e.msig?'m'+it[2].id:null])}
    else if(it[1]===1){const k=rockKey(it[2],it[3],it[4]),b=BOX.get(k);app.stage.img(tx(k),b.x,b.y,dp,{w:b.w,h:b.h})}
    else if(it[1]===2){const[x,y]=P(it[2].x,it[2].y);moverShadow(x,y,3,it[2],casters,D.dark);occ.push(spr(astroKey(it[2],t),x,y,dp))}
    else if(it[1]===3){const[x,y]=P(it[2].x,it[2].y);moverShadow(x,y,13,it[2],casters,D.dark);occ.push(spr(roverKey(it[2],t),x,y,dp))}
    else if(it[1]===5){const[x,y]=P(it[2][0],it[2][1]);spr('lamp',x,y,dp)}
    else devil(it[2],t,dp);
  });
  if(app.placing&&app.ghost){
    const gb=app.movingB?Object.assign({},app.movingB,{gx:app.ghost.x,gy:app.ghost.y,state:app.movingB.state==='building'?'active':app.movingB.state}):{type:app.placing,gx:app.ghost.x,gy:app.ghost.y,lvl:1,state:'active',id:0,ang:.6,upg:0};
    const m=shapeOf(gb,t),o=P(gb.gx,gb.gy),box={x:o[0]+m.dx,y:o[1]+m.dy,w:m.w,h:m.h},sig=bSig(gb);
    if(sig!==app.ghostSig){app.ghostSig=sig;bakeInto('ghost',box,Math.min(zoomScale(),TEX_MAX/Math.max(box.w,box.h)),()=>drawBuilding(gb,t))}
    app.stage.img('ghost',box.x,box.y,1000,{w:box.w,h:box.h,alpha:app.movingB?.82:.6});
  }
  // smoke under the flying things
  const gs=app.stage.g(1001);
  for(const f of app.fx)if(f.k==='smoke'){const a=1-f.t/f.max;const[x,y]=P(f.x,f.y,f.z+(f.rise||6)*a*3);const c=f.c;
    gs.fillStyle((c[0]<<16)|(c[1]<<8)|c[2],.42*(1-a)).fillCircle(x+a*8,y,(f.r+f.g*a)*60)}
  const gd=app.stage.g(1102);
  for(const d of app.drones){const[x,y]=P(d.x,d.y),bob=-Math.sin(d.bob)*3*(d.kind==='boss'?.5:1);
    const dk=droneKey(d,t);occ.push(spr(dk,x,y+bob,1100));if(d.flash>0)spr(dk,x,y+bob,1101,{tint:0xffffff,fill:true,alpha:d.flash*.55});
    if(d.hp<d.max){const k=d.size,bx=x,by=y-droneZ(d)+bob,w=d.kind==='boss'?50:20*k,hy=by-(d.kind==='boss'?24:13*k);
      gd.fillStyle(0,.55).fillRect(bx-w/2,hy,w,3).fillStyle(0xff5a5f,1).fillRect(bx-w/2,hy,w*d.hp/d.max,3)}}
  for(const m of app.missiles){const[x,y]=P(m.x,m.y,m.z);const ca=Math.cos(m.a||0),sa=Math.sin(m.a||0);
    let dx=(ca-sa)*HW,dy=(ca+sa)*HH-(m.t<.25?40:0);const l=Math.hypot(dx,dy)||1;dx/=l;dy/=l;
    gd.lineStyle(2.6,0xe9edef,1).lineBetween(x-dx*6,y-dy*6,x+dx*5,y+dy*5).lineStyle(2.6,0xd9454f,1).lineBetween(x+dx*3,y+dy*3,x+dx*6,y+dy*6);
    const f=3+Math.random()*2.5;app.stage.glow(x-dx*7,y-dy*7,f,[255,162,58],1,1103);app.stage.glow(x-dx*7,y-dy*7,f*.5,[255,246,208],1,1103,true)}
  if(app.mission){const s=1+(1-app.mission.t/6)*.3,[x,y]=missionPos();spr('ship',x,y+8*s,1104,{s})}

  // glowing effects
  const ga=app.stage.g(1200,true);
  for(const f of app.fx){
    if(f.k==='beam'){const a=P(f.x1,f.y1,f.z1),b=P(f.x2,f.y2,f.z2),al=Math.min(1,f.t*8),bw=(f.w||2)*1.5,c=hx(f.c);
      ga.lineStyle(bw*3,c,al*.35).lineBetween(a[0],a[1],b[0],b[1]).lineStyle(bw,c,al).lineBetween(a[0],a[1],b[0],b[1]).lineStyle(bw*.4,0xffffff,al*.9).lineBetween(a[0],a[1],b[0],b[1])}
    else if(f.k==='flash'){const[x,y]=P(f.x,f.y,f.z);const r=60*f.r*(.6+f.t*2);app.stage.glow(x,y,r,f.c||[255,210,150],Math.min(1,f.t*4)*.7,1201);app.stage.glow(x,y,r*.35,[255,255,255],Math.min(1,f.t*6),1202,true)}
    else if(f.k==='fire'){const a=1-f.t/f.max;const[x,y]=P(f.x,f.y,f.z+a*10);const r=(f.r*60)*(.6+a*1.4);app.stage.glow(x,y,r,[255,150,50],(1-a)*.85,1201);app.stage.glow(x,y,r*.45,[255,240,190],1-a,1202,true)}
    else if(f.k==='p'){const[x,y]=P(f.x,f.y,f.z);ga.fillStyle(hx(f.c),Math.min(1,f.t*3)).fillCircle(x+f.ox,y+f.oy,1.6)}
    else if(f.k==='hit'){const[x,y]=P(f.x,f.y,f.z);const a=Math.min(1,f.t*5);app.stage.glow(x,y,10,[255,90,60],a,1201);app.stage.glow(x,y,4,[255,230,180],a,1202,true)}
    else if(f.k==='star'){const[x,y]=P(f.x,f.y,f.z);const a=Math.min(1,f.t*2),r=2.5*a+1;
      ga.fillStyle(0xffe08a,a).fillPoints(pts([[x,y-r*2],[x+r*.4,y-r*.4],[x+r*2,y],[x+r*.4,y+r*.4],[x,y+r*2],[x-r*.4,y+r*.4],[x-r*2,y],[x-r*.4,y-r*.4]]),true)}
  }
  const gdb=app.stage.g(1300);
  for(const f of app.fx)if(f.k==='deb'){const[x,y]=P(f.x,f.y,f.z),cx=x+f.ox,cy=y+f.oy,c=Math.cos(f.rot),s=Math.sin(f.rot);
    gdb.fillStyle(0x3a3533,1).fillPoints([[-2,-1.2],[2,-1.2],[2,1.2],[-2,1.2]].map(([u,v])=>({x:cx+u*c-v*s,y:cy+u*s+v*c})),true)}

  // night: everything that can hide a lit window, back to front, then the lights
  if(D.dark>.01){const{L,G}=collectLights(t);
    app.stage.night(D.dark,occ,L,!app.still||app.frameN%2===0);
    for(const[x,y,r,c,a]of G){const A=a*D.dark,rr=r*2.4;app.stage.glow(x,y,rr,c,A*.8,2100);app.stage.glow(x,y,rr*.3,[255,255,255],A,2101,true)}}
  else app.stage.night(0,[],[]);

  // labels on top
  const go=app.stage.g(2200);
  if(app.placing&&app.ghost){const s=DEF[app.placing].size;go.lineStyle(2,app.ghost.ok?0x5ff3ea:0xff5a5f,1);dashed(go,[P(app.ghost.x,app.ghost.y),P(app.ghost.x+s,app.ghost.y),P(app.ghost.x+s,app.ghost.y+s),P(app.ghost.x,app.ghost.y+s)],5,4)}
  for(const b of app.S.b){if(b.state==='building'||b===app.movingB)continue;if(!(cam.z>=1.8||b===app.selected||b.upg>0||b.state==='damaged'||app.editMode))continue;
    const spot=badgeSpot(b);if(!spot)continue;const[x,y]=spot;const w=b.lvl>=10?16:13,h=11;
    go.fillStyle(b.type==='hq'?0x78500a:0x14162e,b.type==='hq'?.92:.85).fillRoundedRect(x-w/2,y-h-1,w,h,3.5)
      .lineStyle(1,0xffc94a,b.type==='hq'?1:.75).strokeRoundedRect(x-w/2,y-h-1,w,h,3.5);
    app.stage.text('lv'+b.id,String(b.lvl),x,y-h/2-1,2202,8.5,'#fff6ea')}
  for(const b of app.S.b){if(b===app.movingB)continue;const r=barOf(b);if(!r)continue;const s=DEF[b.type].size;const[x,y]=P(b.gx+s/2,b.gy+s/2,30+s*16);
    go.fillStyle(0x14162e,.8).fillRect(x-19,y-3,38,6).fillStyle(hx(r.col),1).fillRect(x-18,y-2,36*r.f,4)}
  app.floaters.forEach((f,i)=>{const s=DEF[f.b.type].size;const[x,y]=P(f.b.gx+s/2,f.b.gy+s/2,48+s*18+(2-f.t)*16);
    app.stage.text('fl'+i,f.txt,x,y-4,2203,12,'#ffc94a',Math.min(1,f.t),true)});

  const sl=stormLeft();app.stage.atmosphere(t,D.dark,D.tw,app.drones.length?.16+.08*Math.sin(t*4):0,sl?clamp(Math.min(sl,60-sl)/5,0,1):0,
    underPlanet());
  app.stage.end();
}
/* any building drawn under the sky planet: tests each column from its top pixel down */
function underPlanet(){
  for(const e of BC.values()){const b=e.box;if(!app.stage.underPlanet(b.x,b.y,b.w,b.h))continue;
    if(!e.cols)return true;
    for(let i=0;i<e.cols.length;i++){const v=e.cols[i];if(v!=null&&app.stage.underPlanet(b.x+i*COL,b.y+v,COL,b.h-v))return true}}
  return false;
}
function devil(d,t,dp){
  const a=Math.min(1,d.life/4,(d.max-d.life)/4)*.6;if(a<=0)return;
  const[x,y]=P(d.x,d.y);
  // sun shadow on the ground (soft blob, like the rovers'), then the dust haze: glowSoft is opaque with a black rim, so only ADD hides its square
  app.stage.img('blob',x-10,y,4,{w:96,h:30,ox:.2,oy:.5,rot:.12,alpha:a*.55});
  app.stage.img('glowSoft',x,y,dp,{w:68,h:34,ox:.5,oy:.5,tint:0xcd8c64,alpha:a*.45,add:true});
  const g=app.stage.g(dp+.0001);
  for(let i=0;i<14;i++){const f=i/13,yy=y-f*92,rx=4+f*f*26+f*6,off=Math.sin(t*2.2+f*5+d.x)*8*f,a0=(t*6+i)%TAU,q=[];
    for(let j=0;j<=12;j++){const an=a0+j/12*Math.PI*1.3;q.push({x:x+off+Math.cos(an)*rx,y:yy+Math.sin(an)*rx*.32})}
    g.lineStyle(2+f*3,0xd6a078,a*(1-f*.6)*.55).strokePoints(q,false)}
}

export function updFx(dt){
  for(let i=app.fx.length-1;i>=0;i--){const f=app.fx[i];f.t-=dt;
    if(f.k==='p'){f.ox+=f.vx*dt;f.oy+=f.vy*dt;f.vy+=90*dt}
    else if(f.k==='deb'){f.ox+=f.vx*dt;f.oy+=f.vy*dt;f.vy+=200*dt;f.rot+=dt*10;if(f.oy>f.z){f.vy*=-.3;f.vx*=.5;f.oy=f.z}}
    else if(f.k==='star')f.z+=f.vz*dt;
    if(f.t<=0||(app.saver&&(f.k==='smoke'||f.k==='p')))app.fx.splice(i,1)}
  if(app.fx.length>600)app.fx.splice(0,app.fx.length-600);
  for(let i=app.floaters.length-1;i>=0;i--){app.floaters[i].t-=dt;if(app.floaters[i].t<=0)app.floaters.splice(i,1)}
}

/* ---------- thumbnails ---------- */
export const THUMB={};
export function makeThumbs(){
  const main=app.ctx;app.thumbMode=true;
  const one=b=>{const s=DEF[b.type].size,oc=document.createElement('canvas');oc.width=220;oc.height=180;
    app.ctx=oc.getContext('2d');const sc=s===2?1.2:2.15;
    app.ctx.setTransform(sc,0,0,sc,110,176-s*2*HH*sc);
    try{poly([P(0,0),P(s,0),P(s,s),P(0,s)],TH.tile?TH.tile[0]:`rgb(${TH.sand})`,TH.tile?TH.tile[1]:TH.out);drawBuilding(b,1.2);return oc.toDataURL()}catch(e){return''}};
  for(const type of Object.keys(DEF)){const b={type,gx:0,gy:0,lvl:1,state:'active',id:1,ang:.6,upg:0};
    THUMB[type]=THUMB[type+':painted']=one(b);if(PICS[type]&&type!=='hq')THUMB[type+':classic']=one({...b,style:'classic'})}
  for(const H of HSTYLES){const oc=document.createElement('canvas');oc.width=220;oc.height=180;app.ctx=oc.getContext('2d');app.ctx.setTransform(1.55,0,0,1.55,110,172-2*HH*1.55);
    try{drawBuilding({type:'habitat',gx:0,gy:0,lvl:3,style:H.id,state:'active',id:1,ang:.6,upg:0},1.2);THUMB['habitat:'+H.id]=oc.toDataURL()}catch(e){THUMB['habitat:'+H.id]=''}}
  for(const H of HQSTYLES){const oc=document.createElement('canvas');oc.width=220;oc.height=200;app.ctx=oc.getContext('2d');const sc=1.05;app.ctx.setTransform(sc,0,0,sc,110,196-64*sc);
    try{drawBuilding({type:'hq',gx:0,gy:0,lvl:4,style:H.id,state:'active',id:1,ang:.6,upg:0},1.2);THUMB['hq:'+H.id]=oc.toDataURL()}catch(e){THUMB['hq:'+H.id]=''}}
  app.ctx=main;app.thumbMode=false;
}
