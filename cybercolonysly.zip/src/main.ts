import './style.css';
import './hud.css';
// the game, in the order its parts must run; boot starts it
import './game/env';
import './ui/icons';
import './game/colony';
import './art/kit';
import './art/buildings';
import './art/ground';
import './art/units';
import './render/scene';
import './game/placing';
import './ui/avatar';
import './ui/dressing';
import './ui/sheets';
import './ui/hud';
import './game/start';
import './game/input';
import './ui/menus';
import './game/boot';

if (import.meta.env.PROD && 'serviceWorker' in navigator) {
  addEventListener('load', () => navigator.serviceWorker.register('./sw.js'));
}
