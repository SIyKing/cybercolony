// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** Ground art: rocks, walkways, terrain texture, crystals, colonists */
import { DEF, N, TAU } from '../sim/defs';
import { app } from '../game/state';
import { HH, HW, P, clamp, rng } from '../game/env';
import { WD, WORLD, area, hq, occAt } from '../game/colony';
import { TH, lg, line, poly } from './kit';

/* ---------- rocks ---------- */
const RC=WORLD==='mars'?['#c9876a','#94553a','#4a2618']:WD.rockC,AIR=WD.air;
const RSH=AIR?'rgba(55,22,10,.32)':'rgba(10,12,20,.4)',RHI=AIR?'rgba(255,214,180,.18)':'rgba(255,255,255,.2)';
function rockShape(sx,sy,rx,seed){
  const r=rng(seed);const n=8,pts=[];
  for(let i=0;i<n;i++){const a=i/n*TAU,rr=rx*(.72+r()*.38);pts.push([sx+Math.cos(a)*rr,sy+Math.sin(a)*rr*.5-(Math.sin(a)<0?rx*(.25+r()*.35):0)])}
  app.ctx.fillStyle=RSH;app.ctx.beginPath();app.ctx.ellipse(sx+rx*.55,sy+rx*.12,rx*1.25,rx*.42,0,0,TAU);app.ctx.fill();
  poly(pts,lg([sx-rx,sy-rx*.8],[sx+rx*.8,sy+rx*.4],[[0,RC[0]],[.45,RC[1]],[1,RC[2]]]),'rgba(40,16,8,.35)');
  const hp=pts.map(([x,y])=>[sx-rx*.18+(x-sx)*.5,sy-rx*.3+(y-sy)*.45]);
  poly(hp,RHI,false);
}
export function drawBoulder(x,y,k){
  const[sx,sy]=P(x+.5,y+.55);const sd=x*131+y*71+k;
  if(k===1){rockShape(sx-3,sy,9,sd);rockShape(sx+9,sy+3,4,sd+1)}
  else{rockShape(sx-6,sy-2,3.5,sd);rockShape(sx+3,sy+1,4.5,sd+2);rockShape(sx+8,sy-3,2.5,sd+3)}
}

/* ---------- paved walkways from every building to the Command Center, with street lamps ---------- */
app.PATHS=null;app.PATHKEY='';
export function buildPaths(){
  const key=app.S.b.map(b=>b.type[0]+b.gx+','+b.gy).join('|')+'#'+area().a+','+area().b;if(key===app.PATHKEY&&app.PATHS)return app.PATHS;app.PATHKEY=key;
  const h=hq(),set=new Set(),ok=(x,y)=>x>=0&&y>=0&&x<N&&y<N&&!occAt(x,y)&&app.tiles[x][y].t!=='crystal';
  if(h){const tx=h.gx+2,ty=h.gy+1;
    for(const b of app.S.b){if(b===h)continue;const sz=DEF[b.type].size;
      // start in front of the building's lit face, then walk in an L to the plaza
      let x=b.gx+sz,y=b.gy+Math.floor(sz/2);if(!ok(x,y)){x=b.gx+Math.floor(sz/2);y=b.gy+sz}if(!ok(x,y))continue;
      const goal=[h.gx+1,h.gy+1];let guard=0;
      while(guard++<40){if(ok(x,y))set.add(x*N+y);const dx=goal[0]-x,dy=goal[1]-y;if(Math.abs(dx)<=1&&Math.abs(dy)<=1)break;
        let nx=x+Math.sign(dx),ny=y;if(dx===0||!(nx>=0&&nx<N)||(occAt(nx,ny)&&occAt(nx,ny)!==h)){nx=x;ny=y+Math.sign(dy)}
        if(occAt(nx,ny)&&occAt(nx,ny)!==h){nx=x+Math.sign(dx)||x;ny=y+Math.sign(dy)||y;if(occAt(nx,ny)&&occAt(nx,ny)!==h)break}
        x=nx;y=ny;if(occAt(x,y)===h)break}}}
  const lamps=[];let k=0;for(const v of [...set].sort((a,b)=>a-b)){const x=Math.floor(v/N),y=v%N;if(((x*7+y*3)%5)===0)lamps.push([x+.8,y+.22])}
  app.PATHS={set,lamps};return app.PATHS;
}
export function drawPaths(){
  const{set}=buildPaths(),has=(x,y)=>set.has(x*N+y),a=.33,b=.67;
  const pieces=[];
  for(const v of set){const x=Math.floor(v/N),y=v%N;pieces.push([x+a,y+a,x+b,y+b]);
    if(has(x+1,y))pieces.push([x+b,y+a,x+1+a,y+b]);if(has(x,y+1))pieces.push([x+a,y+b,x+b,y+1+a]);
    if(!has(x+1,y)&&occAt(x+1,y))pieces.push([x+b,y+a,x+1,y+b]);if(!has(x,y+1)&&occAt(x,y+1))pieces.push([x+a,y+b,x+b,y+1]);
    if(!has(x-1,y)&&occAt(x-1,y))pieces.push([x,y+a,x+a,y+b]);if(!has(x,y-1)&&occAt(x,y-1))pieces.push([x+a,y,x+b,y+a])}
  const quad=([x0,y0,x1,y1],dz)=>[P(x0,y0,dz),P(x1,y0,dz),P(x1,y1,dz),P(x0,y1,dz)];
  for(const pc of pieces)poly(quad(pc,0).map(p=>[p[0],p[1]+.9]),'rgba(120,70,45,.35)',false);
  for(const pc of pieces)poly(quad(pc,.3),'#e3d6c6',false);
  app.ctx.strokeStyle='rgba(150,120,95,.25)';app.ctx.lineWidth=.4;app.ctx.beginPath();
  for(const[x0,y0,x1,y1]of pieces){const along=(x1-x0)>(y1-y0);const n=Math.max(1,Math.round((along?x1-x0:y1-y0)/.17));
    for(let k=1;k<n;k++){if(along){const u=x0+(x1-x0)*k/n,p=P(u,y0,.3),q=P(u,y1,.3);app.ctx.moveTo(p[0],p[1]);app.ctx.lineTo(q[0],q[1])}else{const u=y0+(y1-y0)*k/n,p=P(x0,u,.3),q=P(x1,u,.3);app.ctx.moveTo(p[0],p[1]);app.ctx.lineTo(q[0],q[1])}}}
  app.ctx.stroke();
}
export function drawLamp(x,y,t){
  const[bx,by]=P(x,y);const h=17;
  app.ctx.fillStyle='rgba(55,22,10,.25)';app.ctx.beginPath();app.ctx.ellipse(bx+3,by+.5,3.2,1.1,0,0,TAU);app.ctx.fill();
  app.ctx.fillStyle='#e6e9eb';app.ctx.beginPath();app.ctx.ellipse(bx,by,1.6,.8,0,0,TAU);app.ctx.fill();
  app.ctx.lineCap='round';line([bx,by],[bx,by-h],'#f4f6f7',1.3);line([bx+.5,by],[bx+.5,by-h],'#b9c1c5',.5);
  app.ctx.beginPath();app.ctx.moveTo(bx,by-h);app.ctx.quadraticCurveTo(bx+.5,by-h-3,bx+4,by-h-2.4);app.ctx.strokeStyle='#f4f6f7';app.ctx.lineWidth=1.3;app.ctx.stroke();app.ctx.lineCap='butt';
  app.ctx.fillStyle='#ffffff';app.ctx.beginPath();app.ctx.ellipse(bx+4.6,by-h-2.2,2.4,1.1,0,0,TAU);app.ctx.fill();
  app.ctx.fillStyle='#ffe2a8';app.ctx.beginPath();app.ctx.ellipse(bx+4.6,by-h-1.7,1.6,.6,0,0,TAU);app.ctx.fill();
}
/* ---------- terrain texture, baked once per landing site ---------- */
app.TERR=null;export const EXT=9,TSC=1.25,HAZE=TH.haze;
export function buildTerrainCache(seed){
  const r=rng((seed^0x5bd1e995)>>>0);
  const NP=256,perm=new Float32Array(NP*NP);for(let i=0;i<perm.length;i++)perm[i]=r();
  const vn=(x,y)=>{const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf);
    const i0=xi&255,j0=yi&255,i1=(i0+1)&255,j1=(j0+1)&255,a=perm[i0+j0*NP],b=perm[i1+j0*NP],c=perm[i0+j1*NP],d=perm[i1+j1*NP];
    return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v};
  const fbm=(x,y)=>vn(x,y)*.5+vn(x*2.03+17,y*2.03+5)*.25+vn(x*4.1+3,y*4.1+11)*.125+vn(x*8.3+7,y*8.3+1)*.0625;
  const G0=-EXT,G1=N+EXT,RES=10,FW=(G1-G0)*RES+1;
  const craters=[];
  // airless worlds keep every impact: many craters, mostly small (r^3 gives the power law), with sharp raised rims
  for(let i=0;i<(AIR?22:140);i++){const cx=G0+r()*(G1-G0),cy=G0+r()*(G1-G0),q=r();const inside=cx>-.5&&cx<N+.5&&cy>-.5&&cy<N+.5;
    if(Math.hypot(cx-N/2,cy-N/2)<4)continue;craters.push({x:cx,y:cy,r:AIR?(inside?.3+q*.35:.5+q*1.9):(inside?.2+q*q*.45:.3+q*q*2.8)})}
  const tv=(x,y,kind)=>{if(x>=0&&y>=0&&x<N&&y<N)return app.tiles[x][y].t===kind?1:0;return kind==='rock'&&fbm(x*.45+40,y*.45+40)>.58?1:0};
  const soft=(gx,gy,kind)=>{const u=gx-.5,v=gy-.5,x=Math.floor(u),y=Math.floor(v),fx=u-x,fy=v-y;
    const a=tv(x,y,kind),b=tv(x+1,y,kind),c=tv(x,y+1,kind),d=tv(x+1,y+1,kind);return a+(b-a)*fx+(c-a)*fy+(a-b-c+d)*fx*fy};
  const H=new Float32Array(FW*FW),R=new Float32Array(FW*FW),G=new Float32Array(FW*FW),B=new Float32Array(FW*FW);
  for(let j=0;j<FW;j++)for(let i=0;i<FW;i++){
    const gx=G0+i/RES,gy=G0+j/RES,k=i+j*FW;
    const n=fbm(gx*.28,gy*.28),d=fbm(gx*1.3+9,gy*1.3+4);
    let rk=clamp((soft(gx,gy,'rock')-.25)*1.7+(d-.5)*(AIR?.9:.4),0,1);const cr=soft(gx,gy,'crystal');
    const rp=AIR?Math.sin((gx*1.15+gy*.5)*6.5+n*10+Math.sin(gy*.9)*2)*(1-rk)*(1-cr):0;
    let h=n*1.3+d*.7+rk*.8+rp*.03,floor=1;
    if(AIR){for(const c of craters){const dd=Math.hypot(gx-c.x,gy-c.y)/c.r;if(dd<1.4){if(dd<1){h-=(1-dd*dd)*.55*Math.sqrt(c.r);floor=.9}else h+=(1.4-dd)/.4*.22*Math.sqrt(c.r)}}}
    else for(const c of craters){const dd=Math.hypot(gx-c.x,gy-c.y)/c.r;if(dd>1.6)continue;const s=Math.sqrt(c.r);
      // steep bowl, a sharp rim at dd=1 and a ray of bright ejecta fading out to 1.6
      if(dd<1){h-=(1-dd*dd)*1.1*s-dd**8*.5*s;floor=Math.min(floor,.8+dd*.12+dd**10*.3)}else{h+=Math.exp(-(dd-1)*10)*.45*s;floor=Math.max(floor,1+Math.exp(-(dd-1)*8)*.22)}}
    H[k]=h;
    let rr=TH.sand[0]+(n-.5)*52+(d-.5)*30+rp*2.4,gg=TH.sand[1]+(n-.5)*36+(d-.5)*22+rp*1.8,bb=TH.sand[2]+(n-.5)*22+(d-.5)*14+rp*1.2;
    const r2=TH.rock[0]+(d-.5)*44,g2=TH.rock[1]+(d-.5)*26,b2=TH.rock[2]+(d-.5)*16;
    rr+= (r2-rr)*rk;gg+=(g2-gg)*rk;bb+=(b2-bb)*rk;
    if(TH.patch){const bp=fbm(gx*.42+31,gy*.42+7)+(d-.5)*.35,pk=clamp((bp-.5)/.03,0,1)*(1-rk)*.85;rr+=(TH.patch[0]-rr)*pk;gg+=(TH.patch[1]-gg)*pk;bb+=(TH.patch[2]-bb)*pk}
    rr+=cr*8;gg-=cr*20;bb+=cr*26;
    rr*=floor;gg*=floor;bb*=floor;
    const e=Math.max(-gx,-gy,gx-N,gy-N),f=Math.pow(clamp(e/(EXT-.5),0,1),1.1);
    R[k]=rr+(HAZE[0]-rr)*f;G[k]=gg+(HAZE[1]-gg)*f;B[k]=bb+(HAZE[2]-bb)*f;
  }
  // sunlight from the upper left: slopes facing -x are lit, slopes facing +x fall into shade
  for(let j=1;j<FW-1;j++)for(let i=1;i<FW-1;i++){const k=i+j*FW;
    const s=(H[k-1]-H[k+1])*RES*.5*.8+(H[k-FW]-H[k+FW])*RES*.5*.25;const sk=TH.slope??.75,L=clamp(1-s*sk,TH.lo??1-.64*sk,TH.hi??1+.6*sk);
    R[k]*=L;G[k]*=L;B[k]*=L}
  const minX=P(G0,G1)[0],maxX=P(G1,G0)[0],minY=P(G0,G0)[1],maxY=P(G1,G1)[1];
  const W=Math.ceil((maxX-minX)*TSC),Hh=Math.ceil((maxY-minY)*TSC);
  const cnv=document.createElement('canvas');cnv.width=W;cnv.height=Hh;const c2=cnv.getContext('2d');
  const im=c2.createImageData(W,Hh),px=im.data;let seedL=(seed*2654435761)>>>0;
  const rand=()=>{seedL=(seedL*1664525+1013904223)>>>0;return seedL/4294967296};
  for(let y=0;y<Hh;y++){const wy=minY+y/TSC;for(let x=0;x<W;x++){
    const wx=minX+x/TSC,gx=(wx/HW+wy/HH)/2,gy=(wy/HH-wx/HW)/2;
    const fi=(gx-G0)*RES,fj=(gy-G0)*RES;if(fi<0||fj<0||fi>=FW-1||fj>=FW-1)continue;
    const i0=fi|0,j0=fj|0,u=fi-i0,v=fj-j0,k=i0+j0*FW;
    const w00=(1-u)*(1-v),w10=u*(1-v),w01=(1-u)*v,w11=u*v;
    let rr=R[k]*w00+R[k+1]*w10+R[k+FW]*w01+R[k+FW+1]*w11,gg=G[k]*w00+G[k+1]*w10+G[k+FW]*w01+G[k+FW+1]*w11,bb=B[k]*w00+B[k+1]*w10+B[k+FW]*w01+B[k+FW+1]*w11;
    const q=rand(),grain=(q-.5)*14*(TH.grain??1);let m=1;if(q>.992)m=.72;else if(q<.004)m=1.18;
    const lu=rr*.3+gg*.59+bb*.11;const sa=TH.sat??1.22;rr=lu+(rr-lu)*sa;gg=lu+(gg-lu)*sa;bb=lu+(bb-lu)*sa; // richer, painted-map colour
    const o=(x+y*W)*4;px[o]=clamp(rr*m+grain,0,255);px[o+1]=clamp(gg*m+grain*.7,0,255);px[o+2]=clamp(bb*m+grain*.5,0,255);px[o+3]=255}}
  c2.putImageData(im,0,0);
  // scattered rocks outside the colony
  const keep=app.ctx;app.ctx=c2;app.ctx.setTransform(TSC,0,0,TSC,-minX*TSC,-minY*TSC);
  const rocks=[];for(let i=0;i<70;i++){const x=G0+r()*(G1-G0),y=G0+r()*(G1-G0);if(x>-1&&x<N+1&&y>-1&&y<N+1)continue;rocks.push([x,y,r()])}
  // ejecta: boulders thrown onto the rims of the big craters
  if(!AIR)for(const c of craters){if(c.r<1.2)continue;for(let i=0;i<c.r*3;i++){const a=r()*TAU,dd=1.05+r()*.5,x=c.x+Math.cos(a)*c.r*dd,y=c.y+Math.sin(a)*c.r*dd;
    if(x>-1&&x<N+1&&y>-1&&y<N+1)continue;rocks.push([x,y,r()*.45])}}
  rocks.sort((a,b)=>a[0]+a[1]-b[0]-b[1]);
  for(const[x,y,s]of rocks){const[sx,sy]=P(x,y);app.ctx.globalAlpha=1-clamp(Math.max(-x,-y,x-N,y-N)/EXT,0,1)*.8;rockShape(sx,sy,3+s*10,(x*97+y*13)|0)}
  app.ctx.globalAlpha=1;app.ctx=keep;
  app.TERR={c:cnv,x:minX,y:minY,w:W/TSC,h:Hh/TSC};
}

/* ---------- render ---------- */
const motes=[];{const r=rng(9);for(let i=0;i<46;i++)motes.push([r(),r(),.3+r()*.7,r()*TAU])}
export function depthB(b){const s=DEF[b.type].size;return b.gx+b.gy+s}
export function crystalDeposit(x,y,t){
  const[a,b]=P(x+.5,y+.55);const gl=.65+.35*Math.sin(t*2+x*3+y);
  const g=app.ctx.createRadialGradient(a,b,1,a,b,16);g.addColorStop(0,`rgba(200,95,208,${.2*gl})`);g.addColorStop(1,'rgba(200,95,208,0)');
  app.ctx.fillStyle=g;app.ctx.beginPath();app.ctx.ellipse(a,b,16,8,0,0,TAU);app.ctx.fill();
  const sh=[[-9,11,3.4,-.25],[-2,20,4.6,.05],[6,14,3.8,.28],[11,8,2.6,.45],[1,9,2.8,-.5]];
  for(const[dx,h,w,lean]of sh){const bx=a+dx,by=b+(dx%3),tx=bx+lean*h,ty=by-h;
    app.ctx.fillStyle='rgba(60,20,40,.3)';app.ctx.beginPath();app.ctx.ellipse(bx+3,by+1,w*1.3,w*.45,0,0,TAU);app.ctx.fill();
    poly([[bx-w,by],[bx,by+w*.4],[tx,ty]],lg([tx,ty],[bx,by],[[0,'#ffe3f6'],[.4,'#ff8ee0'],[1,'#c23d9e']]),'rgba(120,20,90,.5)');
    poly([[bx,by+w*.4],[bx+w,by],[tx,ty]],lg([tx,ty],[bx+w,by],[[0,'#ffb3ea'],[1,'#7a1a62']]),'rgba(120,20,90,.5)');
    app.ctx.strokeStyle=`rgba(255,255,255,${.5*gl})`;app.ctx.lineWidth=.7;app.ctx.beginPath();app.ctx.moveTo(tx,ty);app.ctx.lineTo(bx-w*.4,by-h*.15);app.ctx.stroke()}
}
export function drawAstronaut(c,t){const[px,py]=P(c.x,c.y);app.ctx.save();app.ctx.translate(px,py);app.ctx.scale(.8,.8);drawAstronaut0(c,t);app.ctx.restore()}
function drawAstronaut0(c,t){
  const st=Math.sin(t*9+c.x*5),y=-Math.abs(st)*.8;
  app.ctx.strokeStyle='#d6dce0';app.ctx.lineWidth=1.6;app.ctx.lineCap='round';app.ctx.beginPath();app.ctx.moveTo(-1.1,-3+y);app.ctx.lineTo(-1.1-st,-.6);app.ctx.moveTo(1.1,-3+y);app.ctx.lineTo(1.1+st,-.6);app.ctx.stroke();app.ctx.lineCap='butt';
  app.ctx.fillStyle='#4a525a';app.ctx.fillRect(-2.1-st,-1,1.9,1.1);app.ctx.fillRect(.3+st,-1,1.9,1.1);
  app.ctx.fillStyle=lg([-3.8,0],[-1.6,0],[[0,'#c3cbd0'],[1,'#8e989f']]);app.ctx.fillRect(-3.8,-9.4+y,2.1,5.2);
  app.ctx.fillStyle=lg([-2.4,0],[2.6,0],[[0,'#ffffff'],[1,'#b5bec4']]);app.ctx.beginPath();app.ctx.roundRect?app.ctx.roundRect(-2.4,-9.1+y,4.8,6.4,1.5):app.ctx.rect(-2.4,-9.1+y,4.8,6.4);app.ctx.fill();
  app.ctx.fillStyle=c.c;app.ctx.fillRect(-2.4,-7.8+y,4.8,.8);
  app.ctx.fillStyle='#2ee6ff';app.ctx.fillRect(.3,-6.4+y,1.3,.9);
  app.ctx.fillStyle=lg([-2,-13+y],[2.5,-9+y],[[0,'#ffffff'],[1,'#c9d0d4']]);app.ctx.beginPath();app.ctx.arc(0,-11+y,2.9,0,TAU);app.ctx.fill();
  app.ctx.fillStyle=lg([0,-12.3+y],[2,-9.6+y],[[0,'#ffe09a'],[.5,'#d98a2a'],[1,'#4a2a08']]);app.ctx.beginPath();app.ctx.ellipse(.9,-10.9+y,1.9,1.5,0,0,TAU);app.ctx.fill();
  app.ctx.fillStyle='rgba(255,255,255,.85)';app.ctx.beginPath();app.ctx.ellipse(.3,-11.6+y,.6,.35,-.4,0,TAU);app.ctx.fill();
}
