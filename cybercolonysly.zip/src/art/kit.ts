// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** Drawing kit: the colour look, world ground palettes, lit materials, neon, glass */
import * as W from '../sim/worlds';
import { TAU } from '../sim/defs';
import { app } from '../game/state';
import { $, HH, HW, P, clamp, closeSheet, rng } from '../game/env';
import { WD, WORLD, save } from '../game/colony';

/* ---------- drawing helpers (lit materials) ---------- */
/* the colony look: building shading, accents, neon, glass glow and the Mars ground (other worlds swap the ground) */
export const TH={sand:[208,130,88],rock:[132,72,52],haze:[190,126,94],out:'rgba(40,24,18,.32)',shL:'#7a4630',shR:'#5a3020',top:'#c98a66',mixR:.5,mixT:.18,teal:'#efb6d2',teald:'#c98aaa',
    neon:['#ffc4e4','#ffd6b8','#e2d4ff','#ff9fd0','#cdb8ff','#ffdcf0'],warm:['#fff6fb','#ffd6ec','#e9a8cf'],dim:['#efe2ec','#b99ab4'],sat:1,slope:.55,lo:.6,hi:1.35,tile:['#e9a67a','rgba(140,70,45,.3)']};
/* the world this device plays: Mars keeps the colony ground, other worlds bring their own */
if(WORLD!=='mars')Object.assign(TH,{sand:WD.sand,rock:WD.rock,haze:WD.haze,patch:null,tile:['rgb('+WD.sand+')','rgba(30,32,40,.3)']});
document.documentElement.dataset.world=WORLD;
export function goWorld(w){if(w===WORLD){closeSheet();$('intro').hidden=true;save();return}
  try{localStorage.setItem(W.WORLD_KEY,w);sessionStorage.setItem('dustfall-land','1')}catch(e){}if($('intro').hidden)save();location.reload()}
export const OUT=TH.out;
export function hex(c){if(c[0]==='#'){const n=parseInt(c.slice(1),16);return[n>>16&255,n>>8&255,n&255]}const m=/^rgb\((\d+),\s*(\d+),\s*(\d+)\)/.exec(c);return m?[+m[1],+m[2],+m[3]]:null}
export function mix(c,t){const v=hex(c);if(!v)return c;const k=t>=0?255:0,a=Math.abs(t);return`rgb(${Math.round(v[0]+(k-v[0])*a)},${Math.round(v[1]+(k-v[1])*a)},${Math.round(v[2]+(k-v[2])*a)})`}
export function mixC(c1,c2,t){const a=hex(c1),b=hex(c2);if(!a||!b)return c1;return`rgb(${Math.round(a[0]+(b[0]-a[0])*t)},${Math.round(a[1]+(b[1]-a[1])*t)},${Math.round(a[2]+(b[2]-a[2])*t)})`}
app.TEX=false;app.NOISE=null;
export function lg(a,b,stops){const g=app.ctx.createLinearGradient(a[0],a[1],b[0],b[1]);stops.forEach(([o,c])=>g.addColorStop(o,c));return g}
export function poly(pts,fill,stroke){app.ctx.beginPath();for(let i=0;i<pts.length;i++){const p=pts[i];i?app.ctx.lineTo(p[0],p[1]):app.ctx.moveTo(p[0],p[1])}app.ctx.closePath();
  if(fill){app.ctx.fillStyle=fill;app.ctx.fill()}if(stroke!==false){app.ctx.strokeStyle=stroke||OUT;app.ctx.lineWidth=.8;app.ctx.stroke()}}
export function line(a,b,c,w){app.ctx.strokeStyle=c;app.ctx.lineWidth=w||1;app.ctx.beginPath();app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(b[0],b[1]);app.ctx.stroke()}
/* box with sunlight from the upper left: left wall lit, right wall in shade, soft darkening toward the ground */
export function prism(x0,y0,x1,y1,z,h,top,l,r,opt){
  const A=P(x0,y0,z+h),B=P(x1,y0,z+h),C=P(x1,y1,z+h),D=P(x0,y1,z+h),Cb=P(x1,y1,z),Db=P(x0,y1,z),Bb=P(x1,y0,z);
  const flat=hex(l)===null;
  poly([Db,Cb,C,D],flat?l:lg(D,Db,[[0,mix(l,.08)],[.6,l],[1,mixC(l,TH.shL,.45)]]));
  poly([Cb,Bb,B,C],flat?r:lg(C,Cb,[[0,mix(r,.04)],[.6,r],[1,mixC(r,TH.shR,TH.mixR??.55)]]));
  poly([A,B,C,D],flat?top:lg(A,C,[[0,mix(top,.12)],[.7,mix(top,-.02)],[1,mixC(top,TH.top,TH.mixT??.2)]]));
  if(!(opt&&opt.noEdge)&&h>1.5){app.ctx.strokeStyle='rgba(255,255,255,.55)';app.ctx.lineWidth=.9;app.ctx.beginPath();app.ctx.moveTo(D[0],D[1]);app.ctx.lineTo(C[0],C[1]);app.ctx.lineTo(B[0],B[1]);app.ctx.stroke();
    line(C,[C[0],C[1]+1.5],'rgba(255,255,255,.4)',1)}
}
/* vertical panel seams on both visible walls */
function seams(x0,y0,x1,y1,z,h,n){
  app.ctx.strokeStyle='rgba(60,70,80,.18)';app.ctx.lineWidth=.7;app.ctx.beginPath();
  for(let i=1;i<n;i++){const u=x0+(x1-x0)*i/n,a=P(u,y1,z),b=P(u,y1,z+h);app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(b[0],b[1]);
    const v=y1-(y1-y0)*i/n,c=P(x1,v,z),d=P(x1,v,z+h);app.ctx.moveTo(c[0],c[1]);app.ctx.lineTo(d[0],d[1])}
  app.ctx.stroke();
}
/* framed window: dark frame, glass gradient, glare; lit=warm interior light */
function winQuad(p,lit){
  poly(p,'#c9d0d3',false);
  const ins=[0,1,2,3].map(i=>{const q=p[i],o=p[(i+2)%4];return[q[0]+(o[0]-q[0])*.12,q[1]+(o[1]-q[1])*.12]});
  poly(ins,lit?lg(ins[0],ins[3],[[0,'#fff3dc'],[.55,'#ffd38f'],[1,'#e9a35a']]):lg(ins[0],ins[3],[[0,'#a8968a'],[.55,'#4a3d34'],[1,'#2a221d']]),false);if(lit&&!app.thumbMode)litQ(ins);
  app.ctx.strokeStyle='rgba(255,255,255,.45)';app.ctx.lineWidth=.7;app.ctx.beginPath();app.ctx.moveTo(ins[3][0],ins[3][1]);app.ctx.lineTo(ins[1][0]+(ins[3][0]-ins[1][0])*.45,ins[1][1]+(ins[3][1]-ins[1][1])*.45);app.ctx.stroke();
}
export function winL(x0,x1,y,z0,z1,lit){winQuad([P(x0,y,z1),P(x1,y,z1),P(x1,y,z0),P(x0,y,z0)],lit)}
function winR(y0,y1,x,z0,z1,lit){winQuad([P(x,y0,z1),P(x,y1,z1),P(x,y1,z0),P(x,y0,z0)],lit)}
/* metal cylinder with a specular stripe */
export function cyl(cx,cy,r,z,h,top,side){
  const[x,y]=P(cx,cy,z);const rx=r*HW*1.414,ry=r*HH*1.414;
  app.ctx.beginPath();app.ctx.moveTo(x-rx,y);app.ctx.lineTo(x-rx,y-h);app.ctx.ellipse(x,y-h,rx,ry,0,Math.PI,0,true);app.ctx.lineTo(x+rx,y);app.ctx.ellipse(x,y,rx,ry,0,0,Math.PI);app.ctx.closePath();
  app.ctx.fillStyle=lg([x-rx,0],[x+rx,0],[[0,mix(side,-.05)],[.28,mix(side,.35)],[.42,mix(side,.1)],[1,mix(side,-.38)]]);app.ctx.fill();app.ctx.strokeStyle=OUT;app.ctx.lineWidth=.8;app.ctx.stroke();
  app.ctx.beginPath();app.ctx.ellipse(x,y-h,rx,ry,0,0,TAU);app.ctx.fillStyle=lg([x-rx,y-h-ry],[x+rx,y-h+ry],[[0,mix(top,.25)],[1,mix(top,-.12)]]);app.ctx.fill();app.ctx.stroke();
}
export function ring(cx,cy,r,z,c){const[x,y]=P(cx,cy,z);const rx=r*HW*1.414,ry=r*HH*1.414;app.ctx.strokeStyle=c;app.ctx.lineWidth=1.6;app.ctx.beginPath();app.ctx.ellipse(x,y,rx,ry,0,0,Math.PI);app.ctx.stroke()}
/* glass dome with ribs and reflection */
export function dome(cx,cy,r,z,tint,ribs){
  const[x,y]=P(cx,cy,z);const rx=r*HW*1.414,ry=r*HH*1.414,hz=rx*.85;
  app.ctx.beginPath();app.ctx.ellipse(x,y,rx,hz,0,Math.PI,0);app.ctx.ellipse(x,y,rx,ry,0,0,Math.PI);app.ctx.closePath();
  const g=app.ctx.createRadialGradient(x-rx*.35,y-hz*.6,rx*.05,x,y-hz*.2,rx*1.15);
  g.addColorStop(0,'rgba(255,255,255,.95)');g.addColorStop(.25,tint);g.addColorStop(1,mix('#1d4a56',0));
  app.ctx.fillStyle=g;app.ctx.globalAlpha*=.9;app.ctx.fill();app.ctx.globalAlpha/=.9;app.ctx.strokeStyle='rgba(30,50,60,.5)';app.ctx.lineWidth=.9;app.ctx.stroke();
  if(ribs){app.ctx.save();app.ctx.beginPath();app.ctx.ellipse(x,y,rx,hz,0,Math.PI,0);app.ctx.ellipse(x,y,rx,ry,0,0,Math.PI);app.ctx.clip();
    app.ctx.strokeStyle='rgba(230,245,250,.55)';app.ctx.lineWidth=.8;
    for(let i=1;i<ribs;i++){const k=-1+2*i/ribs;app.ctx.beginPath();app.ctx.ellipse(x,y,Math.abs(k)*rx+.01,hz,0,Math.PI,0);app.ctx.stroke()}
    for(const f of[.35,.68]){app.ctx.beginPath();app.ctx.ellipse(x,y-hz*f,rx*Math.sqrt(1-f*f),ry*Math.sqrt(1-f*f),0,0,Math.PI);app.ctx.stroke()}
    app.ctx.restore()}
  app.ctx.fillStyle='rgba(255,255,255,.55)';app.ctx.beginPath();app.ctx.ellipse(x-rx*.38,y-hz*.55,rx*.18,hz*.1,-.7,0,TAU);app.ctx.fill();
}
/* panelled geodesic dome: rings of white panels, each with an inset hexagonal window, some lit. Light from the upper left, back panels culled */
export function geodome(cx,cy,R,z,seed){
  const H=R*HW*1.414*.85,pt=(f,a)=>P(cx+R*Math.cos(f)*Math.cos(a),cy+R*Math.cos(f)*Math.sin(a),z+H*Math.sin(f));
  const rings=[[0,.42,11],[.42,.84,9],[.84,1.22,6]],rr=rng(seed),fs=[];
  rings.forEach(([f0,f1,n],ri)=>{const off=ri%2?Math.PI/n:0;for(let j=0;j<n;j++){const a0=off+j*TAU/n,a1=a0+TAU/n,fm=(f0+f1)/2,am=(a0+a1)/2;
    fs.push({q:[pt(f0,a0),pt(f0,am),pt(f0,a1),pt(f1,a1),pt(f1,am),pt(f1,a0)],f:fm,a:am,lit:rr()<.45})}});
  {const f=1.22,n=6,q=[];for(let j=0;j<n;j++)q.push(pt(f,j*TAU/n));fs.push({q,f:Math.PI/2,a:0,lit:rr()<.6,cap:true})}
  const vis=e=>Math.cos(e.f)*(Math.cos(e.a)+Math.sin(e.a))*.7+Math.sin(e.f)*.8;
  for(const e of fs.filter(e=>vis(e)>.02).sort((a,b)=>vis(a)-vis(b))){
    const nx=Math.cos(e.f)*Math.cos(e.a),ny=Math.cos(e.f)*Math.sin(e.a),nz=Math.sin(e.f),lam=clamp(.62+.42*(-.35*nx+.7*ny+.6*nz),.38,1);
    poly(e.q,mixC('#ffffff','#9aa6ae',1-lam),'rgba(120,132,142,.45)');
    const c=e.q.reduce((m,p)=>[m[0]+p[0]/e.q.length,m[1]+p[1]/e.q.length],[0,0]),w=e.q.map(p=>[c[0]+(p[0]-c[0])*.5,c[1]+(p[1]-c[1])*.5]);
    if(e.lit){poly(w,lg(w[0],w[3]||w[2],[[0,'#ecfbff'],[1,'#7fd3f5']]),'rgba(40,110,150,.45)');litQ(w)}
    else poly(w,mixC('#9fd4ec','#3f7fa6',1-lam),'rgba(30,70,100,.45)');
  }
}
export function pad(x0,y0,x1,y1){patio(x0,y0,x1,y1);return;prism(x0,y0,x1,y1,0,2,'#cfccc6','#aaa59d','#8f8a83',{noEdge:true});
  app.ctx.strokeStyle='rgba(80,70,60,.25)';app.ctx.lineWidth=.6;app.ctx.beginPath();const m=(x0+x1)/2,n=(y0+y1)/2;let a=P(m,y0,2),b=P(m,y1,2);app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(b[0],b[1]);a=P(x0,n,2);b=P(x1,n,2);app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(b[0],b[1]);app.ctx.stroke()}
function unit(x,y,z,w){prism(x,y,x+w,y+w,z,w*16,'#dfe3e2','#c3c9ca','#9fa8ab');const[c,d]=P(x+w/2,y+w/2,z+w*16);app.ctx.fillStyle='#55606a';app.ctx.beginPath();app.ctx.ellipse(c,d,w*14,w*7,0,0,TAU);app.ctx.fill()}
export function lattice(base,top,w,steps,c){
  const L1=[base[0]-w,base[1]],R1=[base[0]+w,base[1]],L2=[top[0]-w*.3,top[1]],R2=[top[0]+w*.3,top[1]];
  line(L1,L2,c,1.6);line(R1,R2,c,1.6);
  app.ctx.strokeStyle=c;app.ctx.lineWidth=.8;app.ctx.beginPath();
  for(let i=0;i<steps;i++){const f0=i/steps,f1=(i+1)/steps;const l0=[L1[0]+(L2[0]-L1[0])*f0,L1[1]+(L2[1]-L1[1])*f0],r0=[R1[0]+(R2[0]-R1[0])*f0,R1[1]+(R2[1]-R1[1])*f0],
    l1=[L1[0]+(L2[0]-L1[0])*f1,L1[1]+(L2[1]-L1[1])*f1],r1=[R1[0]+(R2[0]-R1[0])*f1,R1[1]+(R2[1]-R1[1])*f1];
    app.ctx.moveTo(l0[0],l0[1]);app.ctx.lineTo(r1[0],r1[1]);app.ctx.moveTo(r0[0],r0[1]);app.ctx.lineTo(l1[0],l1[1]);app.ctx.moveTo(l1[0],l1[1]);app.ctx.lineTo(r1[0],r1[1])}
  app.ctx.stroke();
}
function hazard(x0,x1,y,z,h){const n=8;for(let i=0;i<n;i++){const a=x0+(x1-x0)*i/n,b=x0+(x1-x0)*(i+1)/n;poly([P(a,y,z+h),P(b,y,z+h),P(b,y,z),P(a,y,z)],i%2?'#2b2b2b':'#f2b632',false)}}
export const W1='#ffffff',W2='#f2f4f5',W3='#c9d1d5',TEAL=TH.teal,TEALD=TH.teald,MET='#b9c1c5';
/* ---------- futuristic kit: neon light strips, octagonal extrusions, glass curtain walls ---------- */
export const[NEONC,AMBER,GREENN,PINKN,PURPN,BLUEN]=TH.neon;
export const GR1='#e7e3dd',GR2='#dcd7cf',GR3='#bdb7ae';
/* Night mask: drawBuilding runs again on a context that turns every paint black, except lit windows and neon.
   Paint order then hides whatever a building's own later parts cover, so no window shows through. */
app.EMIT=0;app.MASK=false;
export function blackout(c){return new Proxy(c,{
  get(o,k){const v=o[k];if(typeof v!=='function')return v;
    if(k==='createLinearGradient'||k==='createRadialGradient')return(...a)=>{const g=v.apply(o,a),add=g.addColorStop.bind(g);
      g.addColorStop=(p,col)=>{if(/rgba\(.*,\s*(0|0?\.\d+)\)/.test(col))g.soft=true;add(p,col)};return g};
    return v.bind(o)},
  set(o,k,v){if((k==='fillStyle'||k==='strokeStyle')&&!app.EMIT){const m=typeof v==='string'&&/^rgba\(.*,\s*([\d.]+)\)/.exec(v);
      v=m?`rgba(0,0,0,${m[1]})`:(v instanceof CanvasGradient&&v.soft)?'rgba(0,0,0,0)':'#000'}
    o[k]=v;return true}})}
export function litQ(q){if(!app.MASK)return;const gc=app.ctx.globalCompositeOperation;app.EMIT++;app.ctx.globalCompositeOperation='source-atop';poly(q,'#ffcd96',false);app.ctx.globalCompositeOperation=gc;app.EMIT--}
export function neon(a,b,c,w){if(app.MASK&&!app.TEX)return;if(app.MASK)app.EMIT++;c=c||NEONC;w=w||1.2;const pc=app.ctx.globalCompositeOperation,ga=app.ctx.globalAlpha;
  app.ctx.globalCompositeOperation='lighter';app.ctx.lineCap='round';
  app.ctx.globalAlpha=ga*.3;line(a,b,c,w*3.4);app.ctx.globalAlpha=ga;line(a,b,c,w);app.ctx.globalAlpha=ga*.8;line(a,b,'#ffffff',w*.35);
  app.ctx.globalCompositeOperation=pc;app.ctx.globalAlpha=ga;app.ctx.lineCap='butt';if(app.MASK)app.EMIT--}
export function neonArc(cx,cy,r,z,c,w){const[x,y]=P(cx,cy,z);const rx=r*HW*1.414,ry=r*HH*1.414;let prev=null;
  for(let i=0;i<=12;i++){const a=i/12*Math.PI,p=[x+Math.cos(a)*rx,y+Math.sin(a)*ry];if(prev)neon(prev,p,c,w);prev=p}}
export function oct(x0,y0,x1,y1,c){return rrect(x0,y0,x1,y1,Math.min(c*1.05,(x1-x0)/2-.001,(y1-y0)/2-.001),3)}
function oct0(x0,y0,x1,y1,c){return[[x0+c,y0],[x1-c,y0],[x1,y0+c],[x1,y1-c],[x1-c,y1],[x0+c,y1],[x0,y1-c],[x0,y0+c]]}
export function ngon(cx,cy,r,n,rot){const o=[];for(let i=0;i<n;i++){const a=rot+i/n*TAU;o.push([cx+Math.cos(a)*r,cy+Math.sin(a)*r])}return o}
/* faces of a convex footprint that point toward the viewer; f runs from lit (0) to shaded (1) */
export function faces(pts){
  let cx=0,cy=0;for(const p of pts){cx+=p[0];cy+=p[1]}cx/=pts.length;cy/=pts.length;
  const out=[];for(let i=0;i<pts.length;i++){const a=pts[i],b=pts[(i+1)%pts.length];let nx=b[1]-a[1],ny=-(b[0]-a[0]);
    const mx=(a[0]+b[0])/2-cx,my=(a[1]+b[1])/2-cy;if(nx*mx+ny*my<0){nx=-nx;ny=-ny}
    const l=Math.hypot(nx,ny)||1;nx/=l;ny/=l;if(nx+ny>.02)out.push({i,a,b,f:clamp(Math.max(0,nx)/(Math.max(0,nx)+Math.max(0,ny)),0,1)})}
  return out}
export function extrude(pts,z,h,top,l,r,opt){
  const F=faces(pts);
  for(const f of F){const c=mixC(l,r,f.f);const A=P(f.a[0],f.a[1],z+h),B=P(f.b[0],f.b[1],z+h),Bb=P(f.b[0],f.b[1],z),Ab=P(f.a[0],f.a[1],z);
    const gr=lg([0,A[1]],[0,Ab[1]+.01],[[0,mix(c,.07)],[.6,c],[1,mixC(c,'#6a4030',z<3?.38:.12)]]);
    if((opt&&opt.smooth)||pts.length>8){poly([Ab,Bb,B,A],gr,false);app.ctx.strokeStyle=gr;app.ctx.lineWidth=.7;app.ctx.stroke()}else poly([Ab,Bb,B,A],gr)}
  const T=pts.map(p=>P(p[0],p[1],z+h));poly(T,lg(T[0],T[Math.floor(T.length/2)],[[0,mix(top,.14)],[1,mix(top,-.06)]]));
  if(!(opt&&opt.noEdge)&&h>1.5){app.ctx.strokeStyle='rgba(255,255,255,.55)';app.ctx.lineWidth=.8;app.ctx.beginPath();for(const f of F){const A=P(f.a[0],f.a[1],z+h),B=P(f.b[0],f.b[1],z+h);app.ctx.moveTo(A[0],A[1]);app.ctx.lineTo(B[0],B[1])}app.ctx.stroke()}
}
export function neonEdges(pts,z,c,w){for(const f of faces(pts))neon(P(f.a[0],f.a[1],z),P(f.b[0],f.b[1],z),c,w)}
/* glass curtain wall: panes split by thin white mullions, a few lit from inside */
export function glassBand(pts,z0,z1,seed,step){
  for(const f of faces(pts)){const len=Math.hypot(f.b[0]-f.a[0],f.b[1]-f.a[1]);const n=Math.max(1,Math.round(len/(step||.16)));
    const at=u=>[f.a[0]+(f.b[0]-f.a[0])*u,f.a[1]+(f.b[1]-f.a[1])*u];
    for(let k=0;k<n;k++){const u0=.05+(k/n)*.9+.006,u1=.05+((k+1)/n)*.9-.006;const pa=at(u0),pb=at(u1);
      const q=[P(pa[0],pa[1],z1),P(pb[0],pb[1],z1),P(pb[0],pb[1],z0),P(pa[0],pa[1],z0)];
      const lit=seed<0||((f.i*7+k*13+seed*5)%6!==0);
      poly(q,lit?WARM(q,false):lg(q[0],q[3],[[0,f.f>.5?'#cdbfb2':'#e2d6ca'],[.5,'#9c8a7a'],[1,'#6e5d50']]),false);if(lit&&!app.thumbMode)litQ(q);
      if(!lit&&k%3===1){app.ctx.strokeStyle='rgba(255,255,255,.22)';app.ctx.lineWidth=1.2;app.ctx.beginPath();app.ctx.moveTo(q[0][0]+(q[1][0]-q[0][0])*.2,q[0][1]+(q[1][1]-q[0][1])*.2+1);app.ctx.lineTo(q[3][0]+(q[2][0]-q[3][0])*.7,q[3][1]+(q[2][1]-q[3][1])*.7-1);app.ctx.stroke()}}
    const A0=at(.05),A1=at(.95);app.ctx.strokeStyle='rgba(255,255,255,.95)';app.ctx.lineWidth=1;app.ctx.beginPath();
    for(const z of[z0,z1]){const p=P(A0[0],A0[1],z),q=P(A1[0],A1[1],z);app.ctx.moveTo(p[0],p[1]);app.ctx.lineTo(q[0],q[1])}app.ctx.stroke()}
}


/* cast shadows: light from the upper left, so shadows stretch along +x on the ground */
export const SH_H={bank:.6,fashion:.5,lab:.55,missile:.4,reactor:1.05,hq:1.15,habitat:.45,solar:.25,extractor:.65,greenhouse:.45,mine:.8,drill:1.05,storage:.35,turret:.4,hangar:.85,railgun:.5,elevator:1.6,shieldgen:.6,terraform:.8,spaceport:.7,ring:1.2,mirror:1.2};
export function rrect(x0,y0,x1,y1,r,n){n=n||3;const c=[[x1-r,y0+r,-Math.PI/2],[x1-r,y1-r,0],[x0+r,y1-r,Math.PI/2],[x0+r,y0+r,Math.PI]];const o=[];
  for(const[cx,cy,a0]of c)for(let i=0;i<=n;i++){const a=a0+i/n*Math.PI/2;o.push([cx+Math.cos(a)*r,cy+Math.sin(a)*r])}return o}
export const WARM=(q,dim)=>lg(q[0],q[3],dim?[[0,TH.dim[0]],[1,TH.dim[1]]]:[[0,TH.warm[0]],[.55,TH.warm[1]],[1,TH.warm[2]]]);
export function patio(x0,y0,x1,y1){prism(x0,y0,x1,y1,0,1.6,'#dcd9d3','#b8b3ab','#9a958e',{noEdge:true});
  app.ctx.strokeStyle='rgba(120,110,100,.22)';app.ctx.lineWidth=.6;app.ctx.beginPath();for(let i=1;i<4;i++){const u=x0+(x1-x0)*i/4;let a=P(u,y0,1.6),b=P(u,y1,1.6);app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(b[0],b[1]);const v=y0+(y1-y0)*i/4;a=P(x0,v,1.6);b=P(x1,v,1.6);app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(b[0],b[1])}app.ctx.stroke()}
