// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** Daylight, ambient life (dust devils, rovers), drones, missiles and ships */
import { DEF, N, TAU } from '../sim/defs';
import { droneZ } from '../sim/raids';
import { app } from '../game/state';
import { HH, HW, P } from '../game/env';
import { area, occAt } from '../game/colony';
import { extrude, faces, hex, lg, line, poly, rrect } from './kit';
import { bHeight, frigate, picOf, hqDims, hqDimsG, hqDimsV, hqStyle, warmFaces } from './buildings';

export function collectLights(t){
  const L=[],G=[];
  const add=(p,r,c,a,arr)=>{(arr||L).push([p[0],p[1],r,c,a])};
  for(const b of app.S.b){const d=DEF[b.type],s=d.size,cx=b.gx+s/2,cy=b.gy+s/2,lv=Math.min(b.lvl,5);
    if(b.state==='building'||b.state==='repair'||b.upg>0){add(P(cx,cy,10),60*s,[225,238,255],.85);continue}
    if(b.state==='damaged'){add(P(cx,cy,8),40*s,[255,120,40],.5+.25*Math.sin(t*13+b.id));continue}
    add(P(cx,cy,4),(b.type==='hq'?62:30*s)+5*lv,[255,188,118],.5);
    if(b.type==='turret'||b.type==='missile'){const p=P(cx,cy,18);add(p,22,[255,214,150],.7);add(p,4,[255,236,200],.9,G)}
    if(b.type==='drill'){const p=picOf(b)?P(cx,cy,bHeight(b)*.8):P(cx+.08,cy+.08,46+Math.min(b.lvl,6)*4);add(p,34,[255,110,220],.8);add(p,7,[255,160,235],1,G)}
    if(b.type==='greenhouse'){add(P(cx,cy,12),48,[210,140,255],.75);add(P(cx,cy,12),30,[140,255,180],.4)}
    if(b.type==='reactor')add(P(b.gx+1.38,b.gy+1.38,6),80,[110,200,255],.6);
    if(b.type==='bank'){const k=Math.floor(t*5+b.id)%3;add(P(cx,cy,8),58,[255,201,74],.8);add(P(cx,cy,34),30,[255,201,74],.6+.3*Math.sin(t*5));for(let i=0;i<3;i++){const p=P(b.gx+.2+i*.3,b.gy+1,2);add(p,i===k?16:7,[255,214,120],i===k?.9:.4);add(p,2,[255,236,190],1,G)}}
    if(b.type==='fashion')add(P(cx,cy,8),50,[255,190,200],.65);
    if(b.type==='lab'){add(P(cx,cy,8),46,[255,200,140],.7);if(b.lvl>=3)add(P(b.gx+.65,b.gy+.65,36),22,[255,220,170],.7)}
    if(b.type==='hq'){const st=hqStyle(b);if(st==='spire'){const H=hqDims(b.lvl);add(P(b.gx+1,b.gy+1,6),80,[255,205,145],.75);add(P(b.gx+1,b.gy+1,H.zt*.55),70,[255,200,140],.5);add(P(b.gx+1,b.gy+1,H.zt*.85),40,[255,214,150],.4);if(b.lvl>=6){const sb=P(b.gx+1,b.gy+1,H.zt-2);if(Math.floor(t*1.5)%2)add([sb[0],sb[1]-25],4,[255,60,70],1,G)}}else{const top=st==='villa'?hqDimsV(b.lvl).zt:st==='glass'?hqDimsG(b.lvl).top:bHeight(b);add(P(b.gx+1,b.gy+1,6),80,[255,205,145],.75);add(P(b.gx+1,b.gy+1,top*.55),70,[255,214,150],.45)}}
    if(b.type==='hangar'&&b.style==='classic'){add(P(b.gx+1.6,b.gy+.87,8),70,[255,200,140],.75);const k=Math.floor(t*6)%6,v=b.gy+.12+(1.48)*k/5,p=P(b.gx+1.94,v,1.8);add(p,3,[255,236,190],1,G);add(p,18,[255,214,150],.5);if(b.lvl>=2)add(P(b.gx+.27,b.gy+1.8,26+Math.min(b.lvl,6)*2+4),26,[255,200,140],.6)}
    else if(b.type==='hangar'){add(P(b.gx+.8,b.gy+1.8,10),60,[255,200,140],.7)} // the open door of the painted hangar
  }
  for(let x=0;x<N;x++)for(let y=0;y<N;y++)if(app.tiles[x][y].t==='crystal'&&!occAt(x,y))add(P(x+.5,y+.5,4),30,[255,110,220],.6);
  for(const c of app.colonists)add(P(c.x,c.y,6),12,[255,236,200],.5);
  if(app.PATHS)for(const[x,y]of app.PATHS.lamps){const[bx,by]=P(x,y);add([bx+3,by-2],34,[255,214,150],.8);add([bx+4.6,by-18.6],3,[255,236,190],1,G)}
  const A=area();for(const[x,y]of[[A.a,A.a],[A.b,A.a],[A.b,A.b],[A.a,A.b]]){if(Math.floor(t*1.5+x)%2){const p=P(x,y,12);add(p,3,[255,70,70],1,G);add(p,18,[255,70,70],.5)}}
  for(const d of app.drones){const z=droneZ(d);add(P(d.x,d.y,0),30*d.size,[255,90,90],.4);add(P(d.x,d.y,z),5*d.size,[255,60,70],1,G);add(P(d.x,d.y,z),26*d.size,[255,60,70],.6)}
  for(const m of app.missiles){const p=P(m.x,m.y,m.z);add(p,34,[255,190,110],.9);add(p,5,[255,220,160],1,G)}
  for(const v of app.rovers){const{pt}=roverFrame(v);add(P(...pt(.42,0),2),30,[255,244,220],.7);add(P(...pt(.21,0),4.6),2.2,[255,250,235],1,G);add(P(...pt(-.21,0),4.6),9,[255,60,70],.5)}
  for(const f of app.fx){
    if(f.k==='flash'){const c=f.c||[255,215,160];add(P(f.x,f.y,f.z),160*f.r,c,Math.min(1,f.t*6))}
    else if(f.k==='fire')add(P(f.x,f.y,f.z),120*f.r*3,[255,140,50],.9*f.t/f.max);
    else if(f.k==='beam'){add(P((f.x1+f.x2)/2,(f.y1+f.y2)/2,(f.z1+f.z2)/2),36,hex(f.c)||[255,255,255],.45)}
  }
  if(app.mission){const p=missionPos();add(p,40,[255,170,90],.8);add(p,5,[255,220,160],1,G)}
  return{L,G};
}

/* ---------- ambient: dust devils and supply rovers ---------- */
app.rovers=[];
export function updAmbient(dt){
  if(app.saver)app.devils.length=0;
  app.devilT-=dt;if(!app.saver&&app.devilT<=0&&app.devils.length<2){app.devilT=25+Math.random()*40;
    const fromLeft=Math.random()<.5,u=-2+Math.random()*(N+4);
    app.devils.push(fromLeft?{x:-5,y:u,vx:.55+Math.random()*.3,vy:(Math.random()-.5)*.3,life:0,max:34}:{x:u,y:-5,vx:(Math.random()-.5)*.3,vy:.55+Math.random()*.3,life:0,max:34})}
  for(let i=app.devils.length-1;i>=0;i--){const d=app.devils[i];d.life+=dt;d.x+=d.vx*dt+Math.sin(d.life*.7)*.2*dt;d.y+=d.vy*dt+Math.cos(d.life*.6)*.2*dt;if(d.life>d.max)app.devils.splice(i,1)}
  // one rover per few buildings drives between them
  const want=Math.min(4,Math.floor(app.S.b.filter(b=>b.state==='active').length/4));
  while(app.rovers.length<want){const b=app.S.b[Math.floor(Math.random()*app.S.b.length)];app.rovers.push({x:b.gx-.4,y:b.gy+.5,tx:b.gx,ty:b.gy,a:0,wait:Math.random()*3})}
  app.rovers.length=Math.max(0,Math.min(app.rovers.length,want));
  for(const v of app.rovers){
    if(v.wait>0){v.wait-=dt;continue}
    const dx=v.tx-v.x,dy=v.ty-v.y,d=Math.hypot(dx,dy);
    if(d<.08){const b=app.S.b[Math.floor(Math.random()*app.S.b.length)];const s=DEF[b.type].size;const side=Math.floor(Math.random()*4);
      v.tx=side===0?b.gx-.35:side===1?b.gx+s+.35:b.gx+Math.random()*s;v.ty=side===2?b.gy-.35:side===3?b.gy+s+.35:b.gy+Math.random()*s;
      if(side<2)v.ty=b.gy+Math.random()*s;v.wait=1+Math.random()*3;continue}
    // drive along one axis at a time, like a road grid
    if(Math.random()<dt*6){const{pt}=roverFrame(v);const[px,py]=pt(-.24,(Math.random()-.5)*.2);app.fx.push({k:'smoke',x:px,y:py,z:1,t:.9,max:.9,r:.04,g:.06,c:[205,150,115],rise:3})}
    if(Math.abs(dx)>.05){v.x+=Math.sign(dx)*Math.min(Math.abs(dx),.9*dt);v.a=dx>0?0:Math.PI}else{v.y+=Math.sign(dy)*Math.min(Math.abs(dy),.9*dt);v.a=dy>0?Math.PI/2:-Math.PI/2}
  }
}
function drawDevil(d,t){
  const a=Math.min(1,d.life/4,(d.max-d.life)/4)*.6;if(a<=0)return;
  const[x,y]=P(d.x,d.y);
  let g=app.ctx.createRadialGradient(x,y,0,x,y,34);g.addColorStop(0,`rgba(205,140,100,${a*.45})`);g.addColorStop(1,'rgba(205,140,100,0)');
  app.ctx.save();app.ctx.translate(0,y*.5);app.ctx.scale(1,.5);app.ctx.fillStyle=g;app.ctx.beginPath();app.ctx.arc(x,y,34,0,TAU);app.ctx.fill();app.ctx.restore();
  for(let i=0;i<14;i++){const f=i/13,yy=y-f*92,rx=4+f*f*26+f*6,off=Math.sin(t*2.2+f*5+d.x)*8*f;
    app.ctx.strokeStyle=`rgba(214,160,120,${a*(1-f*.6)*.55})`;app.ctx.lineWidth=2+f*3;app.ctx.beginPath();
    app.ctx.ellipse(x+off,yy,rx,rx*.32,0,(t*6+i)%TAU,(t*6+i)%TAU+Math.PI*1.3);app.ctx.stroke()}
}
export function roverFrame(v){const ax=Math.abs(Math.cos(v.a))>.5,dir=ax?Math.sign(Math.cos(v.a))||1:Math.sign(Math.sin(v.a))||1;
  return{ax,dir,pt:(f,sd)=>ax?[v.x+f*dir,v.y+sd]:[v.x+sd,v.y+f*dir]}}
export function drawRover(v,t){
  const{ax,dir,pt}=roverFrame(v),L=.2,W=.11,moving=v.wait<=0;
  const box=(f0,f1,s0,s1)=>{const a=pt(f0,s0),b=pt(f1,s1);return[Math.min(a[0],b[0]),Math.min(a[1],b[1]),Math.max(a[0],b[0]),Math.max(a[1],b[1])]};
  const wheel=(f,sd)=>{const[gx,gy]=pt(f,sd),[x,y]=P(gx,gy,2.4),spin=moving?t*12:0;
    app.ctx.fillStyle='#24262b';app.ctx.beginPath();app.ctx.ellipse(x,y,2.2,2.05,0,0,TAU);app.ctx.fill();
    app.ctx.fillStyle='#d6dcdf';app.ctx.beginPath();app.ctx.ellipse(x,y,.95,.88,0,0,TAU);app.ctx.fill();
    app.ctx.strokeStyle='#5a5f66';app.ctx.lineWidth=.5;app.ctx.beginPath();for(let k=0;k<3;k++){const a=spin+k*TAU/3;app.ctx.moveTo(x,y);app.ctx.lineTo(x+Math.cos(a)*1.8,y+Math.sin(a)*1.65)}app.ctx.stroke()};
  const fs=[-.14,0,.14];
  for(const f of fs)wheel(f,-W-.015);
  // suspension arms
  for(const sd of[-W,W])for(const f of fs){const a=P(...pt(f,sd*1.1),2.6),b=P(...pt(f*.8,sd*.8),4.2);line(a,b,'#8d969b',.8)}
  // body
  const[bx0,by0,bx1,by1]=box(-L,L,-W,W);const B=rrect(bx0,by0,bx1,by1,.05,3);
  extrude(B,3,3.6,'#ffffff','#f4f6f7','#c9d1d5',{smooth:true});
  {const F=faces(B);for(const fc of F)line(P(fc.a[0],fc.a[1],4.6),P(fc.b[0],fc.b[1],4.6),'#d8b98c',.9)}
  // glass cabin at the front
  const[cx0,cy0,cx1,cy1]=box(.01,L-.02,-W+.02,W-.02);const C=rrect(cx0,cy0,cx1,cy1,.04,3);
  warmFaces(C,6.6,9.6,.14,3);extrude(C,9.6,1.2,'#ffffff','#f4f6f7','#c9d1d5',{smooth:true});
  // rear deck: solar panel and a cargo pod
  {const[x0,y0,x1,y1]=box(-L+.03,-.03,-W+.025,W-.025);const q=[P(x0,y0,6.7),P(x1,y0,6.7),P(x1,y1,6.7),P(x0,y1,6.7)];poly(q,lg(q[0],q[2],[[0,'#3a5aa0'],[1,'#16234a']]),'#e2e6e8');
    app.ctx.strokeStyle='rgba(120,170,240,.4)';app.ctx.lineWidth=.35;app.ctx.beginPath();for(let k=1;k<3;k++){const u=x0+(x1-x0)*k/3,a=P(u,y0,6.7),b=P(u,y1,6.7);app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(b[0],b[1])}app.ctx.stroke()}
  // antenna
  {const a=P(...pt(-L+.03,W-.03),6.6);line(a,[a[0],a[1]-8],'#c9d0d3',.6);app.ctx.fillStyle=(Math.floor(t*2+v.x)%2)?'#ff4d5a':'#6a1a20';app.ctx.beginPath();app.ctx.arc(a[0],a[1]-8.4,.9,0,TAU);app.ctx.fill()}
  for(const f of fs)wheel(f,W+.015);
  // headlights and tail lights
  for(const sd of[-W*.6,W*.6]){const h=P(...pt(L+.002,sd),4.6);app.ctx.fillStyle='#fffbe8';app.ctx.beginPath();app.ctx.ellipse(h[0],h[1],1.1,.7,0,0,TAU);app.ctx.fill();
    const r=P(...pt(-L-.002,sd),4.6);app.ctx.fillStyle='#e0414c';app.ctx.beginPath();app.ctx.ellipse(r[0],r[1],.9,.55,0,0,TAU);app.ctx.fill()}
}

/* ---------- drones, missiles, ships ---------- */
export function drawDrone(d,t){
  const k=d.size,z=droneZ(d)+Math.sin(d.bob)*3*(d.kind==='boss'?.5:1);const[x,y]=P(d.x,d.y,z);const[sx,sy]=P(d.x,d.y);
  app.ctx.fillStyle='rgba(40,12,6,.25)';app.ctx.beginPath();app.ctx.ellipse(sx+z*.35,sy+2,11*k,4.5*k,0,0,TAU);app.ctx.fill();
  if(d.kind==='boss'){
    app.ctx.fillStyle='#22252c';app.ctx.beginPath();app.ctx.ellipse(x,y+3,26,9,0,0,TAU);app.ctx.fill();
    app.ctx.fillStyle=lg([x-32,y],[x+32,y],[[0,'#4b505b'],[.3,'#d3d8de'],[.5,'#8a909a'],[1,'#2e323a']]);app.ctx.beginPath();app.ctx.ellipse(x,y,32,10,0,0,TAU);app.ctx.fill();app.ctx.strokeStyle='rgba(0,0,0,.4)';app.ctx.lineWidth=1;app.ctx.stroke();
    app.ctx.strokeStyle='rgba(255,255,255,.25)';app.ctx.beginPath();app.ctx.ellipse(x,y-1,24,7,0,Math.PI,TAU);app.ctx.stroke();
    app.ctx.fillStyle=lg([x-10,y-16],[x+10,y],[[0,'#ffc2c6'],[.4,'#ff3b4c'],[1,'#7a0a18']]);app.ctx.beginPath();app.ctx.ellipse(x,y-3,14,11,0,Math.PI,TAU);app.ctx.closePath();app.ctx.fill();
    app.ctx.fillStyle='rgba(255,255,255,.55)';app.ctx.beginPath();app.ctx.ellipse(x-5,y-9,4,2,-.4,0,TAU);app.ctx.fill();
    for(let i=0;i<12;i++){const a=i/12*TAU+t*.8;const lx=x+Math.cos(a)*28,ly=y+Math.sin(a)*8;if(Math.sin(a)<-.2)continue;app.ctx.fillStyle=(i+Math.floor(t*4))%3?'#ff4d5a':'#ffd34a';app.ctx.beginPath();app.ctx.arc(lx,ly,1.8,0,TAU);app.ctx.fill()}
  }else{
    const c={heavy:'#ff3b4c',lancer:'#ffb547',siege:'#9a6bff'}[d.kind]||'#ff4d5e';
    const th=app.ctx.createRadialGradient(x-6*k,y+1*k,0,x-6*k,y+1*k,6*k);th.addColorStop(0,'rgba(255,120,80,.9)');th.addColorStop(1,'rgba(255,60,40,0)');
    app.ctx.fillStyle=th;app.ctx.beginPath();app.ctx.arc(x-6*k,y+1*k,6*k,0,TAU);app.ctx.fill();
    app.ctx.save();app.ctx.translate(x,y);app.ctx.scale(k,k*.62);app.ctx.lineWidth=.8/k;
    poly([[13,0],[-8,-10],[-4,0],[-8,10]],lg([-8,-10],[10,10],[[0,'#5a616e'],[.45,'#2a2f3a'],[1,'#0d0f14']]),'rgba(0,0,0,.7)');
    poly([[10,0],[-5,-3],[-5,3]],c,false);
    app.ctx.fillStyle='#ffb070';app.ctx.fillRect(-9,-6,2,2.4);app.ctx.fillRect(-9,3.6,2,2.4);
    if(d.kind==='heavy'){app.ctx.fillStyle='#15171c';app.ctx.fillRect(0,-9,8,1.6);app.ctx.fillRect(0,7.4,8,1.6)}
    if(d.kind==='siege'){app.ctx.strokeStyle='#c9b3ff';app.ctx.lineWidth=1.4;app.ctx.beginPath();app.ctx.ellipse(0,0,13,12,0,0,TAU);app.ctx.stroke()}
    app.ctx.restore();
    if(d.kind==='lancer'){app.ctx.strokeStyle='#ffe2a8';app.ctx.lineWidth=1.6;app.ctx.beginPath();app.ctx.moveTo(x+12*k,y);app.ctx.lineTo(x+20*k,y+1*k);app.ctx.stroke()}
    app.ctx.fillStyle='#ff2a3a';app.ctx.beginPath();app.ctx.arc(x+7*k,y,1.6*k,0,TAU);app.ctx.fill();app.ctx.fillStyle='#ffd0d4';app.ctx.beginPath();app.ctx.arc(x+6.6*k,y-.4*k,.55*k,0,TAU);app.ctx.fill();
  }
  if(d.flash>0){app.ctx.globalAlpha=d.flash*.55;app.ctx.fillStyle='#ffffff';app.ctx.beginPath();app.ctx.ellipse(x,y,(d.kind==='boss'?30:9*k),(d.kind==='boss'?10:5*k),0,0,TAU);app.ctx.fill();app.ctx.globalAlpha=1}
  if(d.hp<d.max){const w=d.kind==='boss'?50:20*k;app.ctx.fillStyle='rgba(0,0,0,.55)';app.ctx.fillRect(x-w/2,y-(d.kind==='boss'?24:13*k),w,3);app.ctx.fillStyle='#ff5a5f';app.ctx.fillRect(x-w/2,y-(d.kind==='boss'?24:13*k),w*d.hp/d.max,3)}
}
function drawMissile(m,t){
  const[x,y]=P(m.x,m.y,m.z);const ca=Math.cos(m.a||0),sa=Math.sin(m.a||0);
  let dx=(ca-sa)*HW,dy=(ca+sa)*HH-(m.t<.25?40:0);const l=Math.hypot(dx,dy)||1;dx/=l;dy/=l;
  app.ctx.lineCap='round';line([x-dx*6,y-dy*6],[x+dx*5,y+dy*5],'#e9edef',2.6);line([x+dx*3,y+dy*3],[x+dx*6,y+dy*6],'#d9454f',2.6);app.ctx.lineCap='butt';
  const f=3+Math.random()*2.5;const g=app.ctx.createRadialGradient(x-dx*7,y-dy*7,0,x-dx*7,y-dy*7,f);g.addColorStop(0,'#fff6d0');g.addColorStop(.5,'#ffa23a');g.addColorStop(1,'rgba(255,120,40,0)');
  app.ctx.fillStyle=g;app.ctx.beginPath();app.ctx.arc(x-dx*7,y-dy*7,f,0,TAU);app.ctx.fill();
}
export function missionPos(){const p=1-app.mission.t/6,e=p*p;return P(app.mission.x+e*16,app.mission.y-e*16,8+e*170+p*20)}
export function drawShip(t){
  const p=1-app.mission.t/6;const[x,y]=missionPos();
  app.ctx.save();app.ctx.translate(x,y);app.ctx.rotate(-.42);const s=1+p*.3;app.ctx.scale(s,s);
  frigate(10+Math.random()*7+p*10);app.ctx.restore();
}
