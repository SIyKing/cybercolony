/** The sky over each colony: stars on airless worlds and the planet or moons that hang above it (#34). Drawn in screen space, w by h CSS pixels. */
import type { WorldId } from '../sim/worlds';

type C = CanvasRenderingContext2D;
const TAU = Math.PI * 2;
function rng(s: number) { return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
function disc(c: C, x: number, y: number, r: number, stops: [number, string][], lx = -.4, ly = -.45) {
  const g = c.createRadialGradient(x + r * lx, y + r * ly, r * .05, x, y, r);
  for (const [o, col] of stops) g.addColorStop(o, col);
  c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
}
/** night side: a dark crescent shadow away from the sun (upper left) */
function shade(c: C, x: number, y: number, r: number, a = .85) {
  c.save(); c.beginPath(); c.arc(x, y, r, 0, TAU); c.clip();
  const g = c.createLinearGradient(x - r * .3, y - r * .3, x + r, y + r);
  g.addColorStop(0, 'rgba(4,6,18,0)'); g.addColorStop(.55, `rgba(4,6,18,${a * .6})`); g.addColorStop(1, `rgba(4,6,18,${a})`);
  c.fillStyle = g; c.fillRect(x - r, y - r, r * 2, r * 2); c.restore();
}
function glow(c: C, x: number, y: number, r0: number, r1: number, col: string) {
  const g = c.createRadialGradient(x, y, r0, x, y, r1); g.addColorStop(0, `rgba(${col},.45)`); g.addColorStop(1, `rgba(${col},0)`);
  c.fillStyle = g; c.beginPath(); c.arc(x, y, r1, 0, TAU); c.fill();
}
function stars(c: C, w: number, h: number, n: number, seed: number) {
  const r = rng(seed);
  for (let i = 0; i < n; i++) {
    const x = r() * w, y = Math.pow(r(), 1.6) * h, s = r();
    c.fillStyle = `rgba(255,255,255,${(.25 + s * .6) * (1 - y / h)})`; c.beginPath(); c.arc(x, y, .4 + s * .9, 0, TAU); c.fill();
  }
}
function lumpy(c: C, x: number, y: number, r: number, seed: number, light: string, dark: string) {
  const q = rng(seed), n = 11; c.beginPath();
  for (let i = 0; i <= n; i++) { const a = i / n * TAU, rr = r * (.78 + q() * .3); c[i ? 'lineTo' : 'moveTo'](x + Math.cos(a) * rr, y + Math.sin(a) * rr * .85); }
  const g = c.createRadialGradient(x - r * .4, y - r * .4, r * .1, x, y, r * 1.1); g.addColorStop(0, light); g.addColorStop(1, dark);
  c.fillStyle = g; c.fill();
  for (let i = 0; i < 4; i++) { c.fillStyle = 'rgba(0,0,0,.18)'; c.beginPath(); c.arc(x + (q() - .5) * r, y + (q() - .5) * r * .8, r * (.08 + q() * .12), 0, TAU); c.fill(); }
}

function haze(c: C, w: number, h: number) {
  const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, 'rgba(200,130,60,.35)'); g.addColorStop(1, 'rgba(200,130,60,0)');
  c.fillStyle = g; c.fillRect(0, 0, w, h);
}
/** screen rectangle the planet covers */
/** the discs the planet or moons cover on screen: [x, y, radius] */
export type SkyDiscs = [number, number, number][];

/** planet false: the backdrop (stars, haze, belt). planet true: the planet or moons alone, returning where they are, so the
 * stage can fade them when buildings are underneath (#43) */
export function drawSky(c: C, w: number, h: number, world: WorldId, planet: boolean): SkyDiscs {
  // the planet peeks in from the right edge, just under the HUD
  const R = Math.min(70, w * .18), x = w - R * .55, y = Math.min(h * .55, 205);
  if (!planet) {
    // the backdrop: stars, Titan's haze and Ceres' belt
    if (world === 'moon') stars(c, w, h, 70, 7);
    else if (world === 'europa') stars(c, w, h, 60, 13);
    else if (world === 'titan') haze(c, w, h);
    else if (world === 'ceres') {
      stars(c, w, h, 110, 29);
      // the asteroid belt: a soft diagonal band of tiny rocks
      const q = rng(41);
      for (let i = 0; i < 160; i++) {
        const u = q(), bx = u * w, by = h * .62 - u * h * .45 + (q() - .5) * 26, s = q();
        c.fillStyle = `rgba(${200 + s * 40},${190 + s * 40},${180 + s * 40},${.35 + s * .5})`; c.beginPath(); c.arc(bx, by, .5 + s * 1.6, 0, TAU); c.fill();
      }
    }
    return [];
  }
  if (world === 'moon') {
    glow(c, x, y, R * .95, R * 1.35, '120,180,255');
    disc(c, x, y, R, [[0, '#9fd8ff'], [.5, '#2f7fd0'], [1, '#123e7a']]);
    // continents and clouds, clipped to the globe
    c.save(); c.beginPath(); c.arc(x, y, R, 0, TAU); c.clip();
    const q = rng(3);
    // continents: clusters of small blobs, so the coasts look ragged
    for (let k = 0; k < 3; k++) { const cx = x + (q() - .6) * R * 1.2, cy = y + (q() - .5) * R * 1.2;
      for (let i = 0; i < 9; i++) { c.fillStyle = q() < .6 ? 'rgba(104,156,86,.9)' : 'rgba(190,164,108,.9)'; c.beginPath(); c.ellipse(cx + (q() - .5) * R * .5, cy + (q() - .5) * R * .6, R * (.05 + q() * .1), R * (.04 + q() * .07), q() * 3, 0, TAU); c.fill(); } }
    for (let i = 0; i < 9; i++) { c.fillStyle = 'rgba(255,255,255,.75)'; c.beginPath(); c.ellipse(x + (q() - .5) * R * 1.8, y + (q() - .5) * R * 1.8, R * (.12 + q() * .3), R * (.03 + q() * .05), -.35 + q() * .3, 0, TAU); c.fill(); }
    c.restore();
    shade(c, x, y, R);
    return [[x, y, R * 1.05]];
  } else if (world === 'mars') {
    // Phobos and Deimos: two small potato moons in the dusty sky
    lumpy(c, x - R * .2, y - R * .6, R * .32, 11, '#d9c2ae', '#5e4a3c');
    lumpy(c, x - R * 1.6, y - R * 1.3, R * .16, 23, '#e4d2c2', '#6a5648');
    return [[x - R * .2, y - R * .6, R * .34], [x - R * 1.6, y - R * 1.3, R * .18]];
  } else if (world === 'europa') {
    const J = R * 1.5, jx = w - J * .45;
    glow(c, jx, y, J * .95, J * 1.2, '255,220,180');
    disc(c, jx, y, J, [[0, '#fbe9d0'], [1, '#c9a27a']]);
    c.save(); c.beginPath(); c.arc(jx, y, J, 0, TAU); c.clip();
    const bands: [number, number, string][] = [[-.62, .1, '#b98a62'], [-.35, .12, '#e8cfae'], [-.15, .1, '#a8724c'], [.12, .14, '#d9b48c'], [.35, .1, '#b07a52'], [.6, .12, '#e2c6a2']];
    for (const [o, t, col] of bands) { c.fillStyle = col; c.globalAlpha = .7; c.fillRect(jx - J, y + o * J, J * 2, t * J); }
    c.globalAlpha = 1; c.fillStyle = '#c4573a'; c.beginPath(); c.ellipse(jx - J * .35, y + J * .3, J * .14, J * .08, 0, 0, TAU); c.fill();
    c.restore();
    shade(c, jx, y, J, .7);
    return [[jx, y, J * 1.02]];
  } else if (world === 'titan') {
    const S = R * .9;
    const ring = (front: boolean) => {
      c.save(); c.translate(x, y); c.rotate(-.35); c.beginPath();
      c.ellipse(0, 0, S * 2.1, S * .5, 0, front ? 0 : Math.PI, front ? Math.PI : TAU); c.strokeStyle = 'rgba(240,214,160,.7)'; c.lineWidth = S * .22; c.stroke();
      c.strokeStyle = 'rgba(160,120,70,.6)'; c.lineWidth = S * .05; c.stroke(); c.restore();
    };
    ring(false);
    disc(c, x, y, S, [[0, '#ffe7b0'], [1, '#b98a44']]);
    shade(c, x, y, S, .6);
    ring(true);
    // the orange haze lies in front of Saturn: tint only Saturn's own pixels, the backdrop has the rest
    c.save(); c.globalCompositeOperation = 'source-atop'; haze(c, w, h); c.restore();
    // Saturn and the two ends of its tilted ring
    const ex = Math.cos(.35) * S * 1.75, ey = Math.sin(.35) * S * 1.75;
    return [[x, y, S * 1.05], [x - ex, y + ey, S * .45], [x + ex, y - ey, S * .45]];
  }
  return [];
}
