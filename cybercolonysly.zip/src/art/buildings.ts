// @ts-nocheck -- moved out of the old one-file game; to be typed module by module (#2)
/** Building art: every building type, habitat and Command Center designs */
import { DEF, TAU } from '../sim/defs';
import { app } from '../game/state';
import { FLOOR, HH, HW, P, clamp, rng } from '../game/env';
import { caps, dayInfo, stormLeft, tech } from '../game/colony';
import hqUrl from '../assets/buildings/hq.webp';
import hackerUrl from '../assets/buildings/hacker.webp';
import drillUrl from '../assets/buildings/drill.webp';
import mineUrl from '../assets/buildings/mine.webp';
import hangarUrl from '../assets/buildings/hangar.webp';
import spaceportUrl from '../assets/buildings/spaceport.webp';
import { AMBER, BLUEN, GR1, GR2, GR3, GREENN, NEONC, OUT, PINKN, PURPN, SH_H, TEAL, W1, W2, W3, WARM, cyl, dome, extrude, faces, geodome, glassBand, lattice, lg, line, litQ, mix, mixC, neon, neonArc, neonEdges, ngon, oct, pad, patio, poly, prism, ring, rrect, winL } from './kit';

export function bHeight(b){const L=b.lvl,s=DEF[b.type].size;
  const pc=picOf(b);if(pc)return pc.k*pc.ay;
  if(b.type==='hq'){const st=hqStyle(b);return st==='spire'?hqDims(L).zt+(L>=6?24:0):st==='villa'?hqDimsV(L).zt+10:hqDimsG(L).top+20}
  return({habitat:14+12*Math.min(L,5),fashion:L>=3?42:30,drill:56+Math.min(L,6)*4,reactor:64,bank:48,mine:52,extractor:40+Math.min(L,6)*5,lab:44,greenhouse:40,hangar:48,turret:26,missile:26,railgun:34,elevator:150,solar:20,storage:32,shieldgen:40,terraform:60,spaceport:60,ring:90,mirror:90})[b.type]||30*s+10}
/* cast=true: the shadow the sun casts, which fades at night; cast=false: the contact shadow, which stays */
export function drawShadow(b,cast){
  const d=DEF[b.type],s=d.size;if(b.state==='building')return;
  if(b.type==='hq'&&hqStyle(b)==='spire'){const cx=b.gx+1,cy=b.gy+1,len=hqDims(b.lvl).H/34;
    if(!cast){poly([P(cx-.6,cy-.6),P(cx+.6,cy-.6),P(cx+.6,cy+.6),P(cx-.6,cy+.6)],'rgba(45,16,6,.1)',false);return}
    const g=lg(P(cx,cy),P(cx+len,cy+len*.15),[[0,'rgba(55,20,8,.45)'],[.7,'rgba(55,20,8,.18)'],[1,'rgba(55,20,8,0)']]);
    poly([P(cx-.1,cy-.5),P(cx+len,cy+len*.15-.04),P(cx+len,cy+len*.15+.04),P(cx-.1,cy+.5)],g,false);
    return}
  const k=(SH_H[b.type]||.4)*(1+.18*(b.lvl-1));const x0=b.gx+.1,y0=b.gy+.1,x1=b.gx+s-.1,y1=b.gy+s-.1;
  if(!cast){for(const[e,a]of[[.16,.08],[.09,.12],[.03,.16]])poly([P(x0-e,y0-e),P(x1+e,y0-e),P(x1+e,y1+e),P(x0-e,y1+e)],`rgba(45,16,6,${a})`,false);return}
  const g=lg(P(x1,y0),P(x1+k,y0),[[0,'rgba(60,22,10,.42)'],[.7,'rgba(60,22,10,.16)'],[1,'rgba(60,22,10,0)']]);
  poly([P(x0,y0),P(x1+k,y0+k*.15),P(x1+k,y1+k*.15),P(x0,y1)],g,false);
}

/* ---------- habitat designs inspired by modern cantilever villas ---------- */
export const HSTYLES=[{id:'dome',n:'Geo Dome'},{id:'villa',n:'Cantilever Villa'},{id:'pebble',n:'Pebble Stack'},{id:'terrace',n:'Terrace Tower'},{id:'classic',n:'Classic'}];
/* warm-lit glass on every visible face, split by slim dark mullions */
export function warmFaces(pts,z0,z1,step,seed){
  for(const f of faces(pts)){const len=Math.hypot(f.b[0]-f.a[0],f.b[1]-f.a[1]);const n=Math.max(1,Math.round(len/(step||.2)));
    const at=u=>[f.a[0]+(f.b[0]-f.a[0])*u,f.a[1]+(f.b[1]-f.a[1])*u];
    for(let k=0;k<n;k++){const pa=at(k/n),pb=at((k+1)/n);const q=[P(pa[0],pa[1],z1),P(pb[0],pb[1],z1),P(pb[0],pb[1],z0),P(pa[0],pa[1],z0)];
      const dim=((f.i*5+k*3+seed)%6)===0;poly(q,WARM(q,dim),false);if(!app.thumbMode&&!dim)litQ(q);
      app.ctx.fillStyle=`rgba(255,255,255,${.1+f.f*.12})`;app.ctx.beginPath();app.ctx.moveTo(q[0][0],q[0][1]);app.ctx.lineTo(q[0][0]+(q[1][0]-q[0][0])*.45,q[0][1]+(q[1][1]-q[0][1])*.45);app.ctx.lineTo(q[3][0]+(q[2][0]-q[3][0])*.15,q[3][1]+(q[2][1]-q[3][1])*.15);app.ctx.lineTo(q[3][0],q[3][1]);app.ctx.closePath();app.ctx.fill();
      line(q[0],q[3],'#2a2420',.7)}
    line(P(f.a[0],f.a[1],z1),P(f.b[0],f.b[1],z1),'#2a2420',.8)}
}
/* rounded window cut into a flat wall: a deep white reveal, warm room behind glass, a glass balcony rail and an LED cove */
function opening(face,c,u0,u1,z0,z1,seed,opt){
  const mp=(u,z)=>face==='L'?P(u,c,z):P(c,u,z);
  const path=(eu,ez)=>{const a=u0+eu,b=u1-eu,lo=z0+ez,hi=z1-ez,ru=Math.min(.06,(b-a)/3),rz=Math.min(3,(hi-lo)/3);
    const pts=[[a+ru,hi],[b-ru,hi],[b,hi,1],[b,hi-rz],[b,lo+rz],[b,lo,1],[b-ru,lo],[a+ru,lo],[a,lo,1],[a,lo+rz],[a,hi-rz],[a,hi,1]];
    app.ctx.beginPath();let i=0;const S0=mp(pts[0][0],pts[0][1]);app.ctx.moveTo(S0[0],S0[1]);
    for(i=1;i<pts.length;i++){const p=pts[i];if(p[2]){const cc=mp(p[0],p[1]),n=pts[(i+1)%pts.length],nn=mp(n[0],n[1]);app.ctx.quadraticCurveTo(cc[0],cc[1],nn[0],nn[1]);i++}else{const s=mp(p[0],p[1]);app.ctx.lineTo(s[0],s[1])}}
    app.ctx.closePath()};
  const top=mp((u0+u1)/2,z1),bot=mp((u0+u1)/2,z0);
  path(0,0);app.ctx.fillStyle=lg(top,bot,[[0,'#9aa5ab'],[.35,'#c9d0d3'],[1,'#e3e7e9']]);app.ctx.fill();
  app.ctx.save();path(.022,1.1);app.ctx.clip();app.EMIT++;
  app.ctx.fillStyle=lg(top,bot,[[0,'#fff6e4'],[.5,'#ffd79a'],[1,'#e6a466']]);app.ctx.fill();
  const rr=rng(seed*13+5),span=u1-u0;
  if(opt&&opt.shop){
    const cols=['#e86a9a','#e0a83a','#3fb5ad','#d9454f','#9b7ad8','#f2f2f2'];const n=Math.max(2,Math.round(span/.16));
    {const a=mp(u0,z1-1.6),b2=mp(u1,z1-1.6);line(a,b2,'rgba(200,170,120,.9)',.8)}
    for(let i=0;i<n;i++){const u=u0+span*(i+.5)/n;const base=mp(u,z0+1.4),c=cols[(i+seed)%cols.length],h=z1-z0-3.4;
      app.ctx.strokeStyle='#8a7a6a';app.ctx.lineWidth=.6;app.ctx.beginPath();app.ctx.moveTo(base[0],base[1]);app.ctx.lineTo(base[0],base[1]-h*.35);app.ctx.stroke();
      app.ctx.fillStyle='#d9cdbf';app.ctx.fillRect(base[0]-1.6,base[1]-.4,3.2,.8);
      app.ctx.fillStyle=c;app.ctx.beginPath();app.ctx.moveTo(base[0]-1.1,base[1]-h*.85);app.ctx.lineTo(base[0]+1.1,base[1]-h*.85);app.ctx.lineTo(base[0]+2.6,base[1]-h*.3);app.ctx.lineTo(base[0]-2.6,base[1]-h*.3);app.ctx.closePath();app.ctx.fill();
      app.ctx.fillStyle='rgba(255,255,255,.35)';app.ctx.fillRect(base[0]-.9,base[1]-h*.83,.7,h*.45);
      app.ctx.fillStyle='#f3e7da';app.ctx.beginPath();app.ctx.arc(base[0],base[1]-h*.95,1.1,0,TAU);app.ctx.fill()}
    {const sp=mp(u0+span*.5,z1-1.2);const g=app.ctx.createRadialGradient(sp[0],sp[1],0,sp[0],sp[1],span*30);g.addColorStop(0,'rgba(255,255,255,.35)');g.addColorStop(1,'rgba(255,255,255,0)');app.ctx.fillStyle=g;app.ctx.fillRect(sp[0]-30,sp[1]-4,60,30)}
  }else{
  // interior: curtains, a sofa, a table and a plant
  for(let i=0;i<3;i++){const u=u0+span*(.2+rr()*.6);const a=mp(u,z1-1.2),b2=mp(u,z0+1.6);line(a,b2,'rgba(255,255,255,.35)',2.2)}
  {const s0=mp(u0+span*.18,z0+3.2),s1=mp(u0+span*.5,z0+3.2),s2=mp(u0+span*.5,z0+1.2),s3=mp(u0+span*.18,z0+1.2);poly([s0,s1,s2,s3],'#f6f1ea',false)}
  {const tb=mp(u0+span*.66,z0+2.8);app.ctx.fillStyle='#8a5a3a';app.ctx.fillRect(tb[0]-2.4,tb[1],4.8,1.2);app.ctx.fillRect(tb[0]-.4,tb[1],.8,2.4)}
  {const pl=mp(u0+span*.86,z0+1.2);app.ctx.fillStyle='#c8794a';app.ctx.beginPath();app.ctx.ellipse(pl[0],pl[1]-1.6,1.9,1.8,0,0,TAU);app.ctx.fill();app.ctx.fillStyle='#a85f36';app.ctx.fillRect(pl[0]-.9,pl[1]-3.6,1.8,1);app.ctx.strokeStyle='#e9d3a6';app.ctx.lineWidth=.9;app.ctx.lineCap='round';app.ctx.beginPath();for(const d of[-1.8,0,1.6]){app.ctx.moveTo(pl[0],pl[1]-3.4);app.ctx.quadraticCurveTo(pl[0]+d*.5,pl[1]-6,pl[0]+d,pl[1]-8.2)}app.ctx.stroke();app.ctx.lineCap='butt';app.ctx.fillStyle='#f3e4c2';for(const d of[-1.8,0,1.6]){app.ctx.beginPath();app.ctx.ellipse(pl[0]+d,pl[1]-8.6,.9,1.6,d*.2,0,TAU);app.ctx.fill()}}
  }
  for(let i=1;i<4;i++){const u=u0+span*i/4;line(mp(u,z1),mp(u,z0),'rgba(40,32,26,.55)',(opt&&opt.shop)?.4:.6)}
  {const a=mp(u0,z1-.8),b2=mp(u1,z1-.8);app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.globalAlpha=.8;line(a,b2,'#ffe2a8',1.6);app.ctx.restore()}
  if(!(opt&&opt.noRail)){const rl=z0+(z1-z0)*.36;const q=[mp(u0,rl),mp(u1,rl),mp(u1,z0),mp(u0,z0)];poly(q,'rgba(215,236,248,.38)',false);line(q[0],q[1],'rgba(255,255,255,.85)',.8)}
  app.ctx.fillStyle='rgba(255,255,255,.16)';app.ctx.beginPath();const g0=mp(u0+span*.05,z1),g1=mp(u0+span*.3,z1),g2=mp(u0+span*.12,z0),g3=mp(u0-span*.1,z0);app.ctx.moveTo(g0[0],g0[1]);app.ctx.lineTo(g1[0],g1[1]);app.ctx.lineTo(g2[0],g2[1]);app.ctx.lineTo(g3[0],g3[1]);app.ctx.closePath();app.ctx.fill();
  {const j=[mp(u0,z1),mp(u0+span*.06,z1),mp(u0+span*.06,z0),mp(u0,z0)];poly(j,'rgba(24,16,10,.3)',false);
    const k=[mp(u0,z1),mp(u1,z1),mp(u1,z1-2.1),mp(u0,z1-2.1)];poly(k,lg(top,mp((u0+u1)/2,z1-2.1),[[0,'rgba(24,16,10,.6)'],[1,'rgba(24,16,10,0)']]),false)}
  app.EMIT--;app.ctx.restore();
  path(.022,1.1);app.ctx.strokeStyle='#1d1a18';app.ctx.lineWidth=.7;app.ctx.stroke();
  line(mp(u0+.02,z0+.9),mp(u1-.02,z0+.9),'#ffffff',.9);line(mp(u0+.02,z0+.45),mp(u1-.02,z0+.45),'rgba(70,74,78,.4)',.6);
}
function lounge(x,y,z,w){const[sx,sy]=P(x,y,z);app.ctx.fillStyle='rgba(60,30,20,.25)';app.ctx.beginPath();app.ctx.ellipse(sx+2,sy+1.2,w+1,w*.38,0,0,TAU);app.ctx.fill();
  app.ctx.fillStyle=lg([sx,sy-w*.5],[sx,sy+w*.3],[[0,'#ffffff'],[1,'#c9d0d3']]);app.ctx.beginPath();app.ctx.ellipse(sx,sy-1.2,w,w*.42,0,0,TAU);app.ctx.fill();
  app.ctx.strokeStyle='rgba(60,60,60,.35)';app.ctx.lineWidth=.5;app.ctx.beginPath();app.ctx.ellipse(sx,sy-.8,w*.98,w*.38,0,.1,Math.PI-.1);app.ctx.stroke()}
function potPlant(x,y,z,s){const[px,py]=P(x,y,z);app.ctx.fillStyle='rgba(60,40,30,.35)';app.ctx.beginPath();app.ctx.ellipse(px+1.2*s,py+.2*s,3.2*s,1.3*s,0,0,TAU);app.ctx.fill();
  app.ctx.fillStyle=lg([px-2*s,0],[px+2*s,0],[[0,'#a9a096'],[1,'#6f675f']]);app.ctx.beginPath();app.ctx.moveTo(px-2*s,py-3*s);app.ctx.lineTo(px+2*s,py-3*s);app.ctx.lineTo(px+1.5*s,py);app.ctx.lineTo(px-1.5*s,py);app.ctx.closePath();app.ctx.fill();
  app.ctx.fillStyle='#3a2a20';app.ctx.beginPath();app.ctx.ellipse(px,py-3*s,2*s,.7*s,0,0,TAU);app.ctx.fill();line([px,py-3*s],[px,py-6*s],'#5a4030',.8*s);
  for(const[dx,dy,r,c]of[[-1.6,-5.5,2.4,'#2f7a3a'],[1.4,-6.2,2.2,'#3f9a4c'],[0,-8,2.4,'#5cb862']]){app.ctx.fillStyle=c;app.ctx.beginPath();app.ctx.arc(px+dx*s,py+dy*s,r*s,0,TAU);app.ctx.fill()}}
function umbrella(x,y,z){const[px,py]=P(x,y,z);line([px,py],[px,py-12],'#cfd6d9',.9);app.ctx.fillStyle=lg([px-7,py-14],[px+7,py-12],[[0,'#ffffff'],[1,'#d5dadc']]);app.ctx.beginPath();app.ctx.moveTo(px-8,py-11);app.ctx.quadraticCurveTo(px,py-17,px+8,py-11);app.ctx.closePath();app.ctx.fill()}
/* a balcony on a wall: slab, soffit shadow on the wall below, glass rail, and a chair */
function balcony(face,c,u0,u1,z,d){
  const mp=(u,o,h)=>face==='L'?P(u,c+o,h):P(c+o,u,h);
  poly([mp(u0,0,z),mp(u1,0,z),mp(u1,0,z-2.4),mp(u0,0,z-2.4)],'rgba(40,44,50,.22)',false);
  poly([mp(u0,0,z+.9),mp(u1,0,z+.9),mp(u1,d,z+.9),mp(u0,d,z+.9)],'#e4e2dc',false);
  poly([mp(u0,d,z+.9),mp(u1,d,z+.9),mp(u1,d,z),mp(u0,d,z)],face==='L'?'#f4f5f5':'#bfc7cb',false);
  const a=mp(u0+(u1-u0)*.2,d*.5,z+.9);app.ctx.fillStyle='#8a5a3a';app.ctx.beginPath();app.ctx.ellipse(a[0],a[1]-1.1,1.5,.7,0,0,TAU);app.ctx.fill();
  poly([mp(u0,d,z+4.2),mp(u1,d,z+4.2),mp(u1,d,z+.9),mp(u0,d,z+.9)],'rgba(205,230,244,.42)',false);
  line(mp(u0,d,z+4.2),mp(u1,d,z+4.2),'#ffffff',.7);
  for(const u of[u0,(u0+u1)/2,u1])line(mp(u,d,z+4.2),mp(u,d,z+.9),'rgba(120,130,136,.8)',.45);
  poly([mp(u0,0,z+4.2),mp(u0,d,z+4.2),mp(u0,d,z+.9),mp(u0,0,z+.9)],'rgba(205,230,244,.28)',false);
}
/* a used roof: parapet edge, paved deck with drainage lines, a lit skylight, a plant room and solar cells */
function roofKit(R,z,L,x0,y0,x1,y1){
  const I=R.map(p=>{const cx=(x0+x1)/2,cy=(y0+y1)/2;return[cx+(p[0]-cx)*.86,cy+(p[1]-cy)*.86]}).map(p=>P(p[0],p[1],z));
  poly(I,lg(P(x0,y0,z),P(x1,y1,z),[[0,'#cfcbc3'],[1,'#e2dfd8']]),false);
  app.ctx.save();app.ctx.beginPath();I.forEach((p,i)=>i?app.ctx.lineTo(p[0],p[1]):app.ctx.moveTo(p[0],p[1]));app.ctx.closePath();app.ctx.clip();
  app.ctx.strokeStyle='rgba(90,84,76,.2)';app.ctx.lineWidth=.4;app.ctx.beginPath();
  for(let i=1;i<6;i++){const u=x0+(x1-x0)*i/6,v=y0+(y1-y0)*i/6;let a=P(u,y0,z),b=P(u,y1,z);app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(b[0],b[1]);a=P(x0,v,z);b=P(x1,v,z);app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(b[0],b[1])}app.ctx.stroke();app.ctx.restore();
  // shadow the parapet throws on the deck
  app.ctx.strokeStyle='rgba(60,54,48,.4)';app.ctx.lineWidth=.9;app.ctx.beginPath();I.forEach((p,i)=>i?app.ctx.lineTo(p[0],p[1]):app.ctx.moveTo(p[0],p[1]));app.ctx.closePath();app.ctx.stroke();
  const u=x=>x0+(x1-x0)*x,v=y=>y0+(y1-y0)*y;
  // skylight
  {const q=[P(u(.56),v(.2),z+1.6),P(u(.8),v(.2),z+1.6),P(u(.8),v(.44),z+1.6),P(u(.56),v(.44),z+1.6)];prism(u(.56),v(.2),u(.8),v(.44),z,1.6,'#d9dde0','#eef0f1','#b9c0c4',{noEdge:true});
    poly(q.map(p=>[p[0],p[1]]),lg(q[0],q[2],[[0,'#7fa6c2'],[1,'#2b4258']]),'#f4f6f7');litQ(q);line(q[0],q[2],'rgba(255,255,255,.35)',.5)}
  // plant room with a vent
  prism(u(.2),v(.22),u(.42),v(.42),z,4.4,'#eceeed','#dfe2e2','#b4bbbf',{noEdge:true});
  {const[a,c]=P(u(.31),v(.32),z+4.4);app.ctx.fillStyle='#5a646c';app.ctx.beginPath();app.ctx.ellipse(a,c,3,1.5,0,0,TAU);app.ctx.fill();app.ctx.fillStyle='#2f363c';app.ctx.beginPath();app.ctx.ellipse(a,c,1.9,.95,0,0,TAU);app.ctx.fill()}
  // solar cells
  if(L>=3){const q=[P(u(.24),v(.6),z+1.6),P(u(.5),v(.6),z+.6),P(u(.5),v(.82),z+.6),P(u(.24),v(.82),z+1.6)];poly(q,lg(q[0],q[2],[[0,'#3a5aa0'],[1,'#16234a']]),'#d8dcde');line(q[0],q[2],'rgba(150,190,240,.3)',.4)}
}
function roofDeck(R,z,L,b,t){
  if(L>=5){const fs=faces(R);for(const f of fs){const q=[P(f.a[0],f.a[1],z+3),P(f.b[0],f.b[1],z+3),P(f.b[0],f.b[1],z),P(f.a[0],f.a[1],z)];poly(q,'rgba(215,236,248,.35)',false);line(q[0],q[1],'rgba(255,255,255,.9)',.7)}}
}
function habStyle(st,b,t){const tx0=app.TEX;app.TEX=false;try{habStyle0(st,b,t)}finally{app.TEX=tx0}}
function habStyle0(st,b,t){
  const s=1,x0=b.gx,y0=b.gy,x1=x0+1,y1=y0+1,cx=x0+.5,cy=y0+.5,L=b.lvl;
  if(st==='dome'){
    patio(x0+.04,y0+.04,x1-.04,y1-.04);
    const R=.36+Math.min(L,6)*.01;
    cyl(cx,cy,R+.02,1.6,3.4,'#e4e0da','#b9b2a8');ring(cx,cy,R+.025,3.2,TEAL);
    geodome(cx,cy,R,5,b.id*7+L);
    // airlock module toward the viewer
    prism(cx+.06,y1-.2,cx+.3,y1-.06,1.6,6,W1,W2,W3);winL(cx+.1,cx+.26,y1-.06,2.6,5.6,true);
    if(L>=3){const r2=.13;cyl(x0+.2,y0+.2,r2+.01,1.6,2.4,'#e4e0da','#b9b2a8');geodome(x0+.2,y0+.2,r2,4,b.id*13)}
    lounge(x1-.16,y0+.22,1.6,2.6);
    return}
  if(st==='villa'){
    patio(x0+.04,y0+.04,x1-.04,y1-.04);
    const fl=Math.min(L,4);
    const G=rrect(x0+.27,y0+.27,x1-.22,y1-.22,.05);warmFaces(G,1.6,11.5,.17,b.id);
    {const T=G.map(p=>P(p[0],p[1],11.5));poly(T,'#d9dfe1',false)}
    // sculpted column under the overhang
    {const[bx,by]=P(x0+.17,y1-.17,1.6),h=10;app.ctx.fillStyle=lg([bx-4,0],[bx+4,0],[[0,'#ffffff'],[1,'#c3cbcf']]);app.ctx.beginPath();app.ctx.moveTo(bx-2,by);app.ctx.quadraticCurveTo(bx-1,by-h*.5,bx-4.5,by-h);app.ctx.lineTo(bx+4.5,by-h);app.ctx.quadraticCurveTo(bx+1,by-h*.5,bx+2,by);app.ctx.closePath();app.ctx.fill()}
    let z=11.5;
    for(let r=0;r<fl;r++){const a0=x0+.08,b0=y0+.08,a1=x1-.08,b1=y1-.08,h=FLOOR;
      const U=rrect(a0,b0,a1,b1,.14,4);extrude(U,z,h,'#ffffff','#f6f8f8','#cdd5d9',{smooth:true});
      opening('L',b1,a0+.15,a1-.15,z+2.2,z+9.4,b.id,{noRail:false});
      opening('R',a1,b0+.15,b1-.15,z+2.2,z+9.4,b.id+7,{noRail:false});
      if(r%2)balcony('L',b1,a0+.12,a1-.12,z+1.2,.06);else balcony('R',a1,b0+.12,b1-.12,z+1.2,.06);
      {const p=P(a0+.14,b1,z+h-.6),q=P(a1-.14,b1,z+h-.6);app.ctx.strokeStyle='rgba(255,255,255,.9)';app.ctx.lineWidth=1.2;app.ctx.beginPath();app.ctx.moveTo(p[0],p[1]);app.ctx.lineTo(q[0],q[1]);app.ctx.stroke()}
      z+=h}
    const R=rrect(x0+.08,y0+.08,x1-.08,y1-.08,.14,4);
    roofKit(R,z,L,x0+.08,y0+.08,x1-.08,y1-.08);roofDeck(R,z,L,b,t);
    if(L>=5){potPlant(x0+.25,y1-.2,z,.8);potPlant(x1-.2,y1-.28,z,.8);umbrella(cx+.1,cy+.14,z)}
    if(L>=7){const q=[P(x0+.3,y0+.2,z+3),P(x0+.6,y0+.2,z+3),P(x0+.6,y0+.45,z+1),P(x0+.3,y0+.45,z+1)];poly(q,'#2a3f6e','#c9d0d3')}
    lounge(x0+.2,y1-.16,1.6,4.6);lounge(x1-.12,y0+.34,1.6,3.6);potPlant(x1-.1,y1-.12,1.6,.8);
  }else if(st==='pebble'){
    patio(x0+.04,y0+.04,x1-.04,y1-.04);
    const fl=Math.min(L,5);let z=1.6;
    for(let r=0;r<fl;r++){const along=r%2===0,ins=r*.02,h=r===0?12:11;
      const U=along?rrect(x0+.08+ins,y0+.24+ins,x1-.08-ins,y1-.2-ins,.17,4):rrect(x0+.24+ins,y0+.08+ins,x1-.2-ins,y1-.08-ins,.17,4);
      extrude(U,z,h,'#ffffff','#f6f8f8','#cdd5d9',{smooth:true});
      const Wn=along?rrect(x0+.1+ins,y0+.26+ins,x1-.1-ins,y1-.22-ins,.15,4):rrect(x0+.26+ins,y0+.1+ins,x1-.22-ins,y1-.1-ins,.15,4);
      warmFaces(Wn,z+3,z+h-3,.09,b.id+r);
      for(const f of faces(U))line(P(f.a[0],f.a[1],z+h-.5),P(f.b[0],f.b[1],z+h-.5),'rgba(255,255,255,.9)',.8),line(P(f.a[0],f.a[1],z+1.6),P(f.b[0],f.b[1],z+1.6),'rgba(70,76,82,.28)',.5);
      if(r<fl-1){const e=along?[[x0+.17+ins,cy+.02],[x1-.15-ins,cy+.02]]:[[cx+.02,y0+.17+ins],[cx+.02,y1-.15-ins]];potPlant(e[0][0],e[0][1],z+h,.7);if(r===0)lounge(e[1][0],e[1][1],z+h,3)}
      z+=h}
    {const last=fl-1,along=last%2===0,ins=last*.02,a=along?x0+.08+ins:x0+.24+ins,c=along?y0+.24+ins:y0+.08+ins,d=along?x1-.08-ins:x1-.2-ins,e=along?y1-.2-ins:y1-.08-ins;
      roofKit(along?rrect(a,c,d,e,.17,4):rrect(a,c,d,e,.17,4),z,L,a,c,d,e);potPlant(a+(d-a)*.76,c+(e-c)*.74,z,1);if(L>=6)umbrella(a+(d-a)*.5,c+(e-c)*.8,z)}
    lounge(x0+.18,y1-.12,1.6,4);
  }else{
    patio(x0+.04,y0+.04,x1-.04,y1-.04);
    const fl=Math.min(L,5);let z=1.6;const C=rrect(x0+.27,y0+.27,x1-.27,y1-.27,.12,4),Sl=rrect(x0+.08,y0+.08,x1-.08,y1-.08,.22,5);
    let prev=null;
    for(let r=0;r<fl;r++){const h=10.5;warmFaces(C,z,z+h,.11,b.id+r);
      if(prev!==null){for(const f of faces(Sl)){const q=[P(f.a[0],f.a[1],prev+3.2),P(f.b[0],f.b[1],prev+3.2),P(f.b[0],f.b[1],prev),P(f.a[0],f.a[1],prev)];poly(q,'rgba(215,236,248,.34)',false);line(q[0],q[1],'rgba(255,255,255,.9)',.7)}
        potPlant(x1-.18,y1-.18,prev,.75)}
      z+=h;extrude(Sl,z,2.4,'#ffffff','#f4f6f7','#cbd3d7',{smooth:true});
      {app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.globalAlpha=.55;for(const f of faces(Sl))line(P(f.a[0],f.a[1],z-.2),P(f.b[0],f.b[1],z-.2),'#ffcf8a',1.2);app.ctx.restore()}
      z+=2.4;prev=z}
    for(const f of faces(Sl)){const q=[P(f.a[0],f.a[1],prev+3.2),P(f.b[0],f.b[1],prev+3.2),P(f.b[0],f.b[1],prev),P(f.a[0],f.a[1],prev)];poly(q,'rgba(215,236,248,.34)',false);line(q[0],q[1],'rgba(255,255,255,.9)',.7)}
    roofKit(Sl,prev,L,x0+.08,y0+.08,x1-.08,y1-.08);potPlant(x1-.26,y1-.22,prev,.8);if(L>=4)umbrella(cx+.14,cy+.2,prev);
    lounge(x0+.18,y1-.12,1.6,3.6);
  }
}
/* the colony frigate, nose to +x: white upper hull with a red stripe, dark belly, swept wings, twin cyan engines. fl = engine flame length, 0 when parked */
export function frigate(fl){const E='rgba(10,16,24,.65)';app.ctx.lineWidth=.6;app.ctx.lineJoin='round';
  if(fl){const g=app.ctx.createLinearGradient(-15,0,-15-fl,0);g.addColorStop(0,'#eaffff');g.addColorStop(.3,'#2ee6ff');g.addColorStop(1,'rgba(46,140,255,0)');app.ctx.fillStyle=g;
    for(const y of[-2.4,2.4]){app.ctx.beginPath();app.ctx.moveTo(-15,y-1.6);app.ctx.lineTo(-15-fl,y);app.ctx.lineTo(-15,y+1.6);app.ctx.closePath();app.ctx.fill()}}
  poly([[-2,-1],[-12,-10],[-7,-10.6],[4,-2.4]],lg([0,-10],[0,-1],[[0,'#7d8b97'],[1,'#4c5864']]),E);
  poly([[-15,0],[16,1],[10,4.6],[-13,4.3]],'#2a323c',E);
  poly([[-15,-3.8],[2,-4.9],[12,-2.5],[18,.6],[-15,1]],lg([0,-5],[0,1],[[0,'#ffffff'],[.6,'#dbe3ea'],[1,'#9aa8b4']]),E);
  app.ctx.fillStyle='#39434e';app.ctx.fillRect(-16.4,-3.6,4,2.4);app.ctx.fillRect(-16.4,1.2,4,2.4);
  app.ctx.fillStyle='#7ff4ff';app.ctx.fillRect(-16.8,-3.2,.8,1.6);app.ctx.fillRect(-16.8,1.6,.8,1.6);
  app.ctx.fillStyle='#e8649f';app.ctx.beginPath();app.ctx.moveTo(-12,-2.3);app.ctx.lineTo(8,-2.8);app.ctx.lineTo(8.8,-2);app.ctx.lineTo(-12,-1.5);app.ctx.closePath();app.ctx.fill();
  app.ctx.fillStyle='#14202c';app.ctx.beginPath();app.ctx.moveTo(5.6,-4.2);app.ctx.lineTo(12,-2.4);app.ctx.lineTo(6.6,-2.6);app.ctx.closePath();app.ctx.fill();
  app.ctx.fillStyle='rgba(127,244,255,.85)';app.ctx.fillRect(7.2,-3.7,2.4,.5);
  app.ctx.fillStyle='#7ff4ff';for(let i=0;i<5;i++)app.ctx.fillRect(-10+i*3,-.5,1.2,.6);
  poly([[-3,1.6],[-13,10.6],[-8,11.2],[3.4,3]],lg([0,2],[0,11],[[0,'#eef2f5'],[1,'#8a98a4']]),E);
  app.ctx.fillStyle='#ff3b4c';app.ctx.beginPath();app.ctx.arc(-11.6,10.6,.8,0,TAU);app.ctx.fill();
  app.ctx.fillStyle='#46ff9a';app.ctx.beginPath();app.ctx.arc(-9.6,-10.4,.7,0,TAU);app.ctx.fill()}
function shuttle(p,rot,sc,flame){app.ctx.save();app.ctx.translate(p[0],p[1]);
  app.ctx.fillStyle='rgba(20,14,10,.35)';app.ctx.beginPath();app.ctx.ellipse(2*sc,6*sc,16*sc,4*sc,0,0,TAU);app.ctx.fill();
  app.ctx.rotate(rot);app.ctx.scale(sc,sc);frigate(flame?8:0);app.ctx.restore()}
export function hqDimsG(L){const th1=24+Math.min(L,8)*5,th2=8+Math.min(L,8)*2,z3=18.6+th1+th2;return{th1,th2,z3,top:z3+14}}
export function hqDimsV(L){const tf=2+Math.ceil(Math.min(L,8)*.75),zt=26+tf*12+3.2;return{tf,zt,z3:zt,top:zt+4}}
/* realistic curtain wall for the Glass Tower: bronze tint, fresnel sky reflection, slab lines, mullions, lit rooms */
function curtainWall(pts,z0,z1,seed,step){
  const F=faces(pts),rr=rng(seed*131+17),fl=FLOOR;
  for(const f of F){
    const refl=Math.min(1,Math.abs(f.f-.5)*2),base=mixC('#9a6440','#efd6ba',refl*.75),c=f.f>.5?mixC(base,'#3e2414',(f.f-.5)*.7):mixC(base,'#fff1de',(.5-f.f)*.25);
    const A1=P(f.a[0],f.a[1],z1),B1=P(f.b[0],f.b[1],z1),B0=P(f.b[0],f.b[1],z0),A0=P(f.a[0],f.a[1],z0);
    poly([A1,B1,B0,A0],lg([0,A1[1]],[0,A0[1]],[[0,mixC(c,'#fff0dc',.45)],[.35,c],[.85,c],[1,mixC(c,'#3a1e10',.35)]]),false);
    app.ctx.strokeStyle=lg([0,A1[1]],[0,A0[1]],[[0,mixC(c,'#fff0dc',.45)],[1,c]]);app.ctx.lineWidth=.6;app.ctx.stroke();
    const len=Math.hypot(f.b[0]-f.a[0],f.b[1]-f.a[1]),nm=Math.max(1,Math.round(len/Math.max(.14,step||.14)));
    const at=(u,z)=>P(f.a[0]+(f.b[0]-f.a[0])*u,f.a[1]+(f.b[1]-f.a[1])*u,z);
    // lit rooms seen through the glass, clearer where the glass faces you
    for(let z=z0;z<z1-fl*.4;z+=fl)for(let k=0;k<nm;k++){if(rr()<.55)continue;const u0=k/nm+.08/nm,u1=(k+1)/nm-.08/nm,zt2=Math.min(z1-.5,z+fl*.78);
      const q=[at(u0,zt2),at(u1,zt2),at(u1,z+1.2),at(u0,z+1.2)];poly(q,`rgba(255,212,150,${.28+.5*(1-refl)})`,false);if(!app.thumbMode)litQ(q)}
    // floor slabs
    for(let z=z0+fl;z<z1-.5;z+=fl){line(at(0,z),at(1,z),'rgba(55,30,16,.55)',.9);line(at(0,z+.6),at(1,z+.6),'rgba(255,232,200,.3)',.4)}
    // mullions
    for(let k=1;k<nm;k++){line(at(k/nm,z0),at(k/nm,z1),'rgba(40,22,12,.35)',.45)}
    // sun glint on the lit corner
    if(f.f>.12&&f.f<.3){const g0=at(.5,z1),g1=at(.5,z0);app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.globalAlpha=.35;line(g0,g1,'#fff4e2',1.4);app.ctx.restore()}
  }
  // frame lines top and bottom
  app.ctx.strokeStyle='rgba(255,255,255,.9)';app.ctx.lineWidth=1;app.ctx.beginPath();for(const f of F)for(const z of[z0,z1]){const p=P(f.a[0],f.a[1],z),q=P(f.b[0],f.b[1],z);app.ctx.moveTo(p[0],p[1]);app.ctx.lineTo(q[0],q[1])}app.ctx.stroke();
}
function hqGlass(b,t){const s=2,x0=b.gx,y0=b.gy,x1=x0+2,y1=y0+2,cx=x0+1,cy=y0+1,L=b.lvl;

    pad(x0+.05,y0+.05,x1-.05,y1-.05);
    const acc=L>=5?AMBER:NEONC,H=hqDimsG(L),u=v=>x0+v,w=v=>y0+v;
    // podium with a glazed ground floor
    const P0=oct(u(.14),w(.14),u(1.86),w(1.86),.38);
    extrude(P0,2,15,W1,W2,W3);curtainWall(P0,4,13,b.id,.12);neonEdges(P0,14,acc,1.1);
    const R0=oct(u(.17),w(.17),u(1.83),w(1.83),.37);extrude(R0,17,1.6,'#d9dfe2','#9aa5ab','#7f8a90',{noEdge:true});neonEdges(R0,18,acc,.7);
    // roof deck panels
    {app.ctx.strokeStyle='rgba(90,105,115,.22)';app.ctx.lineWidth=.6;app.ctx.beginPath();for(let i=1;i<6;i++){const k=.17+i*(1.66/6);let a=P(u(k),w(.4),18.6),c=P(u(k),w(1.6),18.6);app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(c[0],c[1]);a=P(u(.4),w(k),18.6);c=P(u(1.6),w(k),18.6);app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(c[0],c[1])}app.ctx.stroke()}
    // back corner: comms array
    {const ab=P(u(.42),w(.42),18.6);const mh=L>=3?38:24,at=[ab[0],ab[1]-mh];lattice(ab,at,4,5,'#d6dcdf');
      app.ctx.fillStyle=(Math.floor(t*2)%2)?'#ff4d5a':'#5a1a20';app.ctx.beginPath();app.ctx.arc(at[0],at[1]-1,2,0,TAU);app.ctx.fill();
      if(L>=3){app.ctx.save();app.ctx.translate(ab[0]+9,ab[1]-14);app.ctx.rotate(-.6+.2*Math.sin(t*.35));app.ctx.fillStyle=lg([-9,0],[9,0],[[0,'#ffffff'],[1,'#a9b4b8']]);app.ctx.beginPath();app.ctx.ellipse(0,0,10,5,0,0,TAU);app.ctx.fill();app.ctx.strokeStyle=OUT;app.ctx.stroke();
        app.ctx.strokeStyle='#8d979c';app.ctx.lineWidth=.8;app.ctx.beginPath();app.ctx.moveTo(0,0);app.ctx.lineTo(-3,-6);app.ctx.stroke();app.ctx.restore()}}
    // left corner: landing pad, with a parked shuttle from level 4
    if(L>=2){const lc=[u(.45),w(1.55)];const[px,py]=P(lc[0],lc[1],18.8);const rx=.15*HW*1.414,ry=.15*HH*1.414;
      app.ctx.fillStyle='#3a4552';app.ctx.beginPath();app.ctx.ellipse(px,py,rx,ry,0,0,TAU);app.ctx.fill();
      app.ctx.strokeStyle='rgba(255,214,110,.9)';app.ctx.lineWidth=1.2;app.ctx.beginPath();app.ctx.ellipse(px,py,rx*.75,ry*.75,0,0,TAU);app.ctx.stroke();
      app.ctx.save();app.ctx.translate(px,py);app.ctx.scale(1,.5);app.ctx.rotate(Math.PI/4);app.ctx.fillStyle='#ffd66e';app.ctx.font='900 9px system-ui,sans-serif';app.ctx.textAlign='center';app.ctx.textBaseline='middle';app.ctx.fillText('H',0,.5);app.ctx.restore();
      for(let i=0;i<6;i++){const a=i/6*TAU;if((i+Math.floor(t*3))%3)continue;const lx=px+Math.cos(a)*rx,ly=py+Math.sin(a)*ry;app.ctx.fillStyle='#ffe2a8';app.ctx.beginPath();app.ctx.arc(lx,ly,1.2,0,TAU);app.ctx.fill()}
      if(L>=4&&!app.mission){app.ctx.save();app.ctx.translate(px,py-4);app.ctx.rotate(.45);app.ctx.fillStyle='#b9c2c6';app.ctx.beginPath();app.ctx.moveTo(-3,0);app.ctx.lineTo(-8,6);app.ctx.lineTo(-1,2);app.ctx.closePath();app.ctx.fill();
        app.ctx.fillStyle=lg([0,-4],[0,4],[[0,'#ffffff'],[1,'#8f9aa0']]);app.ctx.beginPath();app.ctx.moveTo(-9,-2.5);app.ctx.lineTo(5,-2.5);app.ctx.quadraticCurveTo(11,0,5,2.5);app.ctx.lineTo(-9,2.5);app.ctx.closePath();app.ctx.fill();app.ctx.strokeStyle=OUT;app.ctx.stroke();
        app.ctx.fillStyle='#3a2e26';app.ctx.beginPath();app.ctx.ellipse(6,-.8,2.4,1.3,0,0,TAU);app.ctx.fill();app.ctx.fillStyle=acc;app.ctx.fillRect(-7,-.5,8,1);app.ctx.restore()}}
    // right corner: annex tower
    if(L>=3){const W=oct(u(1.42),w(.3),u(1.72),w(.6),.08),ah=12+Math.min(L,8)*2.5;extrude(W,18.6,ah,W1,W2,W3);curtainWall(W,20.6,18.6+ah-1.5,b.id+11,.09);neonEdges(W,18.6+ah,acc,.9);
      dome(u(1.57),w(.45),.1,18.6+ah,'rgba(225,236,238,.92)',3)}
    // main tower in two setbacks
    const T1=oct(u(.5),w(.5),u(1.5),w(1.5),.26),z1=18.6,z2=z1+H.th1,z3=z2+H.th2;
    extrude(T1,z1,H.th1,W1,W2,W3);curtainWall(T1,z1+2,z2-2,b.id+3,.09);
    {const F=faces(T1);
      // glass elevator riding the front face
      const ff=F.find(f=>f.f>.3&&f.f<.7);if(ff){const mx=(ff.a[0]+ff.b[0])/2,my=(ff.a[1]+ff.b[1])/2;const e=(Math.sin(t*.45+b.id)*.5+.5);const zc=z1+4+e*(H.th1-10);
        const s0=P(mx,my,z1+2),s1=P(mx,my,z2-2);app.ctx.fillStyle='rgba(20,40,55,.55)';app.ctx.fillRect(s0[0]-2.6,s1[1],5.2,s0[1]-s1[1]);const c=P(mx,my,zc);app.ctx.fillStyle='#f4fcff';app.ctx.fillRect(c[0]-2.2,c[1]-4,4.4,4);
        app.ctx.save();app.ctx.globalCompositeOperation='lighter';const g=app.ctx.createRadialGradient(c[0],c[1]-2,0,c[0],c[1]-2,7);g.addColorStop(0,'rgba(255,236,200,.8)');g.addColorStop(1,'rgba(255,214,150,0)');app.ctx.fillStyle=g;app.ctx.fillRect(c[0]-7,c[1]-9,14,14);app.ctx.restore()}
      // colony emblem on the lit face
      const lf=F.find(f=>f.f<.2);if(lf){const mx=lf.a[0]+(lf.b[0]-lf.a[0])*.5,my=lf.a[1]+(lf.b[1]-lf.a[1])*.5;const[ex,ey]=P(mx,my,z2-9);
        const hx=[];for(let i=0;i<6;i++){const a=i/6*TAU+Math.PI/6;hx.push([ex+Math.cos(a)*5.5,ey+Math.sin(a)*4.6+(Math.cos(a))*1.6])}
        for(let i=0;i<6;i++)neon(hx[i],hx[(i+1)%6],acc,.8);neon([ex,ey-2.5],[ex,ey+2.5],acc,.7)}}
    neonEdges(T1,z2-1,acc,1.1);
    const T2=oct(u(.6),w(.6),u(1.4),w(1.4),.22);
    extrude(T2,z2,H.th2,W1,W2,W3);curtainWall(T2,z2+1.5,z3-1.5,b.id+9,.08);neonEdges(T2,z3-.8,acc,.9);
    // crown fins and dome
    const T3=oct(u(.68),w(.68),u(1.32),w(1.32),.18);extrude(T3,z3,4,GR2,GR1,GR3);
    dome(cx,cy,.27,z3+4,'rgba(225,236,238,.92)',6);
    for(let i=0;i<10;i++){const a=i/10*TAU+Math.PI/10;if(Math.sin(a)+Math.cos(a)<-.6)continue;const p=P(cx+Math.cos(a)*.34,cy+Math.sin(a)*.34,z3+2),q=P(cx+Math.cos(a)*.3,cy+Math.sin(a)*.3,z3+14);
      app.ctx.lineCap='round';line(p,q,L>=8?'#ffd56a':'#eef2f3',2.2);app.ctx.lineCap='butt'}
    // holograms over the crown
    {const[hx,hy]=P(cx,cy,H.top+12);app.ctx.save();app.ctx.globalCompositeOperation='lighter';
      const nR=L>=8?3:2;for(let i=0;i<nR;i++){const rr=24+i*9;app.ctx.strokeStyle=i?'rgba(255,214,150,.3)':'rgba(255,214,150,.55)';app.ctx.lineWidth=1.3;app.ctx.setLineDash([9,6]);app.ctx.lineDashOffset=t*(i%2?-24:30);
        app.ctx.beginPath();app.ctx.ellipse(hx,hy+i*5,rr,rr*.3,0,0,TAU);app.ctx.stroke()}
      app.ctx.setLineDash([]);
      if(L>=5){const[gx,gy]=P(cx,cy,H.top+(L>=6?52:30));const rr=10;const g=app.ctx.createRadialGradient(gx-3,gy-3,1,gx,gy,rr);g.addColorStop(0,'rgba(255,190,140,.55)');g.addColorStop(1,'rgba(255,120,60,.08)');app.ctx.fillStyle=g;app.ctx.beginPath();app.ctx.arc(gx,gy,rr,0,TAU);app.ctx.fill();
        app.ctx.strokeStyle='rgba(255,200,150,.6)';app.ctx.lineWidth=.8;app.ctx.beginPath();app.ctx.arc(gx,gy,rr,0,TAU);app.ctx.stroke();
        for(let i=0;i<3;i++){app.ctx.beginPath();app.ctx.ellipse(gx,gy,rr*Math.abs(Math.cos(t*.8+i*1.05)),rr,0,0,TAU);app.ctx.stroke()}
        app.ctx.beginPath();app.ctx.ellipse(gx,gy,rr,rr*.32,0,0,TAU);app.ctx.stroke();
        const ma=t*1.4;app.ctx.fillStyle='rgba(255,230,200,.9)';app.ctx.beginPath();app.ctx.arc(gx+Math.cos(ma)*rr*1.6,gy+Math.sin(ma)*rr*.5,1.6,0,TAU);app.ctx.fill()}
      app.ctx.restore()}
    if(L>=6){const sb=P(cx,cy,z3+4+11),sp=[sb[0],sb[1]-(L>=6?20:0)];line(sb,sp,'#e4e9eb',2);neon([sp[0],sp[1]+16],[sp[0],sp[1]+2],acc,.8);
      app.ctx.fillStyle=(Math.floor(t*1.5)%2)?'#ff4d5a':'#5a1a20';app.ctx.beginPath();app.ctx.arc(sp[0],sp[1]-1,2.4,0,TAU);app.ctx.fill()}
    if(L>=7){const a=P(u(1.48),w(.52),18.6+12+Math.min(L,8)*2.5-4),c=P(u(1.36),w(.66),18.6+12+Math.min(L,8)*2.5-4);app.ctx.lineCap='round';line(a,c,'#e9edef',4.5);line(a,c,'#5f9fb8',1.8);app.ctx.lineCap='butt'}
    // grand glass atrium on the front corner
    {const A=[[u(1.86)-.56,w(1.86)-.06],[u(1.86)-.06,w(1.86)-.56],[u(1.96),w(1.86)-.46],[u(1.86)-.46,w(1.96)]];
      extrude(A,2,11,'#e9eef0','#cfd8dc','#aab5bb');curtainWall(A,2.6,10.4,b.id+21,.08);neonEdges(A,11,acc,1);
      const f=faces(A).find(f=>f.f>.3&&f.f<.7);if(f){const mx=(f.a[0]+f.b[0])/2,my=(f.a[1]+f.b[1])/2,dx=(f.b[0]-f.a[0])*.12,dy=(f.b[1]-f.a[1])*.12;
        const q=[P(mx-dx,my-dy,8),P(mx+dx,my+dy,8),P(mx+dx,my+dy,2),P(mx-dx,my-dy,2)];poly(q,lg(q[0],q[3],[[0,'#f4fcff'],[1,'#9fdcff']]),false);neon(q[0],q[1],acc,.9)}}
    }
function hqVilla(b,t){const s=2,x0=b.gx,y0=b.gy,x1=x0+2,y1=y0+2,cx=x0+1,cy=y0+1,L=b.lvl;

    pad(x0+.04,y0+.04,x1-.04,y1-.04);
    const u=v=>x0+v,w=v=>y0+v,H=hqDimsV(L),zP=12,hP=14,zT=zP+hP,fh=12;
    // glass lobby under a floating podium, carried by sculpted columns
    const Lb=rrect(u(.44),w(.44),u(1.56),w(1.56),.12,3);warmFaces(Lb,1.6,zP,.16,b.id);
    {const T=Lb.map(p=>P(p[0],p[1],zP));poly(T,'#e3e7e9',false)}
    const col=(cx2,cy2)=>{const[bx,by]=P(cx2,cy2,1.6),h=zP-1.6;app.ctx.fillStyle=lg([bx-5,0],[bx+5,0],[[0,'#ffffff'],[1,'#c3cbcf']]);app.ctx.beginPath();app.ctx.moveTo(bx-2.2,by);app.ctx.quadraticCurveTo(bx-1.2,by-h*.5,bx-5,by-h);app.ctx.lineTo(bx+5,by-h);app.ctx.quadraticCurveTo(bx+1.2,by-h*.5,bx+2.2,by);app.ctx.closePath();app.ctx.fill()};
    col(u(.36),w(1.64));col(u(1.64),w(.36));col(u(1.6),w(1.6));
    {const q=[P(u(1.56)-.0,w(1.18),9),P(u(1.56),w(.82),9),P(u(1.56),w(.82),1.6),P(u(1.56),w(1.18),1.6)];poly(q,lg(q[0],q[3],[[0,'#fffaf0'],[1,'#ffd9a0']]),false);line(q[0],q[1],'#2a2420',.8)}
    // podium: a wide villa-style volume with long rounded windows
    const Pd=rrect(u(.2),w(.2),u(1.8),w(1.8),.34,5);extrude(Pd,zP,hP,'#ffffff','#f6f8f8','#cdd5d9',{smooth:true});
    opening('L',w(1.8),u(.58),u(1.0),zP+2.4,zP+hP-2.4,b.id,{});opening('L',w(1.8),u(1.06),u(1.46),zP+2.4,zP+hP-2.4,b.id+1,{});
    opening('R',u(1.8),w(.58),w(1.0),zP+2.4,zP+hP-2.4,b.id+2,{});opening('R',u(1.8),w(1.06),w(1.46),zP+2.4,zP+hP-2.4,b.id+3,{});
    {app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.globalAlpha=.6;for(const f of faces(Pd))line(P(f.a[0],f.a[1],zP-.3),P(f.b[0],f.b[1],zP-.3),'#ffcf8a',1.2);app.ctx.restore()}
    // rooftop: plants behind the tower
    potPlant(u(.48),w(.62),zT,.75);potPlant(u(.62),w(.48),zT,.75);
    // main tower: stacked villa floors with rounded windows on both faces
    const Tw=rrect(u(.56),w(.56),u(1.44),w(1.44),.22,4);let z=zT;
    for(let r=0;r<H.tf;r++){extrude(Tw,z,fh,'#ffffff','#f6f8f8','#cdd5d9',{smooth:true});
      opening('L',w(1.44),u(.74),u(1.26),z+2,z+fh-2,b.id+r%3,{noRail:r%2===1});opening('R',u(1.44),w(.74),w(1.26),z+2,z+fh-2,b.id+r%3+4,{noRail:r%2===1});
      z+=fh}
    // overhanging crown roof with a gold trim and warm downlight
    {const Cr=rrect(u(.5),w(.5),u(1.5),w(1.5),.26,4);extrude(Cr,z,3.2,'#ffffff','#f4f6f7','#cbd3d7',{smooth:true});
      for(const f of faces(Cr))line(P(f.a[0],f.a[1],z+1.6),P(f.b[0],f.b[1],z+1.6),L>=5?'#d9a441':'#d8b98c',1.1);
      app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.globalAlpha=.7;for(const f of faces(Cr))line(P(f.a[0],f.a[1],z-.3),P(f.b[0],f.b[1],z-.3),'#ffcf8a',1.3);app.ctx.restore();z+=3.2}
    const zt=z;
    {app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.globalAlpha=.7;for(const f of faces(Tw))line(P(f.a[0],f.a[1],zt-.4),P(f.b[0],f.b[1],zt-.4),'#ffcf8a',1.1);app.ctx.restore()}
    // roof: helipad, dish, spire
    if(L>=2){const[px,py]=P(u(1),w(1),zt+.1);const rx=.27*HW*1.414,ry=.27*HH*1.414;app.ctx.fillStyle='#dcd9d3';app.ctx.beginPath();app.ctx.ellipse(px,py,rx,ry,0,0,TAU);app.ctx.fill();
      app.ctx.strokeStyle='#e0a83a';app.ctx.lineWidth=1.3;app.ctx.beginPath();app.ctx.ellipse(px,py,rx*.78,ry*.78,0,0,TAU);app.ctx.stroke();
      app.ctx.save();app.ctx.translate(px,py);app.ctx.scale(1,.5);app.ctx.rotate(Math.PI/4);app.ctx.fillStyle='#e0a83a';app.ctx.font='900 12px system-ui,sans-serif';app.ctx.textAlign='center';app.ctx.textBaseline='middle';app.ctx.fillText('H',0,.5);app.ctx.restore();
      for(let i=0;i<8;i++){const a=i/8*TAU;if((i+Math.floor(t*3))%4)continue;app.ctx.fillStyle='#fff2c8';app.ctx.beginPath();app.ctx.arc(px+Math.cos(a)*rx,py+Math.sin(a)*ry,1.3,0,TAU);app.ctx.fill()}
      if(L>=4&&!app.mission)shuttle([px,py-3],.46,.6,false)}
    if(L>=3){const ab=P(u(1.3),w(.68),zt),at=[ab[0],ab[1]-12];line(ab,at,'#d6dcdf',1.2);app.ctx.save();app.ctx.translate(at[0],at[1]+3);app.ctx.rotate(-.6+.2*Math.sin(t*.35));app.ctx.fillStyle=lg([-7,0],[7,0],[[0,'#ffffff'],[1,'#b9c2c6']]);app.ctx.beginPath();app.ctx.ellipse(0,0,7,3.5,0,0,TAU);app.ctx.fill();app.ctx.strokeStyle=OUT;app.ctx.stroke();app.ctx.restore()}
    if(L>=6){const sb=P(u(.7),w(.7),zt),sp=[sb[0],sb[1]-30];line(sb,sp,'#eef1f2',2.2);app.ctx.fillStyle=(Math.floor(t*1.5)%2)?'#ff4d5a':'#5a1a20';app.ctx.beginPath();app.ctx.arc(sp[0],sp[1]-1,2.4,0,TAU);app.ctx.fill()}
    // side wings on the podium roof
    const wing=(W,c1,c2,seed,fl)=>{let zz=zT;for(let r=0;r<fl;r++){extrude(W,zz,11,'#ffffff','#f6f8f8','#cdd5d9',{smooth:true});
      opening('L',c1[0],c1[1],c1[2],zz+2,zz+9,seed+r,{noRail:true});opening('R',c2[0],c2[1],c2[2],zz+2,zz+9,seed+r+3,{noRail:true});zz+=11}};
    const wf=L>=7?2:1;
    if(L>=2)wing(rrect(u(.22),w(1.46),u(.52),w(1.76),.1,3),[w(1.76),u(.3),u(.44)],[u(.52),w(1.54),w(1.68)],b.id+8,wf);
    if(L>=4)wing(rrect(u(1.46),w(.24),u(1.76),w(.54),.1,3),[w(.54),u(1.54),u(1.68)],[u(1.76),w(.32),w(.46)],b.id+9,wf);
    // front roof terrace with a pool and loungers
    if(L>=3){const Pl=rrect(u(1.5),w(1.5),u(1.72),w(1.72),.07,3);const T=Pl.map(p=>P(p[0],p[1],zT+.1));poly(T,'#f1f4f5',false);
      const I=rrect(u(1.53),w(1.53),u(1.69),w(1.69),.05,3).map(p=>P(p[0],p[1],zT+.1));poly(I,lg(I[0],I[Math.floor(I.length/2)],[[0,'#9fe3f2'],[1,'#3aa6c9']]),false);
      app.ctx.fillStyle='rgba(255,255,255,.55)';const c=P(u(1.6),w(1.58),zT+.1);app.ctx.beginPath();app.ctx.ellipse(c[0]+Math.sin(t)*1.5,c[1],3,.8,0,0,TAU);app.ctx.fill();
      lounge(u(1.36),w(1.7),zT,3);lounge(u(1.7),w(1.36),zT,3)}
    potPlant(u(1.75),w(1.12),zT,.7);potPlant(u(1.12),w(1.75),zT,.7);
    // warm hologram crown at the top level
    if(L>=8){const[hx,hy]=P(u(1),w(1),zt+20);app.ctx.save();app.ctx.globalCompositeOperation='lighter';for(let i=0;i<2;i++){app.ctx.strokeStyle=i?'rgba(255,214,150,.3)':'rgba(255,214,150,.55)';app.ctx.lineWidth=1.3;app.ctx.setLineDash([9,6]);app.ctx.lineDashOffset=t*(i?-24:30);app.ctx.beginPath();app.ctx.ellipse(hx,hy+i*5,26+i*9,(26+i*9)*.3,0,0,TAU);app.ctx.stroke()}app.ctx.restore()}
    lounge(u(.3),w(1.86),1.6,3.2);potPlant(u(1.9),w(.32),1.6,.7);
    }
/* painted buildings (#55): pictures, not canvas drawing. k = world px per picture px (the platform fills the footprint),
   (ax,ay) = the platform centre on the ground in the picture. One picture for every level for now; level pictures come later */
const pic=(src,k,ax,ay)=>{const img=new Image();img.src=src;return{img,k,ax,ay}};
export const PICS={hq:pic(hqUrl,136/588,294,656),hacker:pic(hackerUrl,68/852,426,686),drill:pic(drillUrl,68/791,395,369),mine:pic(mineUrl,68/826,413,385),
  hangar:pic(hangarUrl,136/959,480,530),spaceport:pic(spaceportUrl,136/989,494,620)};
/* every painted building can still be switched back to its canvas drawing: style 'classic' (the HQ picks among its designs) */
export const PSTYLES=[{id:'painted',n:'New'},{id:'classic',n:'Classic'}];
export const picOf=b=>(b.type==='hq'?hqStyle(b)!=='helix':b.style==='classic')?null:PICS[b.type];
/* draws the building's picture; false when it has none */
function drawPic(b,cx,cy){const p=picOf(b);if(!p)return false;if(p.img.complete){const[px,py]=P(cx,cy);app.ctx.drawImage(p.img,px-p.ax*p.k,py-p.ay*p.k,p.img.naturalWidth*p.k,p.img.naturalHeight*p.k)}return true}
export const HQSTYLES=[{id:'helix',n:'Helix Tower'},{id:'spire',n:'Twisted Spire'},{id:'villa',n:'Villa Tower'},{id:'glass',n:'Glass Tower'}];
export const hqStyle=b=>b.style||'helix';
app.thumbMode=false;
export function hqDims(L){const H=58+Math.min(L,8)*9,zt=1.7+H;return{H,tf:0,zt,z3:zt,top:zt}}
/* organic tower: warm glass core wrapped by twisting white ribs */
function hqProfile(f){let r=.23+.36*Math.exp(-Math.pow(f/.09,2))+.08*Math.sin(Math.PI*Math.min(1,f/.8));if(f>.62)r*=Math.pow(Math.max(0,(1-f)/.38),.85);return Math.max(r,.004)}
function organicTower(cx,cy,z0,H,sc,seed,t,lit){
  const N=64,E=(f)=>{const r=hqProfile(f)*sc;const[x,y]=P(cx,cy,z0+f*H);return{x,y,rx:r*HW*1.414,ry:r*HH*1.414,f}};
  const S=[];for(let k=0;k<=N;k++)S.push(E(k/N));
  const sil=()=>{app.ctx.beginPath();app.ctx.moveTo(S[0].x-S[0].rx,S[0].y);for(const s of S)app.ctx.lineTo(s.x-s.rx,s.y);for(let k=N;k>=0;k--){const s=S[k];app.ctx.lineTo(s.x+s.rx,s.y)}app.ctx.ellipse(S[0].x,S[0].y,S[0].rx,S[0].ry,0,0,Math.PI);app.ctx.closePath()};
  // curtain-wall glass: blue tint, sky reflected at the grazing edges, interior visible where it faces you
  for(let k=0;k<N;k++){const a=S[k],b=S[k+1];if(a.rx<.4)continue;
    const g=app.ctx.createLinearGradient(a.x-a.rx,0,a.x+a.rx,0);
    g.addColorStop(0,'#dff3ff');g.addColorStop(.07,'#7fc4ec');g.addColorStop(.16,'#5aa6d8');g.addColorStop(.2,'#f4fbff');g.addColorStop(.235,'#78bde6');
    g.addColorStop(.42,'#3f8cc4');g.addColorStop(.62,'#2f74ad');g.addColorStop(.69,'#6fb4e0');g.addColorStop(.72,'#33789f');g.addColorStop(.9,'#245a8a');g.addColorStop(1,'#5b9ccc');
    app.ctx.fillStyle=g;app.ctx.beginPath();app.ctx.moveTo(a.x-a.rx,a.y+.5);app.ctx.lineTo(b.x-b.rx,b.y-.5);app.ctx.lineTo(b.x+b.rx,b.y-.5);app.ctx.lineTo(a.x+a.rx,a.y+.5);app.ctx.closePath();app.ctx.fill()}
  {const s=S[0];const g=app.ctx.createLinearGradient(s.x-s.rx,0,s.x+s.rx,0);g.addColorStop(0,'#7fc4ec');g.addColorStop(.4,'#3a7fb5');g.addColorStop(1,'#1f4f7a');app.ctx.fillStyle=g;app.ctx.beginPath();app.ctx.ellipse(s.x,s.y,s.rx,s.ry,0,0,Math.PI);app.ctx.fill()}
  app.ctx.save();sil();app.ctx.clip();
  // the sky reflects in the upper floors, the dark ground in the lower ones
  {const top=S[N].y,bot=S[0].y;const g=app.ctx.createLinearGradient(0,top,0,bot);g.addColorStop(0,'rgba(225,242,255,.5)');g.addColorStop(.45,'rgba(225,242,255,.08)');g.addColorStop(.8,'rgba(12,40,70,0)');g.addColorStop(1,'rgba(12,40,70,.3)');app.ctx.fillStyle=g;app.ctx.fillRect(S[0].x-S[0].rx-30,top-4,S[0].rx*2+60,bot-top+8)}
  // soft cloud reflections drifting across the facade
  for(let i=0;i<3;i++){const k=Math.floor(N*(.25+i*.2)),s=S[k];if(!s||s.rx<2)continue;const cxr=s.x-s.rx*(.2-i*.25)+Math.sin(t*.15+i)*s.rx*.15;
    const g=app.ctx.createRadialGradient(cxr,s.y,0,cxr,s.y,s.rx*.7);g.addColorStop(0,'rgba(235,247,255,.22)');g.addColorStop(1,'rgba(235,247,255,0)');app.ctx.fillStyle=g;app.ctx.beginPath();app.ctx.ellipse(cxr,s.y,s.rx*.7,s.rx*.35,0,0,TAU);app.ctx.fill()}
  // floor slabs (spandrels) and lit rooms behind the glass
  const rr=rng(seed*97+3);
  const kk=Math.max(3,Math.round(FLOOR/(H/N)));
  for(let k=2;k<N-3;k+=kk){const s=S[k];if(s.rx<3)continue;
    app.ctx.strokeStyle='rgba(20,50,80,.55)';app.ctx.lineWidth=1.1;app.ctx.beginPath();app.ctx.ellipse(s.x,s.y,s.rx,s.ry,0,.04,Math.PI-.04);app.ctx.stroke();
    app.ctx.strokeStyle='rgba(220,240,255,.4)';app.ctx.lineWidth=.4;app.ctx.beginPath();app.ctx.ellipse(s.x,s.y-.8,s.rx*.995,s.ry*.995,0,.15,Math.PI-.15);app.ctx.stroke();
    const s2=S[Math.min(N,k+kk-1)];
    for(let j=0;j<6;j++){if(rr()<.45)continue;const c0=-.85+rr()*1.55,c1=Math.min(.9,c0+.1+rr()*.12);const vis=1-Math.abs((c0+c1)/2);
      const p0=[s.x+s.rx*c0,s.y+s.ry*Math.sqrt(1-c0*c0)-1],p1=[s.x+s.rx*c1,s.y+s.ry*Math.sqrt(1-c1*c1)-1],h=Math.max(1.2,(s.y-s2.y)*.7);
      app.ctx.fillStyle=`rgba(190,240,255,${.25+.5*vis})`;app.ctx.beginPath();app.ctx.moveTo(p0[0],p0[1]);app.ctx.lineTo(p1[0],p1[1]);app.ctx.lineTo(p1[0],p1[1]-h);app.ctx.lineTo(p0[0],p0[1]-h);app.ctx.closePath();app.ctx.fill();
      if(lit&&!app.thumbMode)litQ([[p0[0],p0[1]-h],[p1[0],p1[1]-h],[p1[0],p1[1]],[p0[0],p0[1]]])}}
  // mullions
  for(let c=-.88;c<=.89;c+=.16){app.ctx.strokeStyle='rgba(14,40,70,.3)';app.ctx.lineWidth=.45;app.ctx.beginPath();S.forEach((s,k)=>{const x=s.x+s.rx*c,y=s.y+s.ry*Math.sqrt(1-c*c);k?app.ctx.lineTo(x,y):app.ctx.moveTo(x,y)});app.ctx.stroke()}
  // crisp vertical sun streak
  {app.ctx.strokeStyle='rgba(255,250,240,.55)';app.ctx.lineWidth=1;app.ctx.beginPath();S.forEach((s,k)=>{const c=-.6,x=s.x+s.rx*c,y=s.y+s.ry*Math.sqrt(1-c*c);k?app.ctx.lineTo(x,y):app.ctx.moveTo(x,y)});app.ctx.stroke()}
  app.ctx.restore();
  sil();app.ctx.strokeStyle='rgba(30,60,95,.55)';app.ctx.lineWidth=.8;app.ctx.stroke();
  // twisting white ribs with thickness, a lit face and a soft contact shadow on the glass
  const RIBS=[[0,2.1,.36,.55,1],[1,2.1,.36,.55,1],[2,2.1,.36,.55,1],[3,2.1,.36,.55,1],[.5,-1.7,.09,.12,0],[2.5,-1.7,.09,.12,0]];
  for(const[i,tw,db,dfl,big]of RIBS){
    const th=f=>i*TAU/4+tw*f+seed,dl=f=>(db+dfl*Math.exp(-Math.pow(f/.16,2)))*(big?(.78+.22*Math.sin(f*9+i*2)):1);
    const R=big?1.09:1.05;
    for(let k=0;k<N;k++){const f0=k/N,f1=(k+1)/N,s0=S[k],s1=S[k+1];if(s1.rx<.3)continue;
      const a0=th(f0)-dl(f0),a1=th(f0)+dl(f0),b0=th(f1)-dl(f1),b1=th(f1)+dl(f1);
      const mid=Math.sin((a0+a1+b0+b1)/4);if(mid<-.08)continue;
      const at=(s,a,r)=>[s.x+Math.cos(a)*s.rx*r,s.y+Math.sin(a)*s.ry*r];
      // contact shadow on the glass along the shaded edge
      {const q=[at(s0,a0,1),at(s0,a0-.13,1),at(s1,b0-.13,1),at(s1,b0,1)];poly(q,'rgba(20,50,90,.2)',false)}
      // side wall of the rib (its thickness)
      if(Math.abs(Math.cos(a0))<.78){const q=[at(s0,a0,R),at(s0,a0,1),at(s1,b0,1),at(s1,b0,R)];poly(q,'#aab3b8',false);app.ctx.strokeStyle='#aab3b8';app.ctx.lineWidth=.5;app.ctx.stroke()}
      const M=4,pts=[];for(let j=0;j<=M;j++)pts.push(at(s0,a0+(a1-a0)*j/M,R));for(let j=M;j>=0;j--)pts.push(at(s1,b0+(b1-b0)*j/M,R));
      const am=(a0+a1)/2,lite=.5-.5*Math.cos(am),v=Math.round(212+43*lite);
      app.ctx.beginPath();app.ctx.moveTo(pts[0][0],pts[0][1]);for(const p of pts.slice(1))app.ctx.lineTo(p[0],p[1]);app.ctx.closePath();
      const g=app.ctx.createLinearGradient(pts[0][0],pts[0][1],pts[M][0],pts[M][1]);g.addColorStop(0,`rgb(${v-24},${v-20},${v-16})`);g.addColorStop(.65,'#ffffff');g.addColorStop(1,`rgb(${v},${Math.min(255,v+1)},${Math.min(255,v+3)})`);
      app.ctx.fillStyle=g;app.ctx.fill();app.ctx.strokeStyle=g;app.ctx.lineWidth=.6;app.ctx.stroke();
      app.ctx.lineCap='round';app.ctx.strokeStyle='rgba(85,95,102,.6)';app.ctx.lineWidth=.7;app.ctx.beginPath();app.ctx.moveTo(pts[0][0],pts[0][1]);app.ctx.lineTo(pts[pts.length-1][0],pts[pts.length-1][1]);app.ctx.stroke();
      app.ctx.strokeStyle='rgba(255,255,255,.95)';app.ctx.lineWidth=.7;app.ctx.beginPath();app.ctx.moveTo(pts[1][0],pts[1][1]);app.ctx.lineTo(pts[pts.length-2][0],pts[pts.length-2][1]);app.ctx.stroke();app.ctx.lineCap='butt'}}
  // glint at the tip
  {const s=S[N-3];app.ctx.save();app.ctx.globalCompositeOperation='lighter';const g=app.ctx.createRadialGradient(s.x-1,s.y,0,s.x-1,s.y,6);g.addColorStop(0,'rgba(255,255,255,.9)');g.addColorStop(1,'rgba(255,240,210,0)');app.ctx.fillStyle=g;app.ctx.fillRect(s.x-7,s.y-6,12,12);app.ctx.restore()}
  return S;
}
/* the Command Center's look from colony levels 12, 15 and 20, on top of any design */
function hqTier(b,t,cx,cy){
  const L=b.lvl,top=bHeight(b),[x,y]=P(cx,cy,top);
  if(L>=20){app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.fillStyle=lg([x,y-220],[x,y],[[0,'rgba(255,214,120,0)'],[1,'rgba(255,214,120,.45)']]);app.ctx.beginPath();app.ctx.moveTo(x-3,y-220);app.ctx.lineTo(x+3,y-220);app.ctx.lineTo(x+9,y);app.ctx.lineTo(x-9,y);app.ctx.closePath();app.ctx.fill();app.ctx.restore()}
  // level 12: a mast with a dish and a beacon
  line([x,y+6],[x,y-24],'#e8eef0',1.8);
  app.ctx.save();app.ctx.translate(x,y-12);app.ctx.rotate(-.5+.2*Math.sin(t*.4));app.ctx.fillStyle=lg([-9,0],[9,0],[[0,'#ffffff'],[1,'#a3adb2']]);app.ctx.beginPath();app.ctx.ellipse(0,0,9,3.6,0,0,TAU);app.ctx.fill();app.ctx.strokeStyle=OUT;app.ctx.lineWidth=.8;app.ctx.stroke();app.ctx.restore();
  app.ctx.fillStyle=(Math.floor(t*2)%2)?'#5ff3ff':'#1c5a66';app.ctx.beginPath();app.ctx.arc(x,y-25,2.4,0,TAU);app.ctx.fill();
  // level 15: two station rings around the tower, with pods going round
  if(L>=15)for(const[f,rx,dir]of[[.5,50,1],[.78,36,-1]]){const[px,py]=P(cx,cy,top*f),ry=rx*.42,col=L>=20?'#ffd34a':'#5ff3ff';
    app.ctx.strokeStyle=col;app.ctx.lineWidth=2.2;app.ctx.beginPath();app.ctx.ellipse(px,py,rx,ry,0,0,Math.PI);app.ctx.stroke();
    app.ctx.globalAlpha=.35;app.ctx.beginPath();app.ctx.ellipse(px,py,rx,ry,0,Math.PI,TAU);app.ctx.stroke();app.ctx.globalAlpha=1;
    for(let i=0;i<4;i++){const a=i/4*TAU+t*.5*dir;app.ctx.fillStyle='#ffffff';app.ctx.beginPath();app.ctx.arc(px+Math.cos(a)*rx,py+Math.sin(a)*ry,2.2,0,TAU);app.ctx.fill()}}
  // level 20: a golden crown
  if(L>=20){app.ctx.fillStyle=lg([x-14,y-6],[x+14,y+6],[[0,'#fff1b8'],[.5,'#ffc94a'],[1,'#b8862a']]);app.ctx.beginPath();app.ctx.moveTo(x-14,y+6);for(let i=0;i<=4;i++){const u=x-14+i*7;app.ctx.lineTo(u,y-(i%2?3:10))}app.ctx.lineTo(x+14,y+6);app.ctx.closePath();app.ctx.fill();app.ctx.strokeStyle='rgba(90,60,10,.6)';app.ctx.lineWidth=.8;app.ctx.stroke()}
}
/* corridors: habitats and greenhouses side by side join up, each drawing its half of the tube */
const LINK={habitat:1,greenhouse:1},DIRS=[[1,0],[0,1],[-1,0],[0,-1]];
/** which sides (east, south, west, north) have a joined neighbour, as '0101'; part of the bake key */
export function links(b){if(!LINK[b.type]||!app.S||b.state==='building')return'';
  return DIRS.map(([dx,dy])=>app.S.b.some(o=>o!==b&&LINK[o.type]&&o.state!=='building'&&o.gx===b.gx+dx&&o.gy===b.gy+dy)?1:0).join('')}
function hull(pts){pts=pts.slice().sort((p,q)=>p[0]-q[0]||p[1]-q[1]);const cr=(o,a,b)=>(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]);
  const half=list=>{const h=[];for(const p of list){while(h.length>=2&&cr(h[h.length-2],h[h.length-1],p)<=0)h.pop();h.push(p)}h.pop();return h};
  return half(pts).concat(half(pts.slice().reverse()))}
/** a barrel vault lying on the ground from grid point a to b (along x or y); glass shows what grows inside */
function vault(a,b,r,z0,glass,seed){
  const len=Math.hypot(b[0]-a[0],b[1]-a[1]),ux=(b[0]-a[0])/len,uy=(b[1]-a[1])/len,px=Math.abs(uy),py=Math.abs(ux),zr=r*HW*1.15,N=12;
  const at=(g,th)=>P(g[0]+px*r*Math.cos(th),g[1]+py*r*Math.cos(th),z0+zr*Math.sin(th));
  const arc=(g,t0=0,t1=Math.PI)=>{const o=[];for(let i=0;i<=N;i++)o.push(at(g,t0+(t1-t0)*i/N));return o};
  const sh=hull(arc(a).concat(arc(b))),top=Math.min(...sh.map(p=>p[1])),bot=Math.max(...sh.map(p=>p[1]));
  if(glass){
    poly([P(a[0]+px*r,a[1]+py*r,z0),P(b[0]+px*r,b[1]+py*r,z0),P(b[0]-px*r,b[1]-py*r,z0),P(a[0]-px*r,a[1]-py*r,z0)],'#4a3426',false);
    // two beds of greens down the length, the far row first
    const rr=rng(seed),greens=['#2f7d3a','#3f9a4c','#58b95e','#86dd78'],n=Math.max(3,Math.round(len*14));
    for(const side of[-.45,.45])for(let i=0;i<n;i++){const f=(i+.5)/n,g=[a[0]+(b[0]-a[0])*f+px*r*side,a[1]+(b[1]-a[1])*f+py*r*side],[x,y]=P(g[0],g[1],z0+.5),s=1.6+rr()*1.3;
      app.ctx.fillStyle=greens[Math.floor(rr()*4)];app.ctx.beginPath();app.ctx.arc(x,y-s*.6,s,0,TAU);app.ctx.arc(x+s*.8,y-s*.2,s*.7,0,TAU);app.ctx.fill();
      if(rr()<.25){app.ctx.fillStyle=rr()<.5?'#ff8ad8':'#ffb347';app.ctx.beginPath();app.ctx.arc(x+.6,y-s,.9,0,TAU);app.ctx.fill()}}}
  poly(sh,lg([0,top],[0,bot],glass?[[0,'rgba(240,252,255,.55)'],[.45,'rgba(190,232,245,.16)'],[1,'rgba(120,180,205,.3)']]:[[0,'#ffffff'],[.55,'#eef1f3'],[1,'#bcc6cc']]),false);
  // ribs: only the half that faces the viewer on a solid tube
  const ribs=Math.max(2,Math.round(len*9));app.ctx.lineWidth=glass?.7:.6;app.ctx.strokeStyle=glass?'rgba(245,252,255,.75)':'rgba(140,152,160,.7)';
  for(let i=0;i<=ribs;i++){const f=i/ribs,g=[a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f],pt=arc(g,0,glass?Math.PI:Math.PI*.62);app.ctx.beginPath();pt.forEach((p,k)=>k?app.ctx.lineTo(p[0],p[1]):app.ctx.moveTo(p[0],p[1]));app.ctx.stroke()}
  line(at(a,Math.PI*.42),at(b,Math.PI*.42),'rgba(255,255,255,.85)',1.1);
  if(!glass)neon(at(a,Math.PI*.2),at(b,Math.PI*.2),BLUEN,.8);
  // the end facing the viewer
  {const e=ux+uy>0?b:a,c=arc(e);poly(c,glass?'rgba(200,236,248,.35)':'#dfe4e7',false);app.ctx.strokeStyle=glass?'rgba(255,255,255,.8)':'#aab4ba';app.ctx.lineWidth=.9;app.ctx.beginPath();c.forEach((p,k)=>k?app.ctx.lineTo(p[0],p[1]):app.ctx.moveTo(p[0],p[1]));app.ctx.stroke()}
}
/** corridor stubs from the middle of a 1x1 building to each joined side; back ones go under the building, front ones over it */
function corridors(b,front,from){const lk=links(b);if(!lk)return;const cx=b.gx+.5,cy=b.gy+.5,gl=b.type==='greenhouse';
  DIRS.forEach(([dx,dy],i)=>{if(lk[i]!=='1'||(i<2)!==front)return;vault([cx+dx*from,cy+dy*from],[cx+dx*.5,cy+dy*.5],gl?.2:.13,1.6,gl,b.id*7+i)})}
export function drawBuilding(b,t){app.TEX=!app.thumbMode;try{drawBuildingInner(b,t)}finally{app.TEX=false}}
function drawBuildingInner(b,t){
  const d=DEF[b.type],s=d.size,x0=b.gx,y0=b.gy,x1=x0+s,y1=y0+s,cx=x0+s/2,cy=y0+s/2,L=b.lvl;
  if(b.state==='building'){drawScaffold(b);return}
  const night=false,joins=b.type==='habitat'||(b.type==='greenhouse'&&L>=5);
  if(joins)corridors(b,false,.3);
  if(!drawPic(b,cx,cy))switch(b.type){
  case'hq':{
    {const st=hqStyle(b);if(st==='villa'){hqVilla(b,t);break}if(st==='glass'){hqGlass(b,t);break}}
    pad(x0+.04,y0+.04,x1-.04,y1-.04);
    const Hd=hqDims(L),H=Hd.H,zb=1.7;
    // reflecting pool around the base
    {const[px,py]=P(cx,cy,zb);const rx=.9*HW*1.414,ry=.9*HH*1.414;
      app.ctx.fillStyle='#f4f2ee';app.ctx.beginPath();app.ctx.ellipse(px,py,rx+3,ry+1.6,0,0,TAU);app.ctx.fill();
      app.ctx.fillStyle=lg([px,py-ry],[px,py+ry],[[0,'#a9e3ea'],[1,'#4aa9c0']]);app.ctx.beginPath();app.ctx.ellipse(px,py,rx,ry,0,0,TAU);app.ctx.fill();
      app.ctx.strokeStyle='rgba(255,255,255,.55)';app.ctx.lineWidth=1;for(let i=0;i<3;i++){const ph=(t*.25+i/3)%1;app.ctx.globalAlpha=1-ph;app.ctx.beginPath();app.ctx.ellipse(px,py,rx*(.45+ph*.5),ry*(.45+ph*.5),0,0,TAU);app.ctx.stroke()}app.ctx.globalAlpha=1}
    // reflection of the tower shimmering in the pool
    {const[px,py]=P(cx,cy,zb);const rx=.9*HW*1.414,ry=.9*HH*1.414;app.ctx.save();app.ctx.beginPath();app.ctx.ellipse(px,py,rx,ry,0,0,TAU);app.ctx.clip();
      for(let i=0;i<9;i++){const yy=py+4+i*2.2,w=(12-i)*1.4+Math.sin(t*2+i)*1.5;app.ctx.fillStyle=`rgba(255,214,160,${.32-i*.03})`;app.ctx.fillRect(px-w/2+Math.sin(t*1.7+i*.8)*1.5,yy,w,1.3)}
      app.ctx.fillStyle='rgba(255,255,255,.35)';for(let i=0;i<6;i++){const a=i*1.1+t*.2;app.ctx.fillRect(px+Math.cos(a)*rx*.7,py+Math.sin(a)*ry*.7,4,.8)}app.ctx.restore()}
    potPlant(x1-.12,y0+.3,1.6,.7);potPlant(x0+.3,y0+.12,1.6,.7);
    if(L>=5)organicTower(x0+1.62,y0+.4,zb,H*.48,.5,1.4,t,true);
    {cyl(cx,cy,.68,zb,1.4,'#f6f5f2','#dcd9d3');cyl(cx,cy,.63,zb+1.4,1.2,'#ffffff','#e6e4df')}
    organicTower(cx,cy,zb+2.6,H,1,0,t,true);
    // glowing entrance at the foot of the tower
    {const[ex,ey]=P(cx+.47,cy+.47,zb+2.6);app.EMIT++;app.ctx.fillStyle=lg([ex,ey-9],[ex,ey],[[0,'#fff3dc'],[1,'#e9a35a']]);app.ctx.beginPath();app.ctx.moveTo(ex-5,ey);app.ctx.quadraticCurveTo(ex-5,ey-10,ex,ey-10);app.ctx.quadraticCurveTo(ex+5,ey-10,ex+5,ey);app.ctx.closePath();app.ctx.fill();app.EMIT--}
    // glass geodesic dome beside the tower
    if(L>=2){const gx=x0+.38,gy=y1-.38,R=.3;const[bx,by]=P(gx,gy,zb);const rx=R*HW*1.414,ry=R*HH*1.414,hz=rx*.95;
      const shell=()=>{app.ctx.beginPath();app.ctx.ellipse(bx,by,rx,hz,0,Math.PI,0);app.ctx.ellipse(bx,by,rx,ry,0,0,Math.PI);app.ctx.closePath()};
      app.EMIT++;shell();{const g=app.ctx.createRadialGradient(bx-rx*.3,by-hz*.6,1,bx,by-hz*.3,rx*1.1);g.addColorStop(0,'#ffffff');g.addColorStop(.4,'#cfeeff');g.addColorStop(1,'#6fb4dc');app.ctx.fillStyle=g;app.ctx.fill()}app.EMIT--;
      app.ctx.save();shell();app.ctx.clip();app.ctx.strokeStyle='rgba(255,255,255,.85)';app.ctx.lineWidth=.8;
      for(const f of[.3,.58,.82]){const q=Math.sqrt(1-f*f);app.ctx.beginPath();app.ctx.ellipse(bx,by-hz*f,rx*q,ry*q,0,0,Math.PI);app.ctx.stroke()}
      for(let i=1;i<6;i++){const k=-1+2*i/6;app.ctx.beginPath();app.ctx.ellipse(bx,by,Math.abs(k)*rx+.01,hz,0,Math.PI,0);app.ctx.stroke()}app.ctx.restore();
      app.ctx.strokeStyle='#ffffff';app.ctx.lineWidth=1.6;app.ctx.beginPath();app.ctx.ellipse(bx,by,rx,ry,0,0,Math.PI);app.ctx.stroke();
      app.ctx.fillStyle='rgba(255,255,255,.6)';app.ctx.beginPath();app.ctx.ellipse(bx-rx*.38,by-hz*.6,rx*.2,hz*.08,-.6,0,TAU);app.ctx.fill()}
    // spire and halo
    const ztop=zb+H;
    if(L>=6){const sb=P(cx,cy,ztop-1),sp=[sb[0],sb[1]-22];app.ctx.lineCap='round';line(sb,sp,'#ffffff',2.2);app.ctx.lineCap='butt';app.ctx.fillStyle=(Math.floor(t*1.5)%2)?'#ff4d5a':'#5a1a20';app.ctx.beginPath();app.ctx.arc(sp[0],sp[1]-1,2.4,0,TAU);app.ctx.fill()}
    if(L>=8){const[hx,hy]=P(cx,cy,ztop-H*.18);app.ctx.save();app.ctx.globalCompositeOperation='lighter';for(let i=0;i<2;i++){app.ctx.strokeStyle=i?'rgba(255,214,150,.3)':'rgba(255,214,150,.55)';app.ctx.lineWidth=1.3;app.ctx.setLineDash([9,6]);app.ctx.lineDashOffset=t*(i?-24:30);app.ctx.beginPath();app.ctx.ellipse(hx,hy+i*5,22+i*9,(22+i*9)*.3,0,0,TAU);app.ctx.stroke()}app.ctx.restore()}
    lounge(x1-.2,y1-.1,1.6,3.2);
    break}
  case'habitat':{
    {const st=b.style||'dome';if(st!=='classic'){habStyle(st,b,t);break}}
    pad(x0+.06,y0+.06,x1-.06,y1-.06);
    let z=2;const fl=Math.min(L,5);
    for(let r=0;r<fl;r++){const ins=.14+r*.035,h=r===0?12:9;const Pp=oct(x0+ins,y0+ins,x1-ins,y1-ins,.13);
      extrude(Pp,z,h,W1,W2,W3);glassBand(Pp,z+2.5,z+h-2.5,b.id*3+r,.11);
      if(r===0){const q=[P(cx-.1,y1-ins,z+9),P(cx+.1,y1-ins,z+9),P(cx+.1,y1-ins,z),P(cx-.1,y1-ins,z)];poly(q,lg(q[0],q[3],[[0,'#fff1d6'],[1,'#e8a35c']]),false);neon(q[0],q[1],NEONC,.8)}
      z+=h;const S2=oct(x0+ins-.02,y0+ins-.02,x1-ins+.02,y1-ins+.02,.14);extrude(S2,z,1.6,GR2,GR1,GR3,{noEdge:true});neonEdges(S2,z+.8,NEONC,.6);z+=1.6}
    if(L>=6)dome(cx,cy,.2,z,'rgba(160,235,200,.75)',5);else dome(cx,cy,.16,z,'rgba(225,236,238,.92)',4);
    const ab=P(x1-.32,y0+.34,z),ah=L>=7?22:10;line(ab,[ab[0],ab[1]-ah],'#d6dcdf',1);
    if(L>=8){app.ctx.fillStyle=(Math.floor(t*2+b.id)%2)?'#ff4d5a':'#5a1a20';app.ctx.beginPath();app.ctx.arc(ab[0],ab[1]-ah,1.8,0,TAU);app.ctx.fill()}
    break}
  case'solar':{
    pad(x0+.08,y0+.08,x1-.08,y1-.08);
    const rows=Math.min(L,3),span=.72/rows,dusty=!app.thumbMode&&stormLeft()>0; // dust covers the cells during a storm (#40)
    for(let r=0;r<rows;r++){const a=y0+.14+r*span,bb=a+span-.05;
      for(const u of[x0+.2,x1-.2]){line(P(u,(a+bb)/2,2),P(u,(a+bb)/2,10),'#7b868d',1.4)}
      const p=[P(x0+.12,a,15),P(x1-.12,a,15),P(x1-.12,bb,7),P(x0+.12,bb,7)];
      poly(p,lg(p[0],p[2],L>=6?[[0,'#4a5fb0'],[.5,'#22357a'],[1,'#151f52']]:[[0,'#33508c'],[.5,'#1b2f5e'],[1,'#13234a']]),L>=4?'#e2c46a':'#c8d0d4');
      if(dusty){const k=tech('panels')?.45:1;poly(p,lg(p[0],p[2],[[0,`rgba(214,150,104,${.78*k})`],[1,`rgba(150,92,60,${.7*k})`]]),false)}
      app.ctx.strokeStyle='rgba(255,214,150,.38)';app.ctx.lineWidth=.5;app.ctx.beginPath();
      for(let i=1;i<6;i++){const u=x0+.12+i*(.76/6);const q1=P(u,a,15),q2=P(u,bb,7);app.ctx.moveTo(q1[0],q1[1]);app.ctx.lineTo(q2[0],q2[1])}
      for(let i=1;i<3;i++){const f=i/3,v=a+(bb-a)*f,zz=15-8*f;const q1=P(x0+.12,v,zz),q2=P(x1-.12,v,zz);app.ctx.moveTo(q1[0],q1[1]);app.ctx.lineTo(q2[0],q2[1])}app.ctx.stroke();
      const sw=((t*.15+b.id*.3+r*.2)%1.4)-.2;if(!dusty&&sw>0&&sw<1){const u=x0+.12+.76*sw;app.ctx.save();poly(p,null,false);app.ctx.clip();
        const q1=P(u,a,15),q2=P(u+.12,bb,7);app.ctx.strokeStyle='rgba(255,255,255,.35)';app.ctx.lineWidth=5;app.ctx.beginPath();app.ctx.moveTo(q1[0],q1[1]);app.ctx.lineTo(q2[0],q2[1]);app.ctx.stroke();app.ctx.restore()}}
    prism(x1-.24,y1-.2,x1-.1,y1-.08,2,L>=4?11:6,'#dfe3e2','#c3c9ca','#9fa8ab');neon(P(x1-.24,y1-.08,L>=4?9:5),P(x1-.1,y1-.08,L>=4?9:5),NEONC,.7);
    break}
  case'extractor':{
    pad(x0+.06,y0+.06,x1-.06,y1-.06);
    const th=18+Math.min(L,6)*5;
    if(L>=4){cyl(x0+.24,y0+.24,.14,2,th*.6,'#eef1f2','#cfd8dc');dome(x0+.24,y0+.24,.14,2+th*.6,'rgba(236,241,243,1)',0);neonArc(x0+.24,y0+.24,.142,2+th*.3,BLUEN,.8)}
    const tx=cx-.1,ty=cy+.1;
    cyl(tx,ty,.27,2,th,'#eef1f2','#cfd8dc');dome(tx,ty,.27,2+th,'rgba(236,241,243,1)',0);
    // water gauge shows how full the colony's water store is
    {const[gx,gy]=P(tx,ty,2);const ry=.27*HH*1.414;const wb=gy+ry-4,wt=gy+ry-th+3;
      app.ctx.fillStyle='#0f1d28';app.ctx.beginPath();app.ctx.roundRect?app.ctx.roundRect(gx-4,wt,8,wb-wt,3):app.ctx.rect(gx-4,wt,8,wb-wt);app.ctx.fill();
      const lv=app.S?clamp(app.S.res.water/caps().water,.12,1):.6;const wl=wb-(wb-wt)*lv;const g=app.ctx.createLinearGradient(0,wl,0,wb);g.addColorStop(0,'#bff6ff');g.addColorStop(1,'#1f8fd6');
      app.ctx.fillStyle=g;app.ctx.fillRect(gx-2.6,wl+Math.sin(t*2)*.6,5.2,wb-wl);app.ctx.fillStyle='rgba(255,255,255,.35)';app.ctx.fillRect(gx-2.6,wt+2,1.2,wb-wt-4)}
    neonArc(tx,ty,.275,2+th*.28,BLUEN,.9);neonArc(tx,ty,.275,2+th*.82,BLUEN,.9);
    const ph=oct(x1-.4,y0+.12,x1-.1,y0+.42,.06);extrude(ph,2,11,W1,W2,W3);glassBand(ph,5,9,b.id,.2);neonEdges(ph,11,BLUEN,.8);
    const pa=P(cx+.05,cy-.05,8),pb=P(x1-.38,y0+.3,8);app.ctx.lineCap='round';line(pa,pb,'#9aa6ac',3.5);line([pa[0],pa[1]-1],[pb[0],pb[1]-1],'#e2e8eb',1.2);app.ctx.lineCap='butt';
    for(let i=0;i<3;i++){const p2=(t*.5+i/3+b.id*.21)%1;const[px,py]=P(x1-.25,y0+.27,13);app.ctx.fillStyle=`rgba(240,245,250,${.45*(1-p2)})`;app.ctx.beginPath();app.ctx.arc(px+p2*5,py-p2*22,2.5+p2*5,0,TAU);app.ctx.fill()}
    break}
  case'greenhouse':{
    pad(x0+.04,y0+.04,x1-.04,y1-.04);
    // levels 1-4: a glass tube full of greens, lying along the joined neighbours; from level 5 the big garden dome
    if(L<5){const lk=links(b)||'0000',alongY=lk[0]+lk[2]==='00'&&lk[1]+lk[3]!=='00',r=.2+Math.min(L,4)*.02,e=i=>lk[i]==='1'?.5:.4;
      if(L>=2){cyl(x0+.14,y0+.14,.08,1.6,12,'#eef1f2','#cfd8dc');neonArc(x0+.14,y0+.14,.082,10,GREENN,.7)}
      const a=alongY?[cx,cy-e(3)]:[cx-e(2),cy],c=alongY?[cx,cy+e(1)]:[cx+e(0),cy];
      vault(a,c,r,1.6,true,b.id*31+L);
      if(L>=4){const h=1.6+r*HW*1.15;neon(P(a[0],a[1],h),P(c[0],c[1],h),PINKN,.8)}
      break}
    const R=L>=6?.46:.43,zb=6;
    const base=ngon(cx,cy,R+.03,16,0);extrude(base,2,4,GR1,GR2,GR3,{noEdge:true});
    const[bx,by]=P(cx,cy,zb);const rx=R*HW*1.414,ry=R*HH*1.414,hz=rx*1.18;
    // soil bed and a ring path
    app.ctx.fillStyle=lg([bx,by-ry],[bx,by+ry],[[0,'#4b3426'],[1,'#2b1d15']]);app.ctx.beginPath();app.ctx.ellipse(bx,by,rx,ry,0,0,TAU);app.ctx.fill();
    app.ctx.strokeStyle='rgba(225,215,200,.5)';app.ctx.lineWidth=2.4;app.ctx.beginPath();app.ctx.ellipse(bx,by,rx*.5,ry*.5,0,0,TAU);app.ctx.stroke();
    // grow lights wash the interior
    {const g=app.ctx.createRadialGradient(bx,by-hz*.45,2,bx,by-hz*.4,rx);g.addColorStop(0,'rgba(255,170,240,.28)');g.addColorStop(1,'rgba(170,120,255,0)');app.ctx.fillStyle=g;app.ctx.beginPath();app.ctx.ellipse(bx,by,rx,hz,0,Math.PI,0);app.ctx.ellipse(bx,by,rx,ry,0,0,Math.PI);app.ctx.fill()}
    const rr=rng(b.id*31+7),items=[];
    const greens=['#2f7d3a','#3f9a4c','#58b95e','#86dd78','#2a6e4a'],fruits=['#ff6b6b','#ffb347','#ffe066','#ff8ad8','#b18cff'];
    const nOut=16+Math.min(L,6)*2;
    for(let i=0;i<nOut;i++){const a=i/nOut*TAU+rr()*.25,d=R*(.66+rr()*.2);items.push({x:cx+Math.cos(a)*d,y:cy+Math.sin(a)*d,z:zb,s:2.6+rr()*1.4+Math.min(L,6)*.15,v:rr(),c:greens[Math.floor(rr()*greens.length)],tall:rr()<.25})}
    items.push({tree:true,x:cx,y:cy});
    items.sort((p,q)=>(p.x+p.y)-(q.x+q.y));
    for(const it of items){
      if(it.tree){
        cyl(cx,cy,.17,zb,5,'#e9edef','#c9d0d4');neonArc(cx,cy,.172,zb+5,GREENN,.7);
        const pl=8;for(let i=0;i<pl;i++){const a=i/pl*TAU,[px,py]=P(cx+Math.cos(a)*.11,cy+Math.sin(a)*.11,zb+5);app.ctx.fillStyle=greens[i%5];app.ctx.beginPath();app.ctx.arc(px,py-1.5,2.6,0,TAU);app.ctx.fill()}
        const th=hz*.3+Math.min(L,8)*.3,[tx,ty]=P(cx,cy,zb+5),top=[tx,ty-th];
        app.ctx.strokeStyle=lg([tx-2,0],[tx+2,0],[[0,'#8a5a3a'],[1,'#4e3020']]);app.ctx.lineWidth=3;app.ctx.lineCap='round';app.ctx.beginPath();app.ctx.moveTo(tx,ty);app.ctx.quadraticCurveTo(tx-2,ty-th*.5,top[0],top[1]);app.ctx.stroke();
        app.ctx.lineWidth=1.5;app.ctx.beginPath();app.ctx.moveTo(tx-1,ty-th*.55);app.ctx.lineTo(tx-7,ty-th*.8);app.ctx.moveTo(tx,ty-th*.65);app.ctx.lineTo(tx+6,ty-th*.9);app.ctx.stroke();app.ctx.lineCap='butt';
        const cs=3+Math.min(L,8)*.2,sw=Math.sin(t*1.2+b.id)*.8;
        const blobs=[[-6,2,1],[6,1,1],[0,-4,1.15],[-3,-1,1.1],[4,-3,.95],[0,3,.9],[-8,-3,.8],[8,-4,.8]];
        for(const[dx,dy,k]of blobs){const x=top[0]+dx*cs/6+sw,y=top[1]+dy*cs/6;const g=app.ctx.createRadialGradient(x-cs*.35,y-cs*.4,1,x,y,cs*k);g.addColorStop(0,'#a8ec8a');g.addColorStop(.55,'#4fa956');g.addColorStop(1,'#245c34');app.ctx.fillStyle=g;app.ctx.beginPath();app.ctx.arc(x,y,cs*k,0,TAU);app.ctx.fill()}
        if(L>=3){const fr=rng(b.id+5);for(let i=0;i<5+L;i++){const x=top[0]+(fr()-.5)*cs*2.6+sw,y=top[1]+(fr()-.3)*cs*1.6;app.ctx.fillStyle=L>=6?'#7dfff0':'#ff9a3a';app.ctx.beginPath();app.ctx.arc(x,y,1.3,0,TAU);app.ctx.fill()}}
        continue}
      const[px,py]=P(it.x,it.y,it.z);const sw=Math.sin(t*1.5+it.v*9)*.6;
      if(it.tall){app.ctx.strokeStyle='#3f8f45';app.ctx.lineWidth=1.2;for(let j=-1;j<=1;j++){app.ctx.beginPath();app.ctx.moveTo(px+j*1.5,py);app.ctx.quadraticCurveTo(px+j*2+sw,py-5,px+j*3+sw*1.5,py-8-it.s*.6);app.ctx.stroke()}
        app.ctx.fillStyle='#8ee07a';app.ctx.beginPath();app.ctx.ellipse(px+sw*1.5,py-8-it.s*.6,1.6,3,0,0,TAU);app.ctx.fill()}
      else{const s=it.s;for(const[dx,dy,k]of[[-s*.6,0,.8],[s*.6,0,.8],[0,-s*.5,1]]){app.ctx.fillStyle=it.c;app.ctx.beginPath();app.ctx.arc(px+dx+sw,py+dy-s*.4,s*k,0,TAU);app.ctx.fill()}
        app.ctx.fillStyle='rgba(255,255,255,.18)';app.ctx.beginPath();app.ctx.arc(px-s*.3+sw,py-s*1.1,s*.45,0,TAU);app.ctx.fill();
        if(L>=2&&it.v>.55){app.ctx.fillStyle=fruits[Math.floor(it.v*97)%fruits.length];app.ctx.beginPath();app.ctx.arc(px+s*.4+sw,py-s*.7,1.2,0,TAU);app.ctx.fill()}}
    }
    // drifting mist from the sprinklers
    for(let i=0;i<4;i++){const ph=(t*.12+i/4+b.id*.17)%1;const a=i*1.7+t*.1;app.ctx.fillStyle=`rgba(240,255,250,${.16*Math.sin(ph*Math.PI)})`;app.ctx.beginPath();app.ctx.arc(bx+Math.cos(a)*rx*.45,by-6-ph*hz*.6,4+ph*6,0,TAU);app.ctx.fill()}
    // geodesic glass dome
    const shell=()=>{app.ctx.beginPath();app.ctx.ellipse(bx,by,rx,hz,0,Math.PI,0);app.ctx.ellipse(bx,by,rx,ry,0,0,Math.PI);app.ctx.closePath()};
    shell();{const g=app.ctx.createRadialGradient(bx-rx*.3,by-hz*.6,rx*.05,bx,by-hz*.3,rx*1.1);g.addColorStop(0,'rgba(255,255,255,.5)');g.addColorStop(.3,'rgba(210,255,245,.08)');g.addColorStop(.85,'rgba(150,225,215,.12)');g.addColorStop(1,'rgba(90,170,170,.32)');app.ctx.fillStyle=g;app.ctx.fill()}
    app.ctx.save();shell();app.ctx.clip();
    const lat=[0,.2,.4,.58,.74,.88,1],n=L>=6?14:12;const ring=(j,k)=>{const f=lat[j],q=Math.sqrt(Math.max(0,1-f*f)),a=k/n*TAU+(j%2)*Math.PI/n;return[bx+rx*q*Math.cos(a),by-hz*f+ry*q*Math.sin(a),Math.sin(a)]};
    for(let pass=0;pass<2;pass++){app.ctx.strokeStyle=pass?'rgba(245,252,252,.5)':'rgba(220,240,240,.16)';app.ctx.lineWidth=pass?.7:.5;app.ctx.beginPath();
      for(let j=0;j<lat.length-1;j++)for(let k=0;k<n;k++){const p=ring(j,k),q=ring(j,k+1),u=ring(j+1,k),v=ring(j+1,k+(j%2?1:0)),w2=ring(j+1,k+(j%2?0:-1));
        const front=p[2]>-.05;if(front!==!!pass)continue;
        app.ctx.moveTo(p[0],p[1]);app.ctx.lineTo(q[0],q[1]);app.ctx.moveTo(p[0],p[1]);app.ctx.lineTo(v[0],v[1]);app.ctx.moveTo(p[0],p[1]);app.ctx.lineTo(w2[0],w2[1])}
      app.ctx.stroke()}
    app.ctx.restore();
    app.ctx.fillStyle='rgba(255,255,255,.5)';app.ctx.beginPath();app.ctx.ellipse(bx-rx*.4,by-hz*.62,rx*.2,hz*.08,-.6,0,TAU);app.ctx.fill();
    app.ctx.strokeStyle='rgba(255,255,255,.4)';app.ctx.lineWidth=1.4;app.ctx.beginPath();app.ctx.ellipse(bx,by,rx-1,hz-1,0,-.55,-.05);app.ctx.stroke();
    app.ctx.strokeStyle='#e6ebed';app.ctx.lineWidth=2;app.ctx.beginPath();app.ctx.ellipse(bx,by,rx,ry,0,0,Math.PI);app.ctx.stroke();
    neonArc(cx,cy,R+.03,zb-1,GREENN,1);
    // airlock pod with a lit door
    {const A=oct(x1-.2,cy-.13,x1-.03,cy+.13,.04);extrude(A,2,10,W1,W2,W3);const q=[P(x1-.03,cy+.07,9),P(x1-.03,cy-.07,9),P(x1-.03,cy-.07,2),P(x1-.03,cy+.07,2)];poly(q,lg(q[0],q[3],[[0,'#fff1d6'],[1,'#e8a35c']]),false);neon(q[0],q[1],GREENN,.8)}
    if(L>=3){cyl(x0+.14,y1-.14,.08,2,12,'#eef1f2','#cfd8dc');neonArc(x0+.14,y1-.14,.082,9,BLUEN,.7)}
    if(L>=5){const[lx,ly]=P(cx,cy,zb+hz+12);const s=Math.cos(t*1.3);app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.translate(lx,ly+Math.sin(t*2)*1.5);app.ctx.scale(s,1);
      app.ctx.strokeStyle='rgba(125,255,168,.8)';app.ctx.fillStyle='rgba(125,255,168,.18)';app.ctx.lineWidth=1;app.ctx.beginPath();app.ctx.moveTo(0,6);app.ctx.quadraticCurveTo(-7,-1,0,-8);app.ctx.quadraticCurveTo(7,-1,0,6);app.ctx.fill();app.ctx.stroke();app.ctx.beginPath();app.ctx.moveTo(0,6);app.ctx.lineTo(0,-6);app.ctx.stroke();app.ctx.restore()}
    break}
  case'fashion':{
    patio(x0+.04,y0+.04,x1-.04,y1-.04);
    const B=rrect(x0+.1,y0+.1,x1-.1,y1-.1,.13,4);extrude(B,1.6,16,'#ffffff','#f6f8f8','#cdd5d9',{smooth:true});
    opening('L',y1-.1,x0+.24,x1-.22,2.6,13.4,b.id,{shop:true,noRail:true});
    opening('R',x1-.1,y0+.24,y1-.22,2.6,13.4,b.id+2,{shop:true,noRail:true});
    // glass door on the corner
    {const q=[P(x0+.12,y1-.1,11.4),P(x0+.21,y1-.1,11.4),P(x0+.21,y1-.1,1.6),P(x0+.12,y1-.1,1.6)];poly(q,lg(q[0],q[3],[[0,'#fff6e6'],[1,'#e9b277']]),false);line(q[0],q[3],'#2a2420',.6);if(!app.thumbMode)litQ(q)}
    // slim canopy with a rose trim over both windows
    for(const C of[rrect(x0+.18,y1-.11,x1-.12,y1-.02,.03,2),rrect(x1-.11,y0+.2,x1-.02,y1-.12,.03,2)]){extrude(C,14.2,.8,'#ffffff','#f3f5f6','#cfd7db',{smooth:true})}
    line(P(x0+.2,y1-.02,14.5),P(x1-.12,y1-.02,14.5),'#e9a3b8',1.1);line(P(x1-.02,y1-.13,14.5),P(x1-.02,y0+.21,14.5),'#e9a3b8',1.1);
    app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.globalAlpha=.6;line(P(x0+.2,y1-.03,14.1),P(x1-.12,y1-.03,14.1),'#ffcf8a',1.1);app.ctx.restore();
    let zr=17.6;
    // atelier floor from level 3
    if(L>=3){const U=rrect(x0+.2,y0+.2,x1-.2,y1-.2,.12,4);extrude(U,zr,11,'#ffffff','#f6f8f8','#cdd5d9',{smooth:true});
      opening('L',y1-.2,x0+.32,x1-.32,zr+2,zr+9,b.id+4,{shop:true});opening('R',x1-.2,y0+.32,y1-.32,zr+2,zr+9,b.id+6,{});zr+=11}
    // rooftop runway with a row of lights
    if(L>=5){const a=P(x0+.34,cy,zr+.1),c=P(x1-.3,cy,zr+.1);app.ctx.lineCap='round';line(a,c,'#3a2e2a',3.2);app.ctx.lineCap='butt';
      for(let i=0;i<=5;i++){const u=x0+.34+(x1-.64)*i/5;const p=P(u,cy-.06,zr+.3),q=P(u,cy+.06,zr+.3);const on=(Math.floor(t*4)+i)%3===0;
        for(const r of[p,q]){app.ctx.fillStyle=on?'#fff2c8':'#e0a83a';app.ctx.beginPath();app.ctx.arc(r[0],r[1],on?1.2:.8,0,TAU);app.ctx.fill()}}
      const m=P(x1-.36,cy,zr);app.ctx.fillStyle='#e86a9a';app.ctx.beginPath();app.ctx.moveTo(m[0]-1.2,m[1]-7);app.ctx.lineTo(m[0]+1.2,m[1]-7);app.ctx.lineTo(m[0]+2.6,m[1]-1.6);app.ctx.lineTo(m[0]-2.6,m[1]-1.6);app.ctx.closePath();app.ctx.fill();app.ctx.fillStyle='#f3e7da';app.ctx.beginPath();app.ctx.arc(m[0],m[1]-8.2,1.1,0,TAU);app.ctx.fill();
      potPlant(x0+.28,y0+.28,zr,.7)}
    // rooftop sign with a glowing hanger
    {const[sx,sy]=P(x1-.3,y1-.3,zr);const hc=L>=4?'#ffd27a':'#ffc2d6',w=9,h=8;
      line([sx-w*.6,sy],[sx-w*.6,sy-3],'#cfd6d9',1);line([sx+w*.6,sy],[sx+w*.6,sy-3],'#cfd6d9',1);
      app.ctx.fillStyle='#2a2420';app.ctx.beginPath();app.ctx.roundRect?app.ctx.roundRect(sx-w,sy-3-h,w*2,h,2):app.ctx.rect(sx-w,sy-3-h,w*2,h);app.ctx.fill();
      const hy=sy-3-h+1.6;neon([sx,hy],[sx,hy+1.4],hc,.8);neon([sx,hy+1.4],[sx-5,hy+5],hc,.8);neon([sx-5,hy+5],[sx+5,hy+5],hc,.8);neon([sx+5,hy+5],[sx,hy+1.4],hc,.8);
      app.ctx.strokeStyle=hc;app.ctx.lineWidth=.8;app.ctx.beginPath();app.ctx.arc(sx+.9,hy-.4,1,Math.PI*.9,Math.PI*2.2);app.ctx.stroke()}
    // shopping bags and planters on the patio
    {const bags=[['#e86a9a',x0+.3],['#e0a83a',x0+.38],['#3fb5ad',x0+.46]];for(const[c,u]of bags){const[bx,by]=P(u,y1-.04,1.6);app.ctx.fillStyle=c;app.ctx.fillRect(bx-1.5,by-4,3,3.4);app.ctx.strokeStyle='rgba(60,40,30,.6)';app.ctx.lineWidth=.5;app.ctx.beginPath();app.ctx.arc(bx,by-4,1,Math.PI,0);app.ctx.stroke()}}
    potPlant(x1-.06,y1-.08,1.6,.7);
    break}
  case'storage':{
    pad(x0+.05,y0+.05,x1-.05,y1-.05);
    const cl=['#ffffff','#e4dfd8','#f3f5f6','#d6d0c7'],nc=[NEONC,AMBER,NEONC,AMBER];
    const box=(a,b2,c,dd,z,i)=>{const Pp=oct(a,b2,c,dd,.05);const col=cl[i%4];extrude(Pp,z,9,mix(col,.1),col,mixC(col,'#000000',.25));neonEdges(Pp,z+6,nc[i%4],.75)};
    const lo=[[.14,.14,.5,.46],[.52,.14,.86,.46],[.14,.54,.5,.86],[.52,.54,.86,.86]];
    lo.forEach((u,i)=>box(x0+u[0],y0+u[1],x0+u[2],y0+u[3],2,i));
    const up=[[.16,.16,.5,.46],[.52,.16,.84,.46],[.16,.54,.5,.84],[.52,.54,.84,.84]];
    for(let i=0;i<Math.min(L-1,4);i++){const u=up[i];box(x0+u[0],y0+u[1],x0+u[2],y0+u[3],11,i+1)}
    for(let i=0;i<Math.min(Math.max(L-5,0),3);i++){const u=up[i];box(x0+u[0]+.02,y0+u[1]+.02,x0+u[2]-.02,y0+u[3]-.02,20,i+2)}
    break}
  case'turret':{
    patio(x0+.06,y0+.06,x1-.06,y1-.06);const base=ngon(cx,cy,.37,8,Math.PI/8);extrude(base,1.6,5,GR1,GR2,GR3);neonEdges(base,5,NEONC,.9);
    if(L>=4){const rb=P(cx-.24,cy-.24,6),rt=[rb[0],rb[1]-14];line(rb,rt,'#d6dcdf',1.2);app.ctx.save();app.ctx.translate(rt[0],rt[1]);app.ctx.scale(Math.cos(t*2+b.id),1);app.ctx.fillStyle='#eef1f2';app.ctx.beginPath();app.ctx.ellipse(0,0,4.5,2.6,0,0,TAU);app.ctx.fill();app.ctx.restore()}
    cyl(cx,cy,.24,6,6,'#eef1f2','#cfd8dc');neonArc(cx,cy,.242,9,NEONC,.7);
    const[tx,ty]=P(cx,cy,15);const ca=Math.cos(b.ang),sa=Math.sin(b.ang);
    const ex=(ca-sa)*HW*.6,ey=(ca+sa)*HH*.6;const nx=-ey,ny=ex,nl=Math.hypot(nx,ny)||1;
    app.ctx.lineCap='round';const tips=[];
    for(const o of(L>=6?[-3.4,-1.2,1.2,3.4]:[-2,2])){const ox=nx/nl*o,oy=ny/nl*o;line([tx+ox,ty+oy],[tx+ex+ox,ty+ey+oy],'#3b3f48',2.8+Math.min(L,5)*.3);line([tx+ox,ty+oy-.7],[tx+ex*.92+ox,ty+ey*.92+oy-.7],'#8a919c',.8);tips.push([tx+ex+ox,ty+ey+oy])}
    app.ctx.lineCap='butt';
    app.ctx.save();app.ctx.globalCompositeOperation='lighter';for(const p of tips){const g=app.ctx.createRadialGradient(p[0],p[1],0,p[0],p[1],4);g.addColorStop(0,'rgba(255,240,210,.95)');g.addColorStop(1,'rgba(255,214,150,0)');app.ctx.fillStyle=g;app.ctx.fillRect(p[0]-4,p[1]-4,8,8)}app.ctx.restore();
    app.ctx.fillStyle=lg([tx-8,ty-6],[tx+8,ty+4],[[0,'#ffffff'],[1,'#a3adb2']]);app.ctx.beginPath();app.ctx.ellipse(tx,ty,8.5,5.4,0,0,TAU);app.ctx.fill();app.ctx.strokeStyle=OUT;app.ctx.stroke();
    app.ctx.fillStyle='#3a2e26';app.ctx.beginPath();app.ctx.ellipse(tx+1.5,ty-.5,3.6,2.2,0,0,TAU);app.ctx.fill();
    app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.fillStyle='rgba(255,60,70,.95)';app.ctx.beginPath();app.ctx.ellipse(tx+1.5,ty-.5,2,1.2,0,0,TAU);app.ctx.fill();app.ctx.restore();
    break}
  case'lab':{
    pad(x0+.05,y0+.05,x1-.05,y1-.05);
    const zr=14,acc=PURPN;
    // particle accelerator ring: back half first
    const ringR=.45,[rcx,rcy]=P(cx,cy,5),rrx=ringR*HW*1.414,rry=ringR*HH*1.414;
    const ringArc=(a0,a1)=>{app.ctx.lineCap='round';app.ctx.strokeStyle='#d6d1c9';app.ctx.lineWidth=4.6;app.ctx.beginPath();app.ctx.ellipse(rcx,rcy,rrx,rry,0,a0,a1);app.ctx.stroke();
      app.ctx.strokeStyle='#dfe4e7';app.ctx.lineWidth=1;app.ctx.beginPath();app.ctx.ellipse(rcx,rcy-1.6,rrx,rry,0,a0,a1);app.ctx.stroke();app.ctx.lineCap='butt';
      let prev=null;for(let i=0;i<=10;i++){const a=a0+(a1-a0)*i/10,p=[rcx+Math.cos(a)*rrx,rcy+Math.sin(a)*rry];if(prev)neon(prev,p,acc,.9);prev=p}
      app.ctx.save();app.ctx.globalCompositeOperation='lighter';for(let k=0;k<3;k++){let a=((t*(app.S&&app.S.rs&&!app.thumbMode?5.5:2.2)+k*TAU/3)%TAU);if(a<a0)a+=TAU;if(a>a1)continue;const p=[rcx+Math.cos(a)*rrx,rcy+Math.sin(a)*rry];
        const g=app.ctx.createRadialGradient(p[0],p[1],0,p[0],p[1],5);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.4,'rgba(255,220,170,.8)');g.addColorStop(1,'rgba(255,205,140,0)');app.ctx.fillStyle=g;app.ctx.fillRect(p[0]-5,p[1]-5,10,10)}app.ctx.restore()};
    if(L>=2)ringArc(Math.PI,TAU);
    // main laboratory
    const M=oct(x0+.16,y0+.16,x1-.16,y1-.16,.15);
    extrude(M,2,zr-2,W1,W2,W3);glassBand(M,4.5,zr-4,b.id,.1);
    for(const f of faces(M))if(f.f<.6){const p=P(f.a[0]+(f.b[0]-f.a[0])*.5,f.a[1]+(f.b[1]-f.a[1])*.5,4.5),q=P(f.a[0]+(f.b[0]-f.a[0])*.5,f.a[1]+(f.b[1]-f.a[1])*.5,zr-4);app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.globalAlpha=.25;line(p,q,'#ffe2b0',4);app.ctx.restore()}
    const M2=oct(x0+.14,y0+.14,x1-.14,y1-.14,.15);extrude(M2,zr,1.6,GR2,GR1,GR3,{noEdge:true});neonEdges(M2,zr+.8,acc,1);
    // observatory with an opening slit and a telescope that tracks the sky
    const ox=x0+.4,oy=y0+.4;cyl(ox,oy,.2,zr+1.6,6,'#e6ebea','#c9d0d4');
    {const[dx,dy]=P(ox,oy,zr+7.6);const rx=.2*HW*1.414,hz=rx*.85;const sa=-.75+Math.sin(t*.22+b.id)*.35;
      app.ctx.beginPath();app.ctx.ellipse(dx,dy,rx,hz,0,Math.PI,0);app.ctx.ellipse(dx,dy,rx,.2*HH*1.414,0,0,Math.PI);app.ctx.closePath();
      const g=app.ctx.createRadialGradient(dx-rx*.35,dy-hz*.6,1,dx,dy-hz*.2,rx*1.1);g.addColorStop(0,'#ffffff');g.addColorStop(.5,'#d9dfe2');g.addColorStop(1,'#8f9aa0');app.ctx.fillStyle=g;app.ctx.fill();app.ctx.strokeStyle=OUT;app.ctx.lineWidth=.8;app.ctx.stroke();
      app.ctx.save();app.ctx.translate(dx,dy);app.ctx.rotate(sa);app.ctx.fillStyle='#3a2e26';app.ctx.beginPath();app.ctx.moveTo(-2.6,-hz+1);app.ctx.lineTo(2.6,-hz+1);app.ctx.lineTo(2.2,0);app.ctx.lineTo(-2.2,0);app.ctx.closePath();app.ctx.fill();
      const tl=8+Math.min(L,6)*1.4;app.ctx.lineCap='round';app.ctx.strokeStyle='#eef2f3';app.ctx.lineWidth=3.4;app.ctx.beginPath();app.ctx.moveTo(0,-hz*.4);app.ctx.lineTo(0,-hz*.4-tl);app.ctx.stroke();
      app.ctx.strokeStyle='#2b333d';app.ctx.lineWidth=3.6;app.ctx.beginPath();app.ctx.moveTo(0,-hz*.4-tl);app.ctx.lineTo(0,-hz*.4-tl-1.5);app.ctx.stroke();app.ctx.lineCap='butt';
      app.ctx.fillStyle='#ffcf8a';app.ctx.beginPath();app.ctx.arc(0,-hz*.4-tl-1.2,1.1,0,TAU);app.ctx.fill();app.ctx.restore()}
    // dish on the right corner
    if(L>=2){const ab=P(x1-.27,y0+.3,zr+1.6),at=[ab[0],ab[1]-12];line(ab,at,'#d6dcdf',1.3);
      app.ctx.save();app.ctx.translate(at[0],at[1]+3);app.ctx.rotate(.7+.25*Math.sin(t*.3+b.id));app.ctx.fillStyle=lg([-6,0],[6,0],[[0,'#ffffff'],[1,'#a9b4b8']]);app.ctx.beginPath();app.ctx.ellipse(0,0,6.5,3.2,0,0,TAU);app.ctx.fill();app.ctx.strokeStyle=OUT;app.ctx.stroke();app.ctx.restore()}
    // specimen tanks with glowing fluid
    if(L>=4){for(const[i,[tx,ty]]of[[.3,.7],[.42,.82]].entries()){const X=x0+tx,Y=y0+ty;const[sx,sy]=P(X,Y,zr+1.6);const rx=.06*HW*1.414,ry=rx*.5,h=9;
      app.ctx.fillStyle=i?'rgba(125,255,168,.6)':'rgba(190,140,255,.65)';app.ctx.fillRect(sx-rx,sy-h*.75,rx*2,h*.75);app.ctx.beginPath();app.ctx.ellipse(sx,sy,rx,ry,0,0,Math.PI);app.ctx.fill();
      app.ctx.strokeStyle='rgba(235,245,250,.8)';app.ctx.lineWidth=.8;app.ctx.beginPath();app.ctx.moveTo(sx-rx,sy);app.ctx.lineTo(sx-rx,sy-h);app.ctx.moveTo(sx+rx,sy);app.ctx.lineTo(sx+rx,sy-h);app.ctx.stroke();
      app.ctx.beginPath();app.ctx.ellipse(sx,sy-h,rx,ry,0,0,TAU);app.ctx.fillStyle='#d6dcdf';app.ctx.fill();
      const bp=(t*.8+i*.5)%1;app.ctx.fillStyle='rgba(255,255,255,.7)';app.ctx.beginPath();app.ctx.arc(sx+Math.sin(bp*9)*1.2,sy-1-bp*h*.7,.8,0,TAU);app.ctx.fill()}}
    if(L>=5){const W=oct(x0+.58,y0+.5,x0+.84,y0+.76,.06);extrude(W,zr+1.6,8,W1,W2,W3);glassBand(W,zr+3,zr+8,b.id+2,.1);neonEdges(W,zr+9.6,acc,.8)}
    if(L>=2)ringArc(0,Math.PI);
    // hologram: an atom spinning over the roof
    if(L>=3){const[hx,hy]=P(x1-.26,y1-.44,zr+(L>=5?30:22));const s=L>=6?1.3:1;app.ctx.save();app.ctx.globalCompositeOperation='lighter';
      const g=app.ctx.createRadialGradient(hx,hy,0,hx,hy,5*s);g.addColorStop(0,'rgba(255,255,255,.95)');g.addColorStop(.4,'rgba(255,220,170,.8)');g.addColorStop(1,'rgba(255,205,140,0)');app.ctx.fillStyle=g;app.ctx.fillRect(hx-6*s,hy-6*s,12*s,12*s);
      const orbs=L>=6?4:3;for(let i=0;i<orbs;i++){const rot=i*Math.PI/orbs+t*.3;app.ctx.strokeStyle='rgba(255,226,180,.6)';app.ctx.lineWidth=.9;app.ctx.beginPath();app.ctx.ellipse(hx,hy,11*s,4*s,rot,0,TAU);app.ctx.stroke();
        const ea=t*(2.2+i*.4)+i*2;const ex=Math.cos(ea)*11*s,ey=Math.sin(ea)*4*s;app.ctx.fillStyle='#ffffff';app.ctx.beginPath();app.ctx.arc(hx+ex*Math.cos(rot)-ey*Math.sin(rot),hy+ex*Math.sin(rot)+ey*Math.cos(rot),1.3,0,TAU);app.ctx.fill()}
      const[bx2,by2]=P(x1-.26,y1-.44,zr+1.6);app.ctx.fillStyle='rgba(255,205,140,.18)';app.ctx.beginPath();app.ctx.moveTo(bx2-3,by2);app.ctx.lineTo(hx-10*s,hy+3);app.ctx.lineTo(hx+10*s,hy+3);app.ctx.lineTo(bx2+3,by2);app.ctx.closePath();app.ctx.fill();
      app.ctx.restore();app.ctx.fillStyle='#3a4552';app.ctx.beginPath();app.ctx.ellipse(bx2,by2,4,2,0,0,TAU);app.ctx.fill()}
    break}
  case'missile':{
    pad(x0+.06,y0+.06,x1-.06,y1-.06);
    prism(x0+.14,y0+.14,x1-.14,y1-.14,2,5,'#b7b0a6','#9c958b','#857f76');
    neon(P(x0+.14,y1-.14,6),P(x1-.14,y1-.14,6),AMBER,.8);neon(P(x1-.14,y1-.14,6),P(x1-.14,y0+.14,6),AMBER,.8);
    cyl(cx,cy,.26,7,5,'#eef1f2','#cfd8dc');
    const[tx,ty]=P(cx,cy,15);const ca=Math.cos(b.ang),sa=Math.sin(b.ang);
    let ex=(ca-sa)*HW,ey=(ca+sa)*HH;const l=Math.hypot(ex,ey)||1;ex/=l;ey/=l;const nx=-ey,ny=ex;
    const len=9,wd=6+(L>=5?2:0),ht=8;
    const bk=[tx-ex*len,ty-ey*len+2],fr=[tx+ex*len,ty+ey*len-5];
    const q=(p,o,h)=>[p[0]+nx*o,p[1]+ny*o-h];
    poly([q(bk,wd,0),q(fr,wd,0),q(fr,wd,ht),q(bk,wd,ht)],'#e3e7e9');
    poly([q(bk,-wd,0),q(fr,-wd,0),q(fr,-wd,ht),q(bk,-wd,ht)],'#c9d0d4');
    poly([q(bk,wd,ht),q(fr,wd,ht),q(fr,-wd,ht),q(bk,-wd,ht)],lg(q(bk,0,ht),q(fr,0,ht),[[0,'#f4f6f7'],[1,'#ffffff']]));
    const front=ey>-.2;const e=front?fr:bk;
    poly([q(e,wd,0),q(e,-wd,0),q(e,-wd,ht),q(e,wd,ht)],front?'#5a4a3e':'#d5dbde');
    if(front){const loaded=b.cd<DEF.missile.gun.cd*.55||!app.S.raidOn;const cols=L>=5?3:2;
      for(let i=0;i<cols;i++)for(let j=0;j<2;j++){const o=(i-(cols-1)/2)*(wd*2/cols),hh=ht*(.3+.42*j);const p=q(e,o,hh);
        app.ctx.fillStyle='#14171a';app.ctx.beginPath();app.ctx.arc(p[0],p[1],1.9,0,TAU);app.ctx.fill();if(loaded){app.ctx.fillStyle='#e0414c';app.ctx.beginPath();app.ctx.arc(p[0],p[1],1.2,0,TAU);app.ctx.fill()}}}
    if(L>=3){const rb=P(x1-.24,y0+.24,7),rt=[rb[0],rb[1]-14];line(rb,rt,'#6d777d',1.2);app.ctx.save();app.ctx.translate(rt[0],rt[1]);app.ctx.rotate(t*2);app.ctx.fillStyle='#d6dcde';app.ctx.fillRect(-5,-1,10,2);app.ctx.restore()}
    break}
  case'bank':{
    // white vault: a round door on the left wall, a gold ticker on the right, gold neon around the roof. At night the ticker races and the roof beacon sweeps.
    pad(x0+.05,y0+.05,x1-.05,y1-.05);
    const a0=x0+.14,b0=y0+.14,a1=x1-.14,b1=y1-.14,z=2,H=26+Math.min(L,6)*3,GOLD='#ffc94a',busy=!app.thumbMode&&dayInfo().dark>.5;
    prism(a0,b0,a1,b1,z,H,W1,W2,W3);
    {const[dx,dy]=P((a0+a1)/2,b1,z+11);app.ctx.fillStyle=lg([dx-9,dy-9],[dx+9,dy+9],[[0,'#f4dc8c'],[.5,'#b98f35'],[1,'#7a5a1c']]);app.ctx.beginPath();app.ctx.ellipse(dx,dy,9.5,9,0,0,TAU);app.ctx.fill();app.ctx.strokeStyle='#4a3610';app.ctx.lineWidth=1;app.ctx.stroke();
      app.ctx.fillStyle='#5a4416';app.ctx.beginPath();app.ctx.ellipse(dx,dy,5.4,5,0,0,TAU);app.ctx.fill();
      const w=busy?t*2.4:t*.3;app.ctx.strokeStyle='#f6e6a8';app.ctx.lineWidth=1.4;for(let i=0;i<3;i++){const a=w+i*TAU/3;app.ctx.beginPath();app.ctx.moveTo(dx,dy);app.ctx.lineTo(dx+Math.cos(a)*6.5,dy+Math.sin(a)*6.2);app.ctx.stroke()}
      if(app.MASK){app.ctx.save();app.ctx.globalCompositeOperation='source-atop';app.EMIT++;app.ctx.fillStyle='#ffcd96';app.ctx.beginPath();app.ctx.ellipse(dx,dy,5.4,5,0,0,TAU);app.ctx.fill();app.EMIT--;app.ctx.restore()}}
    {const zt=z+H-6,zb=zt-8,q=[P(a1,b0+.04,zt),P(a1,b1-.04,zt),P(a1,b1-.04,zb),P(a1,b0+.04,zb)];
      poly(q,'#14100a',false);if(!app.thumbMode)litQ(q);
      app.ctx.save();poly(q,null,false);app.ctx.clip();const n=14,sp=busy?.9:.25;
      for(let i=0;i<n;i++){const u=((i/n+t*sp)%1),v=b0+.04+u*(b1-b0-.08),hh=2+((i*37+b.id*7)%5);const[sx,sy]=P(a1,v,zb+1);app.ctx.fillStyle=i%4===0?'#ff6a5a':GOLD;app.ctx.globalAlpha=.95;app.ctx.fillRect(sx-.8,sy-hh,1.7,hh)}
      app.ctx.globalAlpha=1;app.ctx.restore()}
    neonEdges([[a0,b0],[a1,b0],[a1,b1],[a0,b1]],z+H,GOLD,1);
    {const[rx,ry]=P((a0+a1)/2,(b0+b1)/2,z+H);app.ctx.lineCap='round';line([rx,ry],[rx,ry-10],'#b98f35',1.6);app.ctx.lineCap='butt';
      app.ctx.fillStyle=GOLD;app.ctx.beginPath();app.ctx.arc(rx,ry-12,3.2,0,TAU);app.ctx.fill();app.ctx.strokeStyle='#7a5a1c';app.ctx.lineWidth=.7;app.ctx.stroke();
      if(busy&&!app.MASK){const a=t*2.2;app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.fillStyle='rgba(255,201,74,.3)';app.ctx.beginPath();app.ctx.moveTo(rx,ry-12);app.ctx.lineTo(rx+Math.cos(a-.25)*34,ry-12+Math.sin(a-.25)*14);app.ctx.lineTo(rx+Math.cos(a+.25)*34,ry-12+Math.sin(a+.25)*14);app.ctx.fill();app.ctx.restore()}}
    break}
  case'reactor':{
    pad(x0+.04,y0+.04,x1-.04,y1-.04);
    const tower=(tx,ty,r,h)=>{const[x,y]=P(tx,ty,2);const rx=r*HW*1.414,ry=r*HH*1.414;
      app.ctx.beginPath();app.ctx.moveTo(x-rx,y);app.ctx.quadraticCurveTo(x-rx*.5,y-h*.62,x-rx*.74,y-h);app.ctx.lineTo(x+rx*.74,y-h);app.ctx.quadraticCurveTo(x+rx*.5,y-h*.62,x+rx,y);app.ctx.ellipse(x,y,rx,ry,0,0,Math.PI);app.ctx.closePath();
      app.ctx.fillStyle=lg([x-rx,0],[x+rx,0],[[0,'#d7dee2'],[.3,'#ffffff'],[.55,'#eaeff2'],[1,'#aeb9c0']]);app.ctx.fill();if(app.TEX&&app.NOISE){app.ctx.fillStyle=app.NOISE;app.ctx.fill()}app.ctx.strokeStyle=OUT;app.ctx.lineWidth=.8;app.ctx.stroke();
      app.ctx.strokeStyle='rgba(79,195,247,.85)';app.ctx.lineWidth=2;app.ctx.beginPath();app.ctx.ellipse(x,y-h*.2,rx*.86,ry*.86,0,0,Math.PI);app.ctx.stroke();
      app.ctx.beginPath();app.ctx.ellipse(x,y-h,rx*.74,ry*.74,0,0,TAU);app.ctx.fillStyle='#2f3e48';app.ctx.fill();app.ctx.strokeStyle='#e4eaee';app.ctx.lineWidth=1.2;app.ctx.stroke();
      for(let i=0;i<5;i++){const ph=(t*.22+i/5+tx*.37)%1;const px=x+Math.sin(ph*4+i)*6+ph*16,py=y-h-ph*60,pr=rx*.5+ph*rx*1.1;
        app.ctx.fillStyle=`rgba(248,246,242,${.5*(1-ph)})`;app.ctx.beginPath();app.ctx.arc(px,py,pr,0,TAU);app.ctx.fill()}};
    const th=40+Math.min(L,6)*3;
    tower(x0+.5,y0+.5,.36,th);
    if(L>=3)tower(x1-.5,y0+.45,.3,th-8);
    prism(x0+.12,y1-.5,x0+.62,y1-.12,2,12,W1,W2,W3);winL(x0+.18,x0+.56,y1-.12,5,10,true);
    prism(x0+.1,y1-.52,x0+.64,y1-.1,14,1.6,GR2,GR1,GR3,{noEdge:true});neon(P(x0+.1,y1-.1,15),P(x0+.64,y1-.1,15),BLUEN,.9);neon(P(x0+.64,y1-.1,15),P(x0+.64,y1-.52,15),BLUEN,.9);
    const kx=x1-.62,ky=y1-.62;
    cyl(kx,ky,.46,2,20,'#eef1f2','#d6dde0');ring(kx,ky,.46,8,'rgba(90,105,115,.5)');ring(kx,ky,.465,14,TEAL);
    dome(kx,ky,.46,22,'rgba(238,242,244,1)',0);
    {const[x,y]=P(kx,ky,4);const pu=.6+.4*Math.sin(t*3);app.ctx.save();app.ctx.shadowColor='#5cc8ff';app.ctx.shadowBlur=10*pu;app.ctx.strokeStyle=`rgba(110,210,255,${.6+.4*pu})`;app.ctx.lineWidth=2;
      app.ctx.beginPath();app.ctx.ellipse(x,y,.48*HW*1.414,.48*HH*1.414,0,0,Math.PI);app.ctx.stroke();app.ctx.restore()}
    {const[x,y]=P(kx,ky,22);app.ctx.fillStyle='#d9454f';app.ctx.beginPath();app.ctx.arc(x,y-.46*HW*1.2,2,0,TAU);app.ctx.fill()}
    const pa=P(x0+.62,y1-.3,8),pb=P(kx-.3,ky,8);app.ctx.lineCap='round';line(pa,pb,'#7f8a90',3.5);line([pa[0],pa[1]-1],[pb[0],pb[1]-1],'#c7d0d4',1.2);app.ctx.lineCap='butt';
    break}
  case'railgun':{
    pad(x0+.06,y0+.06,x1-.06,y1-.06);
    prism(x0+.16,y0+.16,x1-.16,y1-.16,2,6,'#c9c3ba','#a49d93','#8a847b');
    neon(P(x0+.16,y1-.16,8),P(x1-.16,y1-.16,8),AMBER,.8);neon(P(x1-.16,y1-.16,8),P(x1-.16,y0+.16,8),AMBER,.8);
    cyl(cx,cy,.22,8,6,'#eef1f2','#cfd8dc');
    const[tx,ty]=P(cx,cy,18);const ca=Math.cos(b.ang),sa=Math.sin(b.ang);
    const ex=(ca-sa)*HW*(.9+Math.min(L,10)*.04),ey=(ca+sa)*HH*(.9+Math.min(L,10)*.04);
    app.ctx.lineCap='round';line([tx-ex*.3,ty-ey*.3],[tx+ex,ty+ey],'#2e333b',5);line([tx-ex*.3,ty-ey*.3-1.2],[tx+ex,ty+ey-1.2],'#9aa2ad',1.2);app.ctx.lineCap='butt';
    {const ch=(.5+.5*Math.sin(t*4+b.id));app.ctx.save();app.ctx.globalCompositeOperation='lighter';
      for(let i=1;i<=3;i++){const p=[tx+ex*i/4,ty+ey*i/4];app.ctx.fillStyle=`rgba(255,200,120,${.35+.5*ch})`;app.ctx.beginPath();app.ctx.arc(p[0],p[1]-1,1.6,0,TAU);app.ctx.fill()}app.ctx.restore()}
    app.ctx.fillStyle=lg([tx-8,ty-6],[tx+8,ty+4],[[0,'#ffffff'],[1,'#a3adb2']]);app.ctx.beginPath();app.ctx.ellipse(tx,ty,7.5,4.6,0,0,TAU);app.ctx.fill();app.ctx.strokeStyle=OUT;app.ctx.stroke();
    break}
  case'elevator':{
    pad(x0+.04,y0+.04,x1-.04,y1-.04);
    prism(x0+.2,y0+.2,x1-.2,y1-.2,2,10,W1,W2,W3);winL(x0+.26,x1-.26,y1-.2,4,9,true);
    cyl(cx,cy,.42,12,8,'#eef1f2','#d6dde0');ring(cx,cy,.43,16,TEAL);
    const base=P(cx,cy,20),top=[base[0],base[1]-180];
    app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.strokeStyle='rgba(120,220,255,.28)';app.ctx.lineWidth=5;app.ctx.beginPath();app.ctx.moveTo(base[0],base[1]);app.ctx.lineTo(top[0],top[1]);app.ctx.stroke();app.ctx.restore();
    line(base,top,'#e8eef0',1.6);
    for(let i=0;i<2;i++){const f=(t*.08+i*.5+b.id*.1)%1,y=base[1]-f*175;app.ctx.fillStyle='#ffffff';app.ctx.fillRect(base[0]-3,y-4,6,5);app.ctx.fillStyle='#5cc8ff';app.ctx.fillRect(base[0]-2,y-3,4,1.2)}
    {const pu=.6+.4*Math.sin(t*2.5);app.ctx.fillStyle=`rgba(255,77,90,${pu})`;app.ctx.beginPath();app.ctx.arc(top[0],top[1],2.2,0,TAU);app.ctx.fill()}
    break}
  case'shieldgen':{
    pad(x0+.06,y0+.06,x1-.06,y1-.06);
    prism(x0+.14,y0+.14,x1-.14,y1-.14,2,7,W1,W2,W3);neon(P(x0+.14,y1-.14,9),P(x1-.14,y1-.14,9),TEAL,.9);neon(P(x1-.14,y1-.14,9),P(x1-.14,y0+.14,9),TEAL,.9);
    cyl(cx,cy,.2,9,12,'#eef1f2','#cfd8dc');ring(cx,cy,.21,16,TEAL);dome(cx,cy,.17,21,'rgba(120,235,255,.9)',4);
    {const[px,py]=P(cx,cy,23),pu=.45+.3*Math.sin(t*3+b.id);app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.strokeStyle=`rgba(120,235,255,${pu})`;app.ctx.lineWidth=1.4;app.ctx.beginPath();app.ctx.ellipse(px,py,16,9,0,0,TAU);app.ctx.stroke();app.ctx.restore()}
    break}
  case'terraform':{
    pad(x0+.04,y0+.04,x1-.04,y1-.04);
    poly([P(x0+.12,y0+.12),P(x1-.12,y0+.12),P(x1-.12,y1-.12),P(x0+.12,y1-.12)],'#4f8a4a',false);
    for(const[u,v]of[[.3,1.6],[.55,1.75],[1.7,.4],[1.55,.25],[.25,1.3]])potPlant(x0+u,y0+v,0,.9);
    cyl(x0+.55,y0+.55,.3,2,30,'#eef1f2','#cfd8dc');ring(x0+.55,y0+.55,.31,24,TEAL);
    prism(x1-.85,y0+.2,x1-.2,y0+.8,2,12,W1,W2,W3);winL(x1-.8,x1-.25,y0+.8,4,10,true);
    dome(x0+1.22,y0+1.22,.56,2,'rgba(150,240,175,.85)',8);
    for(let i=0;i<3;i++){const ph=(t*.25+i/3+b.id*.1)%1,[sx,sy]=P(x0+.55,y0+.55,32+ph*38);app.ctx.fillStyle=`rgba(220,255,225,${.5*(1-ph)})`;app.ctx.beginPath();app.ctx.arc(sx+Math.sin(ph*4)*3,sy,3+ph*7,0,TAU);app.ctx.fill()}
    break}
  case'drill':{
    pad(x0+.05,y0+.05,x1-.05,y1-.05);
    prism(x0+.12,y0+.12,x0+.48,y0+.48,2,10,W1,W2,W3);winL(x0+.18,x0+.42,y0+.48,4,9,true);neon(P(x0+.12,y0+.48,10),P(x0+.48,y0+.48,10),PINKN,.8);neon(P(x0+.48,y0+.48,10),P(x0+.48,y0+.12,10),PINKN,.8);
    const db=P(cx+.08,cy+.08,2),dt=[db[0],db[1]-44-Math.min(L,6)*4];lattice(db,dt,11,7,'#c9d0d4');for(const f of[.3,.62]){const y=db[1]+(dt[1]-db[1])*f,w=11-(11-3.3)*f;neon([db[0]-w,y],[db[0]+w,y],PINKN,.8)}
    line(db,dt,'#3e464c',2.5);
    prism(cx-.08,cy-.08+.08,cx+.24,cy+.24,2,6,'#7d868c','#646d73','#545c61');
    // glowing crystal core at the top
    const g=.55+.45*Math.sin(t*3+b.id);app.ctx.save();app.ctx.shadowColor='#ff6ad5';app.ctx.shadowBlur=14*g;
    app.ctx.fillStyle=lg([dt[0],dt[1]-10],[dt[0],dt[1]+6],[[0,'#ffd1f1'],[.5,'#ff6ad5'],[1,'#a3277f']]);
    app.ctx.beginPath();app.ctx.moveTo(dt[0],dt[1]-11);app.ctx.lineTo(dt[0]+5,dt[1]-2);app.ctx.lineTo(dt[0],dt[1]+6);app.ctx.lineTo(dt[0]-5,dt[1]-2);app.ctx.closePath();app.ctx.fill();app.ctx.restore();
    // feed pipe
    const pa=P(cx+.08,cy+.08,6),pb=P(x0+.48,y0+.3,6);app.ctx.lineCap='round';line(pa,pb,'#8a5c84',3);app.ctx.lineCap='butt';
    break}
  case'mine':{
    pad(x0+.05,y0+.05,x1-.05,y1-.05);
    const a0=x0+.12,b0=y0+.12,a1=x0+.62,b1=y1-.12;
    const shd=oct(a0,b0,a1,b1,.07);extrude(shd,2,13,GR1,W2,W3);glassBand(shd,8,11.5,b.id,.12);
    const q=[P(a0+.14,b1,8),P(a0+.36,b1,8),P(a0+.36,b1,2),P(a0+.14,b1,2)];poly(q,lg(q[0],q[3],[[0,'#7a6a5c'],[1,'#3a2e26']]),false);
    for(let i=1;i<4;i++){const z=2+i*1.5;line(P(a0+.15,b1,z),P(a0+.35,b1,z),'rgba(255,255,255,.12)',.6)}
    neonEdges(shd,3,AMBER,.8);neon(q[0],q[1],AMBER,.8);
    // headframe with spinning wheel
    const hb=P(x1-.28,y0+.3,2),ht=[hb[0],hb[1]-38-Math.min(L,6)*3];lattice(hb,ht,8,6,'#c9d0d4');neon([hb[0]-6,hb[1]-14],[hb[0]+6,hb[1]-14],AMBER,.7);
    app.ctx.save();app.ctx.translate(ht[0],ht[1]);app.ctx.rotate(t*2);app.ctx.strokeStyle='#d99a2b';app.ctx.lineWidth=1.6;app.ctx.beginPath();app.ctx.arc(0,0,6,0,TAU);for(let i=0;i<6;i++){const a=i*Math.PI/3;app.ctx.moveTo(0,0);app.ctx.lineTo(Math.cos(a)*6,Math.sin(a)*6)}app.ctx.stroke();app.ctx.restore();
    line(ht,P(a1,y0+.4,14),'#3d3a36',.8);
    // conveyor + ore pile
    const c0=P(a1,y1-.3,10),c1=P(x1-.16,y1-.16,4);line(c0,c1,'#4e4944',3);line([c0[0],c0[1]-1.5],[c1[0],c1[1]-1.5],'#7a736c',1);
    const[ox,oy]=P(x1-.2,y1-.2,2);app.ctx.fillStyle=lg([ox,oy-12],[ox,oy],[[0,'#8a7a6c'],[1,'#4e4239']]);app.ctx.beginPath();app.ctx.moveTo(ox-12,oy);app.ctx.quadraticCurveTo(ox-2,oy-14-Math.min(L,6)*2,ox+8,oy);app.ctx.closePath();app.ctx.fill();
    break}
  case'hangar':{
    pad(x0+.04,y0+.04,x1-.04,y1-.04);
    const a0=x0+.08,a1=x1-.42,b0=y0+.12,b1=y1-.4,ym=(b0+b1)/2,hy=(b1-b0)/2,zb=8,R=20+Math.min(L,6)*2.5,n=18;
    const away=!!app.mission&&!app.thumbMode;
    // office base with a warm window ribbon
    const Bs=rrect(a0,b0,a1,b1,.06,2);extrude(Bs,1.6,zb-1.6,W1,W2,W3,{smooth:true});
    warmFaces(rrect(a0+.01,b0+.01,a1-.01,b1-.01,.05,2),3,zb-1.5,.16,b.id);
    // vaulted white shell with a skylight along the ridge
    const arc=(a,k)=>[ym-Math.cos(a)*hy*(k||1),zb+Math.sin(a)*R*(k||1)];
    for(let i=0;i<n;i++){const t0=Math.PI*i/n,t1=Math.PI*(i+1)/n;const[yA,zA]=arc(t0),[yB,zB]=arc(t1);
      const q=[P(a0,yA,zA),P(a1,yA,zA),P(a1,yB,zB),P(a0,yB,zB)];
      const sky=i>=7&&i<=10;
      if(sky){poly(q,lg(q[0],q[2],[[0,'#eef9ff'],[1,'#7fc8ec']]),false);if(!app.thumbMode)litQ(q);
        for(let k=1;k<6;k++){const u=a0+(a1-a0)*k/6;line(P(u,yA,zA),P(u,yB,zB),'rgba(255,255,255,.85)',.7)}}
      else{const lum=.3+.7*Math.max(0,Math.cos((t0+t1)/2-1.15));const v=Math.round(206+49*lum);poly(q,`rgb(${v},${Math.min(255,v+3)},${Math.min(255,v+5)})`,false);app.ctx.strokeStyle=`rgb(${v},${v},${v})`;app.ctx.lineWidth=.6;app.ctx.stroke()}}
    {const[y7,z7]=arc(Math.PI*7/n),[y11,z11]=arc(Math.PI*11/n);line(P(a0,y7,z7),P(a1,y7,z7),'#ffffff',1.2);line(P(a0,y11,z11),P(a1,y11,z11),'#ffffff',1.2)}
    for(let k=1;k<5;k++){const u=a0+(a1-a0)*k/5;app.ctx.strokeStyle='rgba(150,158,162,.28)';app.ctx.lineWidth=.8;app.ctx.beginPath();for(let i=0;i<=n;i++){const[y,z]=arc(Math.PI*i/n);const p=P(u,y,z);i?app.ctx.lineTo(p[0],p[1]):app.ctx.moveTo(p[0],p[1])}app.ctx.stroke()}
    // thick rounded portal frame, deep reveal, glowing bay with the fleet ship inside
    const arcPoly=(k,x,zb2)=>{const o=[];for(let i=0;i<=n;i++){const a=Math.PI*i/n;o.push(P(x,ym-Math.cos(a)*hy*k,zb2+Math.sin(a)*(zb+R-zb2)*k))}o.push(P(x,ym+hy*k,1.6),P(x,ym-hy*k,1.6));return o};
    const outer=[];for(let i=0;i<=n;i++){const[y,z]=arc(Math.PI*i/n);outer.push(P(a1+.03,y,z))}outer.push(P(a1+.03,b1,1.6),P(a1+.03,b0,1.6));
    poly(outer,lg(P(a1,ym,zb+R),P(a1,ym,1.6),[[0,'#ffffff'],[1,'#e3e8ea']]),'rgba(160,170,175,.5)');
    const rv=arcPoly(.86,a1+.03,1.6);poly(rv,lg(P(a1,ym,zb+R),P(a1,ym,1.6),[[0,'#a9b3b8'],[.4,'#cfd6d9'],[1,'#e6eaec']]),false);
    const inn=arcPoly(.78,a1+.03,1.6);
    app.ctx.save();app.EMIT++;poly(inn,lg(P(a1,ym,(zb+R)*.8),P(a1,ym,1.6),[[0,'#f2fbff'],[.55,'#a6def7'],[1,'#4fa8d8']]),false);app.EMIT--;app.ctx.clip();
    for(const k of[.62,.48]){app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.globalAlpha=.6;const r2=arcPoly(k,a1+.03,1.6);app.ctx.strokeStyle='#c8f0ff';app.ctx.lineWidth=1.2;app.ctx.beginPath();for(let i=0;i<=n;i++){const p=r2[i];i?app.ctx.lineTo(p[0],p[1]):app.ctx.moveTo(p[0],p[1])}app.ctx.stroke();app.ctx.restore()}
    {const f0=P(a1+.03,ym-hy*.78,3.4),f1=P(a1+.03,ym+hy*.78,3.4);line(f0,f1,'rgba(70,120,150,.5)',1)}
    if(!away)shuttle(P(a1-.16,ym,5.2),.46,.82,false);
    for(let k=1;k<6;k++){const y=ym-hy*.78+hy*1.56*k/6;line(P(a1+.03,y,1.6),P(a1+.03,y,zb+R*.8),'rgba(255,255,255,.22)',.6)}
    app.ctx.restore();
    {let prev=null;for(let i=0;i<=n;i++){const p=inn[i];if(prev)neon(prev,p,NEONC,.7);prev=p}}
    // apron: centre line, chevrons, landing ring, edge lights
    {const c0=P(a1+.08,ym,1.7),c1=P(x1-.06,ym,1.7);app.ctx.setLineDash([3,3]);line(c0,c1,'#f2c14e',1.2);app.ctx.setLineDash([]);
      for(let k=0;k<2;k++){const u=a1+.12+k*.1;line(P(u,ym-.07,1.7),P(u+.05,ym,1.7),'#f2c14e',1);line(P(u+.05,ym,1.7),P(u,ym+.07,1.7),'#f2c14e',1)}
      if(L>=3){const[px,py]=P(x1-.2,ym,1.7);app.ctx.strokeStyle='#f2c14e';app.ctx.lineWidth=1.2;app.ctx.beginPath();app.ctx.ellipse(px,py,.15*HW*1.414,.15*HH*1.414,0,0,TAU);app.ctx.stroke()}
      for(let k=0;k<6;k++){const v=b0+(b1-b0)*k/5;const p=P(x1-.06,v,1.8);const on=(Math.floor(t*6)%6)===k;app.ctx.fillStyle=on?'#fff2c8':'#c9a253';app.ctx.beginPath();app.ctx.arc(p[0],p[1],on?1.6:1,0,TAU);app.ctx.fill()}}
    // fuel tanks along the front
    if(L>=3)for(const u of[.72,.96]){cyl(x0+u,y1-.2,.08,1.6,11,'#ffffff','#e6eaec');ring(x0+u,y1-.2,.082,6,TEAL)}
    // control tower with a wraparound window
    if(L>=2){const tx=x0+.27,ty=y1-.2,th=24+Math.min(L,6)*2;cyl(tx,ty,.065,1.6,th,'#ffffff','#e6eaec');
      const Hd=rrect(tx-.15,ty-.15,tx+.15,ty+.15,.07,3);extrude(Hd,th,9,'#ffffff','#f4f6f7','#cbd3d7',{smooth:true});
      opening('L',ty+.15,tx-.08,tx+.08,th+1.6,th+7.4,b.id+3,{noRail:true});opening('R',tx+.15,ty-.08,ty+.08,th+1.6,th+7.4,b.id+5,{noRail:true});
      const rt=P(tx,ty,th+9);if(L>=4){line(rt,[rt[0],rt[1]-8],'#d6dcdf',1.1);app.ctx.save();app.ctx.translate(rt[0],rt[1]-8);app.ctx.scale(Math.cos(t*1.6+b.id),1);app.ctx.fillStyle='#ffffff';app.ctx.beginPath();app.ctx.ellipse(0,0,5,2.8,0,0,TAU);app.ctx.fill();app.ctx.strokeStyle=OUT;app.ctx.stroke();app.ctx.restore()}
      else{app.ctx.fillStyle=(Math.floor(t*2)%2)?'#ff4d5a':'#5a1a20';app.ctx.beginPath();app.ctx.arc(rt[0],rt[1]-2,1.6,0,TAU);app.ctx.fill()}}
    break}
  case'hacker':{
    // dark glass tower: green code rain on the left screen wall, a magenta terminal on the right, dish and mast on the roof
    pad(x0+.05,y0+.05,x1-.05,y1-.05);
    const a0=x0+.16,b0=y0+.16,a1=x1-.16,b1=y1-.16,z=2,H=24+Math.min(L,6)*3,GRN='#5dffb0',MAG='#ff4fd8';
    const racing=!app.thumbMode&&!!app.contest,gold=!app.thumbMode&&app.S.contests.hacked; // the screens run hot during a contest; gold while a win's Hacked effect is armed
    prism(a0,b0,a1,b1,z,H,'#2a3142','#283044','#1a2030');
    {const q=[P(a0+.03,b1,z+H-3),P(a1-.03,b1,z+H-3),P(a1-.03,b1,z+3),P(a0+.03,b1,z+3)];
      poly(q,'#06140e',false);if(!app.thumbMode)litQ(q);
      app.ctx.save();poly(q,null,false);app.ctx.clip();
      for(let i=0;i<7;i++){const u=a0+.06+(i+.5)/7*(a1-a0-.12),sp=(9+(i*5)%7)*(racing?3:1);
        for(let k=0;k<9;k++){const zz=z+3+(((k*4.2-t*sp-i*13)%(H-6))+(H-6))%(H-6);const[sx,sy]=P(u,b1,zz);
          app.ctx.fillStyle=k===0?'#e6fff3':GRN;app.ctx.globalAlpha=k===0?1:.85-k*.08;app.ctx.fillRect(sx-.9,sy-1.3,1.8,2.2)}}
      app.ctx.globalAlpha=1;app.ctx.restore()}
    {const m=z+H*.55,w=racing?5:Math.min(5,1+Math.floor(L/2));
      for(let r=0;r<w;r++){const zz=m+6-r*3,len=racing?.1+.3*Math.abs(Math.sin(t*9+r*2)):.18+((r*37+b.id*11)%10)/30;line(P(a1,b0+.1,zz),P(a1,b0+.1+len,zz),MAG,1.1)}
      if(Math.floor(t*2)%2)line(P(a1,b0+.1,m+6-w*3),P(a1,b0+.16,m+6-w*3),'#ffffff',1.2)}
    neonEdges([[a0,b0],[a1,b0],[a1,b1],[a0,b1]],z+H,GRN,.8);
    {const[rx,ry]=P(a0+.2,b0+.2,z+H);app.ctx.lineCap='round';line([rx,ry],[rx,ry-16],'#9aa3ad',1.4);app.ctx.lineCap='butt';
      app.ctx.fillStyle=gold?'#ffd34a':(Math.floor(t*1.6+b.id)%2)?'#ff4d5a':'#5a1a20';app.ctx.beginPath();app.ctx.arc(rx,ry-17,1.8,0,TAU);app.ctx.fill()}
    {const[dx,dy]=P(a1-.24,b1-.24,z+H);const ang=-.6+Math.sin(t*.4+b.id)*.35;
      line([dx,dy],[dx,dy-6],'#7f8a90',1.6);
      app.ctx.save();app.ctx.translate(dx,dy-8);app.ctx.rotate(ang);app.ctx.fillStyle=lg([-7,0],[7,0],[[0,'#c9cfd5'],[.5,'#f4f6f8'],[1,'#a9b1b9']]);
      app.ctx.beginPath();app.ctx.ellipse(0,0,7,3.6,0,0,TAU);app.ctx.fill();app.ctx.strokeStyle='#6f7880';app.ctx.lineWidth=.6;app.ctx.stroke();
      line([0,0],[0,-5],'#6f7880',.8);app.ctx.fillStyle=GRN;app.ctx.beginPath();app.ctx.arc(0,-5.4,1.1,0,TAU);app.ctx.fill();app.ctx.restore()}
    if(L>=3){const[gx,gy]=P(a0+.08,b1-.1,2);app.ctx.fillStyle='#1d2330';app.ctx.fillRect(gx-4,gy-9,8,9);for(let i=0;i<3;i++){app.ctx.fillStyle=(Math.floor(t*6+i*2+b.id)%3)?GRN:'#0d3a26';app.ctx.fillRect(gx-2.6+i*2,gy-7,1.2,1.2)}}
    if(L>=5){const cz=z+H+22,[hx,hy]=P((a0+a1)/2,(b0+b1)/2,cz),R=7+Math.min(L-5,3);app.ctx.save();app.ctx.globalCompositeOperation='lighter';
      app.ctx.strokeStyle=gold?'rgba(255,211,74,.85)':'rgba(93,255,176,.75)';app.ctx.lineWidth=.8;app.ctx.beginPath();app.ctx.arc(hx,hy,R,0,TAU);app.ctx.stroke();
      app.ctx.beginPath();app.ctx.ellipse(hx,hy,R,R*.35,0,0,TAU);app.ctx.stroke();app.ctx.beginPath();app.ctx.ellipse(hx,hy,Math.abs(Math.cos(t*1.2))*R,R,0,0,TAU);app.ctx.stroke();
      app.ctx.fillStyle=gold?'rgba(255,211,74,.14)':'rgba(93,255,176,.12)';app.ctx.beginPath();app.ctx.moveTo(hx-R*.6,hy+R);app.ctx.lineTo(hx+R*.6,hy+R);const[px,py]=P((a0+a1)/2,(b0+b1)/2,z+H);app.ctx.lineTo(px+3,py);app.ctx.lineTo(px-3,py);app.ctx.fill();app.ctx.restore()}
    break}
  case'spaceport':{
    pad(x0+.04,y0+.04,x1-.04,y1-.04);
    prism(x0+.12,y0+.12,x0+.7,y0+.8,2,18,W1,W2,W3);winL(x0+.18,x0+.64,y0+.8,6,16,true);neon(P(x0+.12,y0+.8,20),P(x0+.7,y0+.8,20),AMBER,.9);
    cyl(x0+1.2,y0+1.2,.62,2,2.4,'#7d868c','#545c61');ring(x0+1.2,y0+1.2,.5,4.5,AMBER);ring(x0+1.2,y0+1.2,.3,4.5,AMBER);
    // service gantry behind the rocket
    {const g0=P(x0+1.62,y0+.86,4.4),g1=[g0[0],g0[1]-74];lattice(g0,g1,7,8,'#c9d0d4');neon([g1[0]-3,g1[1]],[g1[0]+3,g1[1]],BLUEN,.8)}
    // the rocket: white hull with blue glass panels, like the Moon city pictures
    {const[sx,sy]=P(x0+1.2,y0+1.2,4.4),H=62+Math.min(L,10)*2,w=8;
      app.ctx.fillStyle='rgba(30,40,50,.25)';app.ctx.beginPath();app.ctx.ellipse(sx,sy+1,w+4,4,0,0,TAU);app.ctx.fill();
      const fin=d=>{app.ctx.fillStyle=lg([sx+d*w,sy-26],[sx+d*(w+9),sy],[[0,'#ffffff'],[1,'#b7c2c8']]);app.ctx.beginPath();app.ctx.moveTo(sx+d*w*.8,sy-26);app.ctx.quadraticCurveTo(sx+d*(w+9),sy-12,sx+d*(w+8),sy+2);app.ctx.lineTo(sx+d*w*.8,sy-3);app.ctx.closePath();app.ctx.fill();app.ctx.strokeStyle='#5fd0ff';app.ctx.lineWidth=1;app.ctx.beginPath();app.ctx.moveTo(sx+d*(w+8.6),sy-8);app.ctx.lineTo(sx+d*(w+8),sy+2);app.ctx.stroke()};
      fin(-1);fin(1);
      const body=()=>{app.ctx.beginPath();app.ctx.moveTo(sx-w,sy-2);app.ctx.lineTo(sx-w,sy-H*.62);app.ctx.bezierCurveTo(sx-w,sy-H*.86,sx-3,sy-H*.97,sx,sy-H);app.ctx.bezierCurveTo(sx+3,sy-H*.97,sx+w,sy-H*.86,sx+w,sy-H*.62);app.ctx.lineTo(sx+w,sy-2);app.ctx.closePath()};
      body();app.ctx.fillStyle=lg([sx-w,0],[sx+w,0],[[0,'#c9d2d7'],[.35,'#ffffff'],[.7,'#eef2f4'],[1,'#a9b5bc']]);app.ctx.fill();app.ctx.strokeStyle='rgba(90,105,115,.5)';app.ctx.lineWidth=.7;app.ctx.stroke();
      app.ctx.save();body();app.ctx.clip();
      app.EMIT++;app.ctx.fillStyle=lg([0,sy-H*.6],[0,sy-6],[[0,'#bff0ff'],[.5,'#4fc3f7'],[1,'#1f7fb8']]);
      for(const[u0,u1]of[[-.75,-.35],[.15,.55]]){app.ctx.beginPath();app.ctx.moveTo(sx+w*u0,sy-8);app.ctx.lineTo(sx+w*u0,sy-H*.5);app.ctx.quadraticCurveTo(sx+w*(u0+u1)/2,sy-H*.6,sx+w*u1,sy-H*.5);app.ctx.lineTo(sx+w*u1,sy-8);app.ctx.closePath();app.ctx.fill()}
      app.ctx.fillStyle='#7fdcff';app.ctx.fillRect(sx-w,sy-H*.7,w*2,1.6);app.EMIT--;
      app.ctx.restore();
      line([sx-w*.2,sy-H*.95],[sx-w*.2,sy-H*.66],'rgba(255,255,255,.9)',1);
      // umbilical arm to the gantry
      {const g=P(x0+1.62,y0+.86,4.4);line([g[0],g[1]-H*.55],[sx+w,sy-H*.55],'#c9d0d4',1.4)}
      // engine glow and venting steam
      app.EMIT++;app.ctx.fillStyle=`rgba(120,220,255,${.5+.3*Math.sin(t*6)})`;app.ctx.beginPath();app.ctx.ellipse(sx,sy,w*.7,2.2,0,0,TAU);app.ctx.fill();app.EMIT--;
      for(let i=0;i<3;i++){const ph=(t*.3+i/3+b.id*.1)%1;app.ctx.fillStyle=`rgba(245,248,250,${.35*(1-ph)})`;app.ctx.beginPath();app.ctx.arc(sx+(i-1)*10*ph-6+i*6,sy-2-ph*10,3+ph*7,0,TAU);app.ctx.fill()}}
    break}
  case'ring':{
    pad(x0+.04,y0+.04,x1-.04,y1-.04);
    for(const[u,v]of[[.4,.4],[1.6,.4],[.4,1.6],[1.6,1.6]])cyl(x0+u,y0+v,.09,2,60,'#eef1f2','#b7c0c5');
    cyl(cx,cy,.42,2,10,'#eef1f2','#cfd8dc');ring(cx,cy,.43,12,TEAL);
    {const[px,py]=P(cx,cy,64),rx=60,ry=30;app.ctx.strokeStyle='#8fa3ae';app.ctx.lineWidth=8;app.ctx.beginPath();app.ctx.ellipse(px,py,rx,ry,0,0,TAU);app.ctx.stroke();app.ctx.strokeStyle='#ffffff';app.ctx.lineWidth=4;app.ctx.beginPath();app.ctx.ellipse(px,py-1.5,rx,ry,0,0,TAU);app.ctx.stroke();app.ctx.setLineDash([3,4]);app.ctx.strokeStyle='#4fc3f7';app.ctx.lineWidth=1.6;app.ctx.beginPath();app.ctx.ellipse(px,py+1,rx,ry,0,0,Math.PI);app.ctx.stroke();app.ctx.setLineDash([]);
      for(let i=0;i<6;i++){const a=i/6*TAU+t*.3;app.ctx.fillStyle=i%2?'#5ff3ff':'#ffffff';app.ctx.beginPath();app.ctx.arc(px+Math.cos(a)*rx,py-1.5+Math.sin(a)*ry,3,0,TAU);app.ctx.fill()}}
    break}
  case'mirror':{
    pad(x0+.04,y0+.04,x1-.04,y1-.04);
    prism(x0+.3,y0+.3,x1-.3,y1-.3,2,8,W1,W2,W3);neon(P(x0+.3,y1-.3,10),P(x1-.3,y1-.3,10),AMBER,.9);neon(P(x1-.3,y1-.3,10),P(x1-.3,y0+.3,10),AMBER,.9);
    {const bs=P(cx,cy,10),tp=[bs[0],bs[1]-60];lattice(bs,tp,10,6,'#c9d0d4');
      app.ctx.save();app.ctx.globalCompositeOperation='lighter';app.ctx.fillStyle=lg([tp[0],tp[1]-150],tp,[[0,'rgba(255,214,120,0)'],[1,'rgba(255,214,120,.5)']]);app.ctx.beginPath();app.ctx.moveTo(tp[0]-6,tp[1]-150);app.ctx.lineTo(tp[0]+6,tp[1]-150);app.ctx.lineTo(tp[0]+20,tp[1]);app.ctx.lineTo(tp[0]-20,tp[1]);app.ctx.closePath();app.ctx.fill();app.ctx.restore();
      app.ctx.save();app.ctx.translate(tp[0],tp[1]);app.ctx.rotate(-.25);app.ctx.fillStyle=lg([-30,-6],[30,6],[[0,'#fff1b8'],[.5,'#ffc94a'],[1,'#b8862a']]);app.ctx.beginPath();app.ctx.ellipse(0,0,30,12,0,0,TAU);app.ctx.fill();app.ctx.strokeStyle='rgba(90,60,10,.6)';app.ctx.lineWidth=1;app.ctx.stroke();app.ctx.fillStyle='rgba(255,255,255,.6)';app.ctx.beginPath();app.ctx.ellipse(-8,-3,8,2.4,0,0,TAU);app.ctx.fill();app.ctx.restore()}
    break}
  }
  if(joins)corridors(b,true,.3);
  if(b.type==='hq'&&L>=12)hqTier(b,t,cx,cy);
  if(b.state==='damaged'){
    const[x,y]=P(cx,cy,10);app.ctx.fillStyle='rgba(30,12,10,.38)';app.ctx.beginPath();app.ctx.ellipse(x,y,s*30,s*16,0,0,TAU);app.ctx.fill();
    for(let i=0;i<4;i++){const ph=(t*.5+i/4+b.id*.13)%1;app.ctx.fillStyle=`rgba(60,55,55,${.55*(1-ph)})`;app.ctx.beginPath();app.ctx.arc(x+Math.sin(i*2+t)*6+ph*8,y-10-ph*40,5+ph*11,0,TAU);app.ctx.fill()}
    const fl=.6+.4*Math.sin(t*14+b.id);app.ctx.fillStyle=`rgba(255,140,50,${fl})`;app.ctx.beginPath();app.ctx.arc(x-4,y-4,3.5,0,TAU);app.ctx.fill();app.ctx.fillStyle=`rgba(255,220,120,${fl})`;app.ctx.beginPath();app.ctx.arc(x-4,y-5,1.6,0,TAU);app.ctx.fill();
  }
}

function drawScaffold(b){
  const s=DEF[b.type].size,x0=b.gx+.12,y0=b.gy+.12,x1=b.gx+s-.12,y1=b.gy+s-.12,h=14+8*s;
  const hp=h*b.prog;
  poly([P(x0,y0),P(x1,y0),P(x1,y1),P(x0,y1)],'rgba(120,80,60,.35)');
  if(hp>2)prism(x0+.1,y0+.1,x1-.1,y1-.1,0,hp,'#e8e2d8','#cfc6b8','#b9ae9e');
  app.ctx.strokeStyle='#ffb03a';app.ctx.lineWidth=1.4;
  for(const[x,y] of[[x0,y1],[x1,y1],[x1,y0]]){const a=P(x,y,0),c=P(x,y,h);app.ctx.beginPath();app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(c[0],c[1]);app.ctx.stroke()}
  for(const z of[h*.5,h]){app.ctx.beginPath();const a=P(x0,y1,z),c=P(x1,y1,z),e=P(x1,y0,z);app.ctx.moveTo(a[0],a[1]);app.ctx.lineTo(c[0],c[1]);app.ctx.lineTo(e[0],e[1]);app.ctx.stroke()}
}
export const upTime=b=>(DEF[b.type].time*(b.lvl+1)||12*(b.lvl+1))*(tech('nano')?.75:1);
