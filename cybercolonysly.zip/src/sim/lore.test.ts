import { describe, expect, it } from 'vitest';
import { DEF, MAXL, RANKS, REGIONS, SECTORS, SECT_N, STORY, TECH } from './defs';
import { useWorld } from './lore';
import { QUESTS } from './quests';
import { BEATS, CAST } from './story';
import { sector } from './campaign';
import { rng, stats, stormLeft, stormy } from './economy';
import { newGame } from './save';

// its own file: useWorld rewrites the shared tables, and Vitest gives each file fresh modules
describe('each world plays differently', () => {
  it('blows a dust storm over Mars that dims the solar arrays, and none on the Moon', () => {
    const { S } = newGame({}, rng(1));
    S.t = 100; const calm = stats(S).eP;
    S.t = 450; expect(stormy(S)).toBe(true); expect(stormLeft(S)).toBeCloseTo(30);
    expect(calm - stats(S).eP).toBeCloseTo(5 * .6); // the one solar array gives 40% of its 5
    S.tech.panels = 1; expect(calm - stats(S).eP).toBeCloseTo(5 * .3); // self-cleaning panels keep 70%
    expect(TECH.some(T => T.id === 'panels')).toBe(true);
    useWorld('moon'); expect(stormy(S)).toBe(false);
    expect(TECH.some(T => T.id === 'panels')).toBe(false); // no storms, no panel tech
  });
});

describe('the Moon has its own words', () => {
  it('swaps ranks, story, sectors, quests and dialogue, and leaves no Mars behind', () => {
    useWorld('moon');
    expect([RANKS.length, new Set(RANKS).size, SECTORS.length]).toEqual([MAXL, MAXL, SECT_N]);
    expect(sector(0).region).toBe('Shackleton Rim');
    expect(QUESTS.find(q => q.t.includes('sector 8'))!.t).toBe('Defeat Director Kade (sector 8)');
    expect(QUESTS.find(q => q.t === 'Reach colony level 19')!.story).toBe(STORY[19]);
    for (const b of BEATS) for (const [k] of b.lines) expect(CAST[k]).toBeDefined();
    const words = JSON.stringify([RANKS, STORY, REGIONS, SECTORS, BEATS, CAST, QUESTS.map(q => [q.t, q.why, q.story]), Object.values(DEF).map(d => d.desc)]);
    expect(words).not.toMatch(/Mars|Martian|Tharsis|Deimos|Phobos|Kesh/);
  });
});
