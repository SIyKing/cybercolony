import { TECH, TIER } from './defs';
import { canPay, pay, tech } from './economy';
import type { Hooks, State, Tech } from './types';

export const techCount = (S: State) => TECH.filter(T => tech(S, T.id)).length;
export const labB = (S: State) => S.b.find(b => b.type === 'lab');
export function labSpeed(S: State) { const l = labB(S); return l && l.state === 'active' ? 1 + .25 * (l.lvl - 1) : 0; }

export type TechState = 'done' | 'cur' | 'nolab' | 'pre' | 'lvl' | 'ok';
export function techState(S: State, T: Tech): TechState {
  if (tech(S, T.id)) return 'done';
  if (S.rs && S.rs.id === T.id) return 'cur';
  const lab = labB(S); if (!lab) return 'nolab';
  const pre = TECH.find(x => x.br === T.br && x.tier === T.tier - 1); if (pre && !tech(S, pre.id)) return 'pre';
  if (lab.lvl < TIER[T.tier].lab) return 'lvl';
  return 'ok';
}

/** Starts research and pays for it. Returns the tech, 'cost' when it can't be paid, or null when not allowed. */
export function startResearch(S: State, id: string): Tech | 'cost' | null {
  const T = TECH.find(x => x.id === id); if (!T || S.rs || techState(S, T) !== 'ok') return null;
  const tr = TIER[T.tier];
  if (!canPay(S, tr.cost)) return 'cost';
  pay(S, tr.cost); S.rs = { id, left: tr.time, total: tr.time };
  return T;
}

export function tickResearch(S: State, dt: number, h: Hooks) {
  if (!S.rs) return; const sp = labSpeed(S); if (sp <= 0) return; S.rs.left -= dt * sp;
  if (S.rs.left <= 0) {
    const T = TECH.find(x => x.id === S.rs!.id)!; S.tech[T.id] = 1; S.rs = null;
    h.toast('Research complete: ' + T.name + '. ' + T.fx);
    const l = labB(S); if (l) { h.sparkle(l); h.floater(l, 'Researched!', 2); }
    h.save();
  }
}
