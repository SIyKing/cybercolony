import { LORE, REGIONS, RIV1, RIV2, RNAME, SECTORS, SECT_N } from './defs';
import { caps, fleetPower, hackM, has, keys, lootM, tech } from './economy';
import type { Mission, Rand, Rival, Sector, State } from './types';

export function sector(i: number): Sector {
  const boss = (i + 1) % 8 === 0; const p = Math.round(9 * Math.pow(1.19, i) * (boss ? 1.35 : 1));
  const lk = Math.pow(1.17, i) * (boss ? 2 : 1);
  return { i, name: SECTORS[i], region: REGIONS[Math.floor(i / 8)], boss, power: p, loot: { metal: Math.round(150 * lk), crystal: Math.round(15 * lk) } };
}

export function makeRival(S: State, i: number, rand: Rand = Math.random): Rival {
  const base = 9 * Math.pow(1.19, Math.min(S.stage || 0, SECT_N - 1)) * (.55 + .2 * i);
  const p = Math.max(5, Math.round(base * (.85 + rand() * .3)));
  return {
    name: RIV1[Math.floor(rand() * RIV1.length)] + ' ' + RIV2[Math.floor(rand() * RIV2.length)], power: p,
    loot: { metal: Math.round(80 + p * 5), crystal: Math.round(8 + p * .8) },
  };
}
export function makeRivals(S: State, rand: Rand = Math.random) { S.rivals = [0, 1, 2].map(i => makeRival(S, i, rand)); }

/** a target's power after the Hacker Center's attack and a contest win's Hacked effect */
export const enemyPower = (S: State, power: number) => Math.round(power * hackM(S) * (S.contests.hacked ? .9 : 1));
/** chance that the fleet beats a target */
export const winChance = (S: State, power: number) => { const p = fleetPower(S); return p / (p + enemyPower(S, power)); };

/** Sends the fleet. Returns the new mission, or null when the fleet can't fly. */
export function launch(S: State, current: Mission | null, kind: Mission['kind'], i: number): Mission | null {
  if (current || S.cool > 0 || !has(S, 'hangar')) return null;
  const tgt = kind === 'camp' ? sector(S.stage) : S.rivals[i]; if (!tgt) return null;
  const h = S.b.find(b => b.type === 'hangar')!;
  S.cool = (kind === 'camp' ? 60 : 45) * (tech(S, 'ion') ? .6 : 1);
  return { kind, i, t: 6, x: h.gx + 1.62, y: h.gy + .87, name: tgt.name };
}

/** Settles a finished mission and returns the message to show. */
export function resolveMission(S: State, m: Mission, rand: Rand = Math.random): string {
  const camp = m.kind === 'camp'; const r = camp ? sector(S.stage) : S.rivals[m.i];
  let msg: string;
  if (rand() < winChance(S, r.power)) {
    const c = caps(S); const got: string[] = [];
    for (const k of keys(r.loot)) {
      const before = S.res[k]; S.res[k] = Math.min(c[k], S.res[k] + Math.round(r.loot[k]! * lootM(S)));
      got.push('+' + Math.floor(S.res[k] - before) + ' ' + RNAME[k]);
    }
    S.wins++;
    if (camp) { S.stage++; msg = (S.stage >= SECT_N ? 'The sky above ' + LORE.name + ' is yours! ' : S.stage === 24 ? LORE.home[0].toUpperCase() + LORE.home.slice(1) + ' is free! ' : 'Sector ' + S.stage + ' conquered: ') + r.name + '. ' + got.join(', '); }
    else msg = 'Victory over ' + r.name + '! ' + got.join(', ');
  } else msg = 'Defeat at ' + r.name + '. The fleet limped home.';
  if (!camp) S.rivals[m.i] = makeRival(S, m.i, rand);
  S.contests.hacked = false;
  return msg;
}
