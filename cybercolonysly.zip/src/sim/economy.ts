import { DEF, MAXL, RULES, TAU, N } from './defs';
import type { Building, BuildingType, Cost, Goods, Rand, Resources, State, Tiles } from './types';

export const clamp = (v: number, a: number, b: number) => v < a ? a : v > b ? b : v;

/** mulberry32: small seeded PRNG, used for terrain */
export function rng(seed: number): Rand {
  return function () {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

export const tech = (S: State | undefined, id: string) => !!(S && S.tech && S.tech[id]);
export const hq = (S: State) => S.b.find(b => b.type === 'hq');
export const has = (S: State, t: BuildingType) => S.b.some(b => b.type === t && b.state === 'active');
export const occAt = (S: State, x: number, y: number) =>
  S.b.find(b => { const s = DEF[b.type].size; return x >= b.gx && x < b.gx + s && y >= b.gy && y < b.gy + s; });

export const maxHp = (S: State, b: Building) => Math.round(DEF[b.type].hp * (1 + .5 * (b.lvl - 1)) * (tech(S, 'alloy') ? 1.4 : 1) * (tech(S, 'shield') ? 1.3 : 1));

/** buildable land grows with the colony level: 8x8 at level 1, 16x16 from level 5, then a strip along two edges per level from 11, up to the full map at 20 */
export function area(S: State) {
  const L = hq(S)?.lvl ?? 1, r = Math.min(8, 3 + L), x = Math.max(0, L - 10);
  return { a: N / 2 - r - Math.floor(x / 2), b: N / 2 + r + Math.ceil(x / 2) };
}
export const inArea = (S: State, x: number, y: number) => { const A = area(S); return x >= A.a && y >= A.a && x < A.b && y < A.b; };

export function caps(S: State): Resources {
  let extra = 0;
  for (const b of S.b) if (b.state === 'active') extra += (DEF[b.type].store || 0) * b.lvl;
  const h = hq(S); const hb = (h ? h.lvl - 1 : 0) * 400;
  const q = tech(S, 'quantum') ? 1.5 : 1;
  const base = Math.round((600 + extra + hb) * q);
  return { metal: base, water: base, food: base, crystal: Math.round((250 + Math.floor(extra / 2) + hb / 2) * q) };
}

export const maxLvl = (S: State, b: Building) => b.type === 'hq' ? MAXL : Math.min(DEF[b.type].maxL || MAXL, hq(S)!.lvl + 1);
export const grow = (L: number) => 1.5 * Math.pow(L, 1.5);

const buildM = (S: State) => (tech(S, 'nano') ? .85 : 1) * (tech(S, 'forge') ? .85 : 1) * RULES.build;
/** a dust storm blows for the last minute of every 8 minutes, on worlds that have them */
export const stormy = (S: State) => RULES.storms && S.t % 480 > 420;
/** seconds of dust storm left, 0 when calm */
export const stormLeft = (S: State) => stormy(S) ? 480 - S.t % 480 : 0;
/** the share of solar power left in a storm: self-cleaning panels keep more */
export const stormSun = (S: State) => tech(S, 'panels') ? .7 : .4;
/** how much power a plant gives: sunlight for solar arrays and mirrors, fuel for the rest */
const sunM = (S: State, type: BuildingType) => type === 'solar' || type === 'mirror' ? RULES.solar * (stormy(S) ? stormSun(S) : 1) : RULES.fuel;

export function upCost(S: State, b: Building): Cost {
  const d = DEF[b.type], L = b.lvl;
  let c: Cost;
  if (b.type === 'hq') c = { metal: Math.round(250 * grow(L) / 1.5), crystal: Math.round(25 * grow(L) / 1.5) };
  else {
    c = {};
    for (const k of keys(d.cost)) c[k] = Math.ceil(d.cost[k]! * grow(L));
    c.crystal = (c.crystal || 0) + Math.ceil(6 * grow(L) / 1.5);
  }
  for (const k of keys(c)) c[k] = Math.ceil(c[k]! * buildM(S));
  return c;
}

export function repCost(S: State, b: Building): Cost {
  const d = DEF[b.type];
  if (b.type === 'hq') return { metal: 80 * b.lvl };
  const c: Cost = {};
  for (const k of keys(d.cost)) if (k !== 'credit') c[k] = Math.ceil(d.cost[k]! * .4 * b.lvl * (tech(S, 'alloy') ? .5 : 1));
  return c;
}

/** cost to place a new building */
export function bCost(S: State, k: BuildingType): Cost {
  const c: Cost = {}, d = DEF[k].cost;
  for (const r of keys(d)) c[r] = Math.ceil(d[r]! * buildM(S));
  return c;
}

export const canPay = (S: State, c: Cost) => keys(c).every(k => S.res[k] >= c[k]!);
export const pay = (S: State, c: Cost) => { for (const k of keys(c)) S.res[k] -= c[k]!; };

const activeLvl = (S: State, t: BuildingType) => S.b.find(b => b.type === t && b.state === 'active')?.lvl ?? 0;

export const techMul = (S: State, type: BuildingType) =>
  type === 'mine' && tech(S, 'drills') ? 1.25 : type === 'drill' && tech(S, 'reson') ? 1.3
    : type === 'greenhouse' ? (tech(S, 'hydro') ? 1.3 : 1) * (tech(S, 'gene') ? 1.5 : 1) * (1 + .1 * activeLvl(S, 'terraform'))
      : type === 'extractor' && tech(S, 'ice') ? 1.3 : (type === 'elevator' || type === 'spaceport') && tech(S, 'belt') ? 1.5 : 1;
export const lootM = (S: State) => tech(S, 'salvage') ? 1.4 : 1;
export const lootOf = (S: State, l: Goods): Goods => { const o: Goods = {}; for (const k of keys(l)) o[k] = Math.round(l[k]! * lootM(S)); return o; };

/** enemy power multiplier from an active Hacker Center: -5% per level, at most -40% */
export function hackM(S: State) {
  const b = S.b.find(b => b.type === 'hacker' && b.state === 'active');
  return b ? 1 - .05 * Math.min(b.lvl, 8) : 1;
}

/** drone damage multiplier from a Shield Generator (-5% per level, at most -50%) and Aegis Lattice */
export const shieldM = (S: State) => (1 - .05 * Math.min(activeLvl(S, 'shieldgen'), 10)) * (tech(S, 'aegis') ? .85 : 1);

export function fleetPower(S: State) {
  let p = Math.floor(S.pop / 3);
  for (const b of S.b) {
    if (b.state !== 'active') continue; const L = b.lvl;
    if (b.type === 'hangar') p += 12 * L; if (b.type === 'turret') p += 4 * L; if (b.type === 'missile') p += 6 * L; if (b.type === 'hq') p += 3 * L; if (b.type === 'railgun') p += 10 * L; if (b.type === 'ring') p += 25 * L;
  }
  return Math.round(p * (tech(S, 'tact') ? 1.2 : 1) * (tech(S, 'warp') ? 1.25 : 1) * (tech(S, 'carrier') ? 1.3 : 1) * (tech(S, 'sing') ? 1.4 : 1));
}

export function addB(S: State, tiles: Tiles, type: BuildingType, gx: number, gy: number, lvl?: number, instant?: boolean, rand: Rand = Math.random): Building {
  const d = DEF[type];
  const b: Building = { id: S.nid++, type, gx, gy, lvl: lvl || 1, state: instant ? 'active' : 'building', prog: instant ? 1 : 0, hp: 0, upg: 0, cd: 0, ang: rand() * TAU };
  b.hp = maxHp(S, b); S.b.push(b);
  for (let x = gx; x < gx + d.size; x++) for (let y = gy; y < gy + d.size; y++) { tiles[x][y].plant = 0; S.cleared.push(x * N + y); }
  return b;
}

export interface Stats { eP: number; eU: number; work: number; cap: number; fe: number; fw: number; boost: number; fz: number }

/** power, workers, housing and output boost from the active buildings */
export function stats(S: State): Stats {
  let eP = 0, eU = 0, work = 0, cap = 0, boost = 1, fz = 0;
  for (const b of S.b) {
    if (b.state !== 'active') continue;
    const d = DEF[b.type], L = b.lvl;
    if (d.energy > 0) eP += d.energy * L * (tech(S, 'fusion') ? 1.25 : 1) * sunM(S, b.type); else if (d.energy < 0) eU += -d.energy * L * RULES.power;
    work += d.workers || 0;
    cap += Math.round((d.popCap || 0) * L * (b.type === 'habitat' ? (tech(S, 'cryo') ? 1.5 : 1) * (tech(S, 'bio') ? 1.3 : 1) : 1));
    if (d.boost) boost += d.boost * L;
    if (b.type === 'fashion') fz += L;
  }
  const fe = eU > 0 ? Math.min(1, eP / eU) : 1, fw = work > 0 ? Math.min(1, S.pop / work) : 1;
  return { eP, eU, work, cap, fe, fw, boost, fz };
}

/** resources per second, before clamping to storage */
export function rates(S: State, tiles: Tiles, st: Stats): Resources {
  const rate: Resources = { metal: 0, water: 0, food: 0, crystal: 0 };
  for (const b of S.b) {
    if (b.state !== 'active') continue;
    const d = DEF[b.type];
    if (d.use && !d.prod) { for (const r of keys(d.use)) rate[r] -= d.use[r]! * b.lvl; continue; }
    if (!d.prod) continue;
    let k = b.lvl * (b.type === 'hq' ? 1 : st.fe * st.fw * st.boost);
    if (d.rock && tiles[b.gx][b.gy].t === 'rock') k *= 2;
    k *= techMul(S, b.type) * (b.type !== 'hq' && tech(S, 'auto') ? 1.2 : 1);
    if (d.use) { if (S.res.water < 1) k = 0; for (const r of keys(d.use)) rate[r] -= d.use[r]! * k / st.boost; }
    for (const r of keys(d.prod)) rate[r] += d.prod[r]! * k * (RULES.prod[r] ?? 1);
  }
  const u = (tech(S, 'recycle') ? .03 : .05) * (tech(S, 'terra') ? .75 : 1);
  rate.food -= S.pop * u; rate.water -= S.pop * u;
  return rate;
}

export const keys = <T extends object>(o: T) => Object.keys(o) as (keyof T & string)[];
