import { LORE, SECTORS, SECT_N, STORY } from './defs';
import { has, hq } from './economy';
import { techCount } from './research';
import type { Goods, State } from './types';

/** why: the reason shown before the goal is done; story: the line shown once it is */
export interface Quest { t: string; ok: (S: State) => boolean; r: Goods; story?: string; why?: string }

const lvl = (S: State) => hq(S)!.lvl;
const reach = (L: number, r: Goods): Quest => ({ t: 'Reach colony level ' + L, ok: S => lvl(S) >= L, r, get story() { return STORY[L]; } });

/** append only: saves store the index */
export const QUESTS: Quest[] = [
  { t: 'Build an Ice Extractor', ok: S => has(S, 'extractor'), r: { metal: 60 }, why: 'The tanks hold a few days of water. There is ice under the dust: dig it out so the crew can drink.' },
  { t: 'Build a Greenhouse', ok: S => has(S, 'greenhouse'), r: { metal: 70 }, why: 'The greenhouse dome cracked on the way down: build a Greenhouse so the crew can eat.' },
  { t: 'Build an Ore Mine', ok: S => has(S, 'mine'), r: { metal: 80 }, why: 'The hull of the ship will only give so much scrap. A mine gives Ines the metal to keep building.' },
  { t: 'Grow to 10 colonists', ok: S => S.pop >= 10, r: { crystal: 15 }, why: 'The rest of the crew are still in the cold bunks on the ship. Wake them up: they need food, water and homes.' },
  { t: 'Build a Defense Turret', ok: S => has(S, 'turret'), r: { metal: 80 }, why: 'Something on the scope is heading straight for the colony. Get a gun up before it lands.' },
  { t: 'Put a Crystal Drill on a pink deposit', ok: S => has(S, 'drill'), r: { metal: 120 }, why: 'Tavi needs crystals for the scopes and the guns. The pink deposits are full of them.' },
  { t: 'Survive a drone raid', ok: S => S.raids > 0, r: { crystal: 30 }, why: 'The drones are coming. Keep the turrets powered and hold on.' },
  { t: 'Reach colony level 2', ok: S => lvl(S) >= 2, r: { metal: 200 }, why: 'Unmarked drones mean someone knows you are here. A stronger Command Center lets the colony grow to meet them.' },
  { t: 'Build a Hangar', ok: S => has(S, 'hangar'), r: { crystal: 30 }, why: 'Turrets only shoot back. A Hangar gives you ships to go and look for whoever sent the drones.' },
  { t: 'Win a battle', ok: S => S.wins > 0, r: { crystal: 50 }, why: 'Rival camps sit between you and the signal the drones follow. Show them this colony can hit back.' },
  { t: 'Grow to 30 colonists', ok: S => S.pop >= 30, r: { crystal: 60 }, why: 'Word is out that there is water here. Make room for the people who come looking for it.' },
  { t: 'Reach colony level 3', ok: S => lvl(S) >= 3, r: { metal: 400, crystal: 80 }, why: 'Ines says level 3 opens up a real lab. Tavi wants one to crack the drone wrecks.' },
  { t: 'Build a Research Lab', ok: S => has(S, 'lab'), r: { crystal: 40, metal: 150 } },
  { t: 'Conquer 3 campaign sectors', ok: S => (S.stage || 0) >= 3, r: { metal: 500 } },
  { t: 'Build a Missile Battery', ok: S => has(S, 'missile'), r: { crystal: 60 } },
  { t: 'Reach colony level 4', ok: S => lvl(S) >= 4, r: { metal: 600, crystal: 60 } },
  { t: 'Build a Fusion Reactor', ok: S => has(S, 'reactor'), r: { metal: 800 } },
  { t: 'Grow to 50 colonists', ok: S => S.pop >= 50, r: { crystal: 80 } },
  { get t() { return 'Defeat ' + SECTORS[7] + ' (sector 8)'; }, ok: S => (S.stage || 0) >= 8, r: { metal: 1000, crystal: 120 } },
  { t: 'Upgrade any building to level 5', ok: S => S.b.some(b => b.lvl >= 5), r: { crystal: 100 } },
  { t: 'Beat 10 drone raids', ok: S => S.raids >= 10, r: { crystal: 120 } },
  { t: 'Reach colony level 6', ok: S => lvl(S) >= 6, r: { metal: 1500, crystal: 150 } },
  { get t() { return 'Defeat ' + SECTORS[15] + ' (sector 16)'; }, ok: S => (S.stage || 0) >= 16, r: { metal: 2000, crystal: 200 } },
  { t: 'Grow to 100 colonists', ok: S => S.pop >= 100, r: { metal: 2000 } },
  { t: 'Reach colony level 8', ok: S => lvl(S) >= 8, r: { crystal: 300 } },
  { get t() { return 'Defeat ' + SECTORS[23] + ' and free ' + LORE.home; }, ok: S => (S.stage || 0) >= 24, r: { metal: 5000, crystal: 500 } },
  { t: 'Research all 16 technologies', ok: S => techCount(S) >= 16, r: { metal: 5000, crystal: 600 } },
  { t: 'Reach colony level 9', ok: S => lvl(S) >= 9, r: { metal: 6000, crystal: 600 } },
  { t: 'Build a Railgun', ok: S => has(S, 'railgun'), r: { crystal: 400 } },
  { t: 'Reach colony level 10', ok: S => lvl(S) >= 10, r: { metal: 8000, crystal: 800 } },
  { t: 'Build a Space Elevator', ok: S => has(S, 'elevator'), r: { crystal: 600 } },
  { t: 'Research all 20 technologies', ok: S => techCount(S) >= 20, r: { metal: 10000, crystal: 1200 } },
  reach(11, { metal: 8000, crystal: 800 }),
  reach(12, { metal: 9000, crystal: 900 }),
  { t: 'Build a Shield Generator', ok: S => has(S, 'shieldgen'), r: { crystal: 800 } },
  reach(13, { metal: 10000, crystal: 1000 }),
  { get t() { return 'Take ' + SECTORS[24] + ' (sector 25)'; }, ok: S => (S.stage || 0) >= 25, r: { metal: 6000, crystal: 800 } },
  reach(14, { metal: 12000, crystal: 1200 }),
  { t: 'Build a Terraforming Plant', ok: S => has(S, 'terraform'), r: { crystal: 1000 } },
  reach(15, { metal: 14000, crystal: 1400 }),
  { t: 'Research all 24 technologies', ok: S => techCount(S) >= 24, r: { metal: 12000, crystal: 1500 } },
  reach(16, { metal: 16000, crystal: 1600 }),
  { t: 'Build a Spaceport', ok: S => has(S, 'spaceport'), r: { crystal: 1200 } },
  reach(17, { metal: 18000, crystal: 1800 }),
  { t: 'Beat 50 drone raids', ok: S => S.raids >= 50, r: { crystal: 1500 } },
  reach(18, { metal: 20000, crystal: 2000 }),
  { t: 'Build an Orbital Ring', ok: S => has(S, 'ring'), r: { crystal: 1500 } },
  reach(19, { metal: 22000, crystal: 2200 }),
  { t: 'Defeat Admiral Vex (sector 32)', ok: S => (S.stage || 0) >= SECT_N, r: { metal: 20000, crystal: 3000 } },
  reach(20, { metal: 25000, crystal: 2500 }),
  { t: 'Build a Solar Mirror', ok: S => has(S, 'mirror'), r: { crystal: 2000 } },
  { t: 'Research all 28 technologies', ok: S => techCount(S) >= 28, r: { metal: 30000, crystal: 4000 } },
];
