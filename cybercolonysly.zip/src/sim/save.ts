import { N, N0, OFF, RES, RNAME } from './defs';
import { addB, caps, clamp, maxHp } from './economy';
import { newBank, tickBank } from './bank';
import { makeRivals } from './campaign';
import { newContests } from './contest';
import { tickResearch } from './research';
import { beatsPassed } from './story';
import { genTerrain } from './terrain';
import type { Hooks, Rand, State, Tiles } from './types';

export const KEY = 'dustfall-colony-v1';
/** offline progress is capped at 4 hours */
export const OFFLINE_MAX = 4 * 3600;

export function newGame(av: unknown, rand: Rand = Math.random): { S: State; tiles: Tiles } {
  const seed = Math.floor(rand() * 1e9);
  const S: State = {
    v: 2, seed, res: { metal: 220, water: 60, food: 60, crystal: 20, credit: 0 }, pop: 4, b: [], nid: 1, quest: 0, beat: 0, wave: 0, raidT: 300, raidOn: false,
    wins: 0, raids: 0, cool: 0, rivals: [], cleared: [], grow: 0, starve: 0, t: 0, stage: 0, tech: {}, rs: null, contests: newContests(), bank: newBank(), av, saved: Date.now(),
    rate: { metal: 0, water: 0, food: 0, crystal: 0 },
  };
  const tiles = genTerrain(seed);
  addB(S, tiles, 'hq', OFF + 7, OFF + 7, 1, true, rand); addB(S, tiles, 'solar', OFF + 9, OFF + 7, 1, true, rand); addB(S, tiles, 'habitat', OFF + 7, OFF + 9, 1, true, rand);
  makeRivals(S, rand);
  return { S, tiles };
}

/** Parses a saved game and fills in fields older saves lack. Returns null for no or unreadable saves. */
export function parseSave(json: string | null, defaultAv: () => unknown): { S: State; tiles: Tiles } | null {
  let d: (Omit<State, 'v'> & { v: number }) | null = null;
  try { d = JSON.parse(json || 'null'); } catch { /* corrupt save: start fresh */ }
  if (!d || (d.v !== 1 && d.v !== 2)) return null;
  // v1 saves are from the 16x16 map, which now sits in the middle of the bigger one
  if (d.v === 1) {
    for (const b of d.b) { b.gx += OFF; b.gy += OFF; }
    d.cleared = d.cleared.map(k => (Math.floor(k / N0) + OFF) * N + k % N0 + OFF);
    d.v = 2;
  }
  const S = d as State;
  if (S.stage == null) S.stage = 0; if (!S.tech) S.tech = {}; if (!S.av) S.av = defaultAv(); if (S.rs === undefined) S.rs = null; if (!S.contests) S.contests = newContests(); if (S.res.credit == null) S.res.credit = 0; if (!S.bank) S.bank = newBank(); if (S.beat == null) S.beat = beatsPassed(S.quest);
  const tiles = genTerrain(S.seed);
  for (const k of S.cleared) { const x = Math.floor(k / N), y = k % N; if (tiles[x] && tiles[x][y]) tiles[x][y].plant = 0; }
  return { S, tiles };
}

/**
 * Catches up on time spent away, using the last known rates: resources (capped by storage), finished
 * construction and upgrades, research, taxes and interest. Returns what was gained, e.g. ['+120 metal'], or null if under 30 s.
 */
export function applyOffline(S: State, seconds: number, h: Hooks): string[] | null {
  const el = Math.min(OFFLINE_MAX, Math.max(0, seconds));
  let got: string[] | null = null;
  if (el > 30) {
    const c = caps(S); got = [];
    for (const k of RES) {
      const before = S.res[k]; S.res[k] = clamp(S.res[k] + (S.rate[k] || 0) * el, 0, c[k]);
      const g = Math.floor(S.res[k] - before); if (g > 0) got.push('+' + fmt(g) + ' ' + RNAME[k]);
    }
    for (const b of S.b) {
      if (b.state === 'building' || b.state === 'repair') { b.state = 'active'; b.prog = 1; b.hp = maxHp(S, b); }
      if (b.upg > 0 && b.upg < el) { b.upg = 0; b.lvl++; b.hp = maxHp(S, b); }
    }
    const wallet = S.res.credit, saved = S.bank.saved; tickBank(S, el);
    const g = Math.floor(S.res.credit - wallet), i = Math.floor(S.bank.saved - saved);
    if (g > 0) got.push('+' + fmt(g) + ' credits'); if (i > 0) got.push('+' + fmt(i) + ' credits interest');
    S.t += Math.min(el, 600); tickResearch(S, el, h); S.contests.cool = Math.max(0, S.contests.cool - el);
  }
  if (S.raidOn) { S.raidOn = false; S.raidT = Math.max(S.raidT, 90); }
  return got;
}

export const fmt = (n: number) => { n = Math.floor(n); return n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 10000 ? (n / 1000).toFixed(1) + 'k' : String(n); };
