import { describe, expect, it } from 'vitest';
import { CARGO_KEY, hold, inFlight, land, send, tripSecs } from './cargo';
import { addB, rng } from './economy';
import { newGame } from './save';
import { saveKey } from './worlds';

describe('cargo (#41)', () => {
  it('flies a load from one colony to another in real time, one trip at a time', () => {
    const store = new Map<string, string>(), get = (k: string) => store.get(k) ?? null, set = (k: string, v: string) => { store.set(k, v); };
    const mars = newGame({}, rng(1)), moon = newGame({}, rng(2));
    expect(send(mars.S, 'mars', 'moon', 'metal', get, set)).toMatch(/Hangar/);
    addB(mars.S, mars.tiles, 'hangar', 4, 4, 2, true);
    expect(hold(mars.S.b)).toBe(400);
    store.set(saveKey('moon'), JSON.stringify(moon.S));
    expect(send(mars.S, 'mars', 'moon', 'metal', get, set)).toMatch(/no Hangar/);
    addB(moon.S, moon.tiles, 'hangar', 4, 4, 1, true); store.set(saveKey('moon'), JSON.stringify(moon.S));
    mars.S.res.metal = 1000;
    expect(send(mars.S, 'mars', 'moon', 'metal', get, set, 0)).toBeNull();
    expect(mars.S.res.metal).toBe(600);
    expect(send(mars.S, 'mars', 'moon', 'water', get, set, 0)).toMatch(/already out/);
    expect(inFlight(get)).toEqual([{ from: 'mars', to: 'moon', res: 'metal', n: 400, at: tripSecs('mars', 'moon') * 1000 }]);
    moon.S.res.metal = 500; // storage holds 600: 100 fits, 300 waits in the hold
    expect(land(moon.S, 'moon', get, set, 1000)).toEqual([]);
    expect(land(moon.S, 'moon', get, set, 1e9)[0].n).toBe(100);
    expect(moon.S.res.metal).toBe(600);
    expect(land(moon.S, 'moon', get, set, 1e9)).toEqual([]);
    moon.S.res.metal = 0;
    expect(land(moon.S, 'moon', get, set, 1e9)[0].n).toBe(300);
    expect(JSON.parse(store.get(CARGO_KEY)!)).toEqual([]);
    expect(tripSecs('moon', 'mars')).toBeLessThan(tripSecs('mars', 'titan'));
  });
});
