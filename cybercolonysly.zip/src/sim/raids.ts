import { stealCredits } from './bank';
import { DEF, N, TAU } from './defs';
import { caps, hq, lootM, shieldM, tech } from './economy';
import type { Drone, DroneKind, Hooks, Live, Rand, State } from './types';

const KINDS: Record<Exclude<DroneKind, 'boss'>, { hp: number; size: number; dmg: number; sp: number; z: number; cr: number }> = {
  scout: { hp: 1, size: 1.35, dmg: 1, sp: 1.3, z: 34, cr: 2 },
  heavy: { hp: 2.6, size: 1.8, dmg: 2, sp: 1, z: 42, cr: 5 },
  lancer: { hp: .7, size: 1.15, dmg: 1.5, sp: 2.4, z: 30, cr: 3 },
  siege: { hp: 5, size: 2.4, dmg: 3, sp: .8, z: 50, cr: 12 },
};

/** spawns the next wave and returns how many drones it has */
export function startRaid(S: State, drones: Drone[], h: Hooks, rand: Rand = Math.random) {
  // colony levels above 10 toughen raids; lancers join from level 13, siege drones from 17
  const L = hq(S)?.lvl ?? 1, over = Math.max(0, L - 10);
  S.raidOn = true; const w = S.wave; const n = Math.min(14 + over, 2 + w); const hpE = (26 + w * 9) * (1 + .25 * over), dmgM = 1 + .1 * over;
  const boss = w >= 4 && (w + 1) % 5 === 0;
  for (let i = 0; i < n; i++) {
    const side = i % 4, u = rand() * N;
    const [x, y] = side === 0 ? [-2, u] : side === 1 ? [u, -2] : side === 2 ? [N + 2, u] : [u, N + 2];
    const heavy = w >= 3 && i % 3 === 2;
    const kind: DroneKind = L >= 17 && i % 5 === 4 ? 'siege' : heavy ? 'heavy' : L >= 13 && i % 3 === 1 ? 'lancer' : 'scout';
    const K = KINDS[kind];
    drones.push({
      x, y, hp: hpE * K.hp, max: hpE * K.hp, kind, size: K.size, dmg: (7 + w * 2) * K.dmg * dmgM, sp: K.sp,
      tgt: null, cd: 1 + rand(), orb: rand() * TAU, life: 80, bob: rand() * TAU, flash: 0,
    });
  }
  if (boss) { const hp = hpE * 12; drones.push({ x: -3, y: N / 2, hp, max: hp, kind: 'boss', size: 3, dmg: (10 + w * 3) * 3 * dmgM, sp: .6, tgt: null, cd: 2, orb: 0, life: 140, bob: 0, flash: 0 }); }
  h.toast(boss ? 'Raid! A drone mothership leads ' + n + ' drones' : 'Raid! ' + n + ' drones incoming');
}

export const droneZ = (d: Pick<Drone, 'kind'>) => d.kind === 'boss' ? 64 : KINDS[d.kind].z;

export function killDrone(S: State, drones: Drone[], d: Drone, h: Hooks) {
  const i = drones.indexOf(d); if (i < 0) return; drones.splice(i, 1);
  const big = d.kind === 'heavy' || d.kind === 'siege';
  h.shake(d.kind === 'boss' ? .6 : big ? .3 : .15);
  h.boom(d.x, d.y, droneZ(d), d.kind === 'boss' ? 2.4 : big ? 1.4 : 1);
  const cr = Math.round((d.kind === 'boss' ? 40 : KINDS[d.kind].cr) * lootM(S));
  S.res.crystal = Math.min(caps(S).crystal, S.res.crystal + cr);
  if (d.kind === 'boss') h.toast('Mothership destroyed! +' + cr + ' crystals');
}

export function updRaid(S: State, live: Live, dt: number, h: Hooks, rand: Rand = Math.random) {
  const { drones, missiles } = live;
  const alive = S.b.filter(b => b.state === 'active' || b.state === 'building');
  for (let i = drones.length - 1; i >= 0; i--) {
    const d = drones[i]; d.life -= dt; d.bob += dt * 4; d.flash = Math.max(0, d.flash - dt * 4);
    if (d.life <= 0) { drones.splice(i, 1); const lost = Math.floor(S.res.metal * .1); S.res.metal -= lost; const cr = stealCredits(S); h.toast('A drone escaped with ' + lost + ' metal' + (cr ? ' and ' + cr + ' credits' : '')); continue; }
    if (!d.tgt || !S.b.includes(d.tgt) || d.tgt.state === 'damaged') {
      const pool = d.kind === 'boss' ? alive.filter(b => b.type === 'hq' || b.type === 'reactor' || b.type === 'hangar' || b.type === 'elevator' || b.type === 'spaceport' || b.type === 'ring' || b.type === 'mirror') : alive;
      const L = pool.length ? pool : alive; d.tgt = L.length ? L[Math.floor(rand() * L.length)] : null;
    }
    if (!d.tgt) { d.x += dt * 2; continue; }
    const s = DEF[d.tgt.type].size, tx = d.tgt.gx + s / 2, ty = d.tgt.gy + s / 2;
    const dx = tx - d.x, dy = ty - d.y, dist = Math.hypot(dx, dy);
    const rr = .8 * d.size * .8 + .3;
    if (dist > .9 + s * .3 + (d.size - 1) * .6) { d.x += dx / dist * d.sp * dt; d.y += dy / dist * d.sp * dt; d.ang = Math.atan2(dy, dx); }
    else {
      d.orb += dt * 1.3 / d.size; d.x += (tx + Math.cos(d.orb) * rr - d.x) * dt * 2; d.y += (ty + Math.sin(d.orb) * rr - d.y) * dt * 2;
      d.cd -= dt;
      if (d.cd <= 0) {
        d.cd = d.kind === 'boss' ? 2 : 1.2; d.tgt.hp -= d.dmg * shieldM(S);
        h.fx({ k: 'beam', x1: d.x, y1: d.y, z1: droneZ(d) - 4, x2: tx + (rand() - .5) * .4, y2: ty + (rand() - .5) * .4, z2: 12, t: .2, c: '#ff4d5a', w: d.kind === 'boss' ? 4 : 2 });
        h.fx({ k: 'hit', x: tx + (rand() - .5) * .4, y: ty + (rand() - .5) * .4, z: 12, t: .25 });
        if (d.tgt.hp <= 0) { d.tgt.hp = 0; d.tgt.state = 'damaged'; d.tgt.upg = 0; h.boom(tx, ty, 12, 1.3 * s); h.toast(DEF[d.tgt.type].name + ' was knocked out'); d.tgt = null; }
      }
    }
  }
  for (const b of S.b) {
    const g = DEF[b.type].gun; if (!g || b.state !== 'active') continue;
    const s = DEF[b.type].size, cx = b.gx + s / 2, cy = b.gy + s / 2, range = g.range * (1 + .12 * (b.lvl - 1)) * (g.missile && tech(S, 'smart') ? 1.15 : 1);
    let best: Drone | null = null, bd = 1e9;
    for (const d of drones) { const dd = Math.hypot(d.x - cx, d.y - cy); if (dd < range && dd < bd) { bd = dd; best = d; } }
    b.cd -= dt; if (!best) continue;
    b.ang = Math.atan2(best.y - cy, best.x - cx);
    if (b.cd <= 0) {
      b.cd = g.cd * (tech(S, 'pdg') ? .75 : 1);
      const dmg = g.dmg * b.lvl * (g.missile ? (tech(S, 'smart') ? 1.35 : 1) : (tech(S, 'pulse') ? 1.3 : 1)) * (b.type === 'railgun' && tech(S, 'hyper') ? 1.5 : 1);
      if (g.missile) {
        const side = (b.salvo = (b.salvo || 0) + 1) % 2 ? -.12 : .12;
        missiles.push({ x: cx + side, y: cy - side, z: 22, tgt: best, lx: best.x, ly: best.y, dmg, t: 0, vz: 60 });
        h.fx({ k: 'flash', x: cx, y: cy, z: 22, t: .12, r: .5 });
      } else {
        best.hp -= dmg; best.flash = 1;
        const z1 = b.type === 'hq' ? 54 : 17;
        h.fx({ k: 'beam', x1: cx, y1: cy, z1, x2: best.x, y2: best.y, z2: droneZ(best), t: .12, c: '#7ff7ff', w: 2.2 });
        h.fx({ k: 'flash', x: cx, y: cy, z: z1, t: .08, r: .35, c: [120, 240, 255] });
        if (best.hp <= 0) killDrone(S, drones, best, h);
      }
    }
  }
  if (drones.length === 0) {
    S.raidOn = false; S.wave++; S.raids++; S.raidT = Math.max(150, 240 - S.wave * 10);
    const rw = Math.round((15 + S.wave * 5) * lootM(S)); S.res.crystal = Math.min(caps(S).crystal, S.res.crystal + rw);
    h.toast('Raid beaten! +' + rw + ' crystals');
  }
}

export function updMissiles(S: State, live: Live, dt: number, h: Hooks, rand: Rand = Math.random) {
  const { drones, missiles } = live;
  for (let i = missiles.length - 1; i >= 0; i--) {
    const m = missiles[i]; m.t += dt;
    if (m.tgt && drones.includes(m.tgt)) { m.lx = m.tgt.x; m.ly = m.tgt.y; m.lz = droneZ(m.tgt); } else m.tgt = null;
    const tz = m.lz || 34; const dx = m.lx - m.x, dy = m.ly - m.y, dist = Math.hypot(dx, dy); const sp = 5.5 * Math.min(1, .4 + m.t * 1.6);
    if (m.t < .25) m.z += m.vz * dt; else m.z += (tz - m.z) * Math.min(1, dt * 5);
    if (dist < .25) {
      missiles.splice(i, 1); h.boom(m.lx, m.ly, m.z, 1.1);
      for (const d of drones.slice()) {
        const dd = Math.hypot(d.x - m.lx, d.y - m.ly);
        if (d === m.tgt || dd < 1.1) { d.hp -= d === m.tgt ? m.dmg : m.dmg * .5; d.flash = 1; if (d.hp <= 0) killDrone(S, drones, d, h); }
      }
      continue;
    }
    m.x += dx / dist * sp * dt; m.y += dy / dist * sp * dt; m.a = Math.atan2(dy, dx);
    if (rand() < dt * 40) h.fx({ k: 'smoke', x: m.x, y: m.y, z: m.z, t: .9, max: .9, r: .06, g: .1, c: [225, 215, 205] });
  }
}
