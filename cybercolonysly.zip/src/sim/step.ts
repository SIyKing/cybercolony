import { tickBank } from './bank';
import { DEF, MAXL, RANKS, RES, RNAME, STORY } from './defs';
import { caps, clamp, hq, keys, maxHp, rates, stats, stormSun, stormy, tech } from './economy';
import { resolveMission } from './campaign';
import { tickContests } from './contest';
import { fmt } from './save';
import { QUESTS } from './quests';
import { startRaid, updMissiles, updRaid } from './raids';
import { tickResearch } from './research';
import type { Cost, Hooks, Live, Rand, State, Tiles } from './types';

export const costText = (c: Cost) => keys(c).map(k => fmt(c[k]!) + ' ' + RNAME[k]).join(' + ');

/** Advances the colony by dt seconds. */
export function step(S: State, tiles: Tiles, live: Live, dt: number, h: Hooks, rand: Rand = Math.random) {
  const calm = !stormy(S);
  S.t += dt;
  if (calm === stormy(S)) h.toast(calm ? `Dust storm! Solar power drops to ${Math.round(stormSun(S) * 100)}% for a minute` : 'The dust storm has passed');
  const st = stats(S);
  const { eP, eU, work, cap, fe, fw, boost, fz } = st;
  Object.assign(S, { eP, eU, work, cap, fe, fw, boost });
  const c = caps(S), rate = rates(S, tiles, st);
  for (const k of RES) S.res[k] = clamp(S.res[k] + rate[k] * dt, 0, c[k]);
  S.rate = rate;

  // colonists
  if (S.res.food > 2 && S.res.water > 2 && S.pop < cap) {
    S.grow += dt;
    if (S.grow > Math.max(1.5, 4 - S.pop / 40) / (1 + Math.min(1, .08 * fz))) { S.grow = 0; S.pop++; }
  } else S.grow = 0;
  if (S.res.food <= 0 || S.res.water <= 0) {
    S.starve += dt;
    if (S.starve > 8 && S.pop > 2) { S.starve = 0; S.pop--; h.toast(S.res.food <= 0 ? 'A colonist left: no food' : 'A colonist left: no water'); }
  } else S.starve = 0;
  if (S.pop > cap + 2 && cap > 0) S.pop = Math.max(cap, 2);

  // construction
  for (const b of S.b) {
    const d = DEF[b.type];
    if (b.state === 'building' || b.state === 'repair') {
      b.prog += dt / (b.state === 'repair' ? 3 : d.time * (tech(S, 'nano') ? .75 : 1));
      if (rand() < dt * 4) h.weld(b);
      if (b.prog >= 1) {
        b.prog = 1; const wasRep = b.state === 'repair'; b.state = 'active'; b.hp = maxHp(S, b);
        h.floater(b, wasRep ? 'Repaired' : 'Built!', 1.0); h.sparkle(b); h.toast(d.name + (wasRep ? ' repaired' : ' is ready'));
      }
    }
    if (b.upg > 0) {
      if (rand() < dt * 3) h.weld(b);
      b.upg -= dt;
      if (b.upg <= 0) {
        b.upg = 0; b.lvl++; b.hp = maxHp(S, b); h.sparkle(b);
        h.floater(b, b.type === 'hq' ? 'Colony level ' + b.lvl : 'Level ' + b.lvl, 2);
        if (b.type === 'hq') h.toast(RANKS[b.lvl - 1] + '! ' + (STORY[b.lvl] || 'New land, new buildings and level ' + Math.min(MAXL, b.lvl + 1) + ' upgrades unlocked'));
      }
    }
    if (b.state === 'active' && !S.raidOn) b.hp = Math.min(maxHp(S, b), b.hp + 3 * dt);
  }

  // quests
  const q = QUESTS[S.quest];
  if (q && q.ok(S)) {
    for (const k of keys(q.r)) S.res[k] = Math.min(c[k] + q.r[k]!, S.res[k] + q.r[k]!);
    h.toast('Goal done: ' + q.t + ' · +' + costText(q.r) + (q.story ? '. ' + q.story : '')); S.quest++;
    h.floater(hq(S)!, '+' + costText(q.r), 2);
  }

  // raids
  if (!S.raidOn) { if (S.b.length >= 5) S.raidT -= dt; if (S.raidT <= 0) startRaid(S, live.drones, h, rand); }
  else updRaid(S, live, dt, h, rand);
  updMissiles(S, live, dt, h, rand);

  // battles
  if (S.cool > 0) S.cool -= dt;
  if (live.mission) { live.mission.t -= dt; if (live.mission.t <= 0) { h.toast(resolveMission(S, live.mission, rand)); live.mission = null; } }
  tickResearch(S, dt, h);
  tickContests(S, live, dt, h);
  tickBank(S, dt);
}
