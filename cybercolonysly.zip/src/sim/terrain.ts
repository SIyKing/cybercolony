import { N, N0, OFF } from './defs';
import { rng } from './economy';
import type { Tiles } from './types';

/** The map is generated from the seed, so saves only store the seed and the cleared tiles. */
export function genTerrain(seed: number): Tiles {
  const inner = genInner(seed), r = rng(seed ^ 0x1f83d9ab); const tiles: Tiles = [];
  const old = (x: number, y: number) => x >= OFF && y >= OFF && x < OFF + N0 && y < OFF + N0;
  for (let x = 0; x < N; x++) { tiles[x] = []; for (let y = 0; y < N; y++) tiles[x][y] = old(x, y) ? inner[x - OFF][y - OFF] : { t: 'dust', sh: r(), plant: 0 }; }
  for (let k = 0; k < 9; k++) {
    const cx = r() * N, cy = r() * N, rad = 1.3 + r() * 1.4;
    for (let x = 0; x < N; x++) for (let y = 0; y < N; y++) if (!old(x, y) && Math.hypot(x + .5 - cx, y + .5 - cy) < rad) tiles[x][y].t = 'rock';
  }
  let c = 0, g = 0;
  while (c < 12 && g++ < 800) { const x = Math.floor(r() * N), y = Math.floor(r() * N); if (!old(x, y) && tiles[x][y].t !== 'crystal') { tiles[x][y].t = 'crystal'; c++; } }
  for (let x = 0; x < N; x++) for (let y = 0; y < N; y++) if (!old(x, y) && tiles[x][y].t === 'dust' && r() < .12) tiles[x][y].plant = 1 + Math.floor(r() * 2);
  return tiles;
}

/** the original 16x16 map: unchanged, so old colonies keep their ground */
function genInner(seed: number): Tiles {
  const r = rng(seed); const tiles: Tiles = [];
  for (let x = 0; x < N0; x++) { tiles[x] = []; for (let y = 0; y < N0; y++) tiles[x][y] = { t: 'dust', sh: r(), plant: 0 }; }
  const far = (x: number, y: number, d: number) => Math.hypot(x - 7.5, y - 7.5) > d;
  for (let k = 0; k < 5; k++) {
    const cx = r() * N0, cy = r() * N0, rad = 1.3 + r() * 1.4;
    for (let x = 0; x < N0; x++) for (let y = 0; y < N0; y++) if (Math.hypot(x + .5 - cx, y + .5 - cy) < rad && far(x, y, 2.6)) tiles[x][y].t = 'rock';
  }
  let c = 0, g = 0;
  while (c < 7 && g++ < 500) { const x = Math.floor(r() * N0), y = Math.floor(r() * N0); if (far(x, y, 3) && tiles[x][y].t !== 'crystal') { tiles[x][y].t = 'crystal'; c++; } }
  for (let x = 0; x < N0; x++) for (let y = 0; y < N0; y++) { const t = tiles[x][y]; if (t.t === 'dust' && far(x, y, 2.8) && r() < .12) t.plant = 1 + Math.floor(r() * 2); }
  // make sure the starting land holds two crystal deposits and more appear further out
  const r2 = rng(seed ^ 0x2c1b3c6d); const inner = (x: number, y: number) => x >= 4 && x < 12 && y >= 4 && y < 12;
  let ci = 0; for (let x = 4; x < 12; x++) for (let y = 4; y < 12; y++) if (tiles[x][y].t === 'crystal') ci++;
  g = 0;
  while (ci < 2 && g++ < 400) { const x = 4 + Math.floor(r2() * 8), y = 4 + Math.floor(r2() * 8); if (far(x, y, 2.4) && tiles[x][y].t === 'dust') { tiles[x][y].t = 'crystal'; tiles[x][y].plant = 0; ci++; } }
  g = 0; let co = 0;
  while (co < 5 && g++ < 400) { const x = Math.floor(r2() * N0), y = Math.floor(r2() * N0); if (!inner(x, y) && tiles[x][y].t === 'dust') { tiles[x][y].t = 'crystal'; tiles[x][y].plant = 0; co++; } }
  return tiles;
}
