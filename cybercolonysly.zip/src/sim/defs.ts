import type { BuildingDef, BuildingType, ResKey, Tech, Wallet } from './types';

/** map size in tiles */
export const N = 26;
/** the original map's size, and where it sits inside the bigger one */
export const N0 = 16;
export const OFF = (N - N0) / 2;
export const MAXL = 20;
export const TAU = Math.PI * 2;

export const DEF: Record<BuildingType, BuildingDef> = {
  hq: { name: 'Command Center', size: 2, cost: {}, time: 0, hp: 400, energy: 6, workers: 0, popCap: 6, prod: { metal: .6 }, gun: { range: 2.6, dmg: 6, cd: 1.1 }, desc: 'The heart of the colony. Each level is a new colony level: more land, higher building levels and new buildings.' },
  habitat: { name: 'Habitat', size: 1, cost: { metal: 40 }, time: 5, hp: 120, energy: -1, workers: 0, popCap: 6, desc: 'Room for 6 colonists per level. Tap one to pick its design.' },
  solar: { name: 'Solar Array', size: 1, cost: { metal: 30 }, time: 4, hp: 80, energy: 5, workers: 0, desc: '+5 power per level.' },
  extractor: { name: 'Ice Extractor', size: 1, cost: { metal: 50 }, time: 6, hp: 120, energy: -2, workers: 1, prod: { water: 1.2 }, desc: 'Melts buried ice into water.' },
  greenhouse: { name: 'Greenhouse', size: 1, cost: { metal: 60 }, time: 7, hp: 100, energy: -2, workers: 2, prod: { food: 1.0 }, use: { water: .3 }, desc: 'Grows food. Uses a little water.' },
  mine: { name: 'Ore Mine', size: 1, cost: { metal: 45 }, time: 6, hp: 150, energy: -2, workers: 2, prod: { metal: 1.0 }, rock: true, desc: 'Digs metal. Double output on dark rock.' },
  drill: { name: 'Crystal Drill', size: 1, cost: { metal: 90 }, time: 9, hp: 120, energy: -3, workers: 2, prod: { crystal: .25 }, needs: 'crystal', desc: 'Must sit on a pink crystal deposit.' },
  fashion: { name: 'Fashion Store', size: 1, cost: { metal: 120, crystal: 15 }, time: 8, hp: 120, energy: -2, workers: 2, prod: { metal: .7 }, reqHQ: 2, desc: 'Sells the latest colony fashion: +0.7 metal per level and colonists move in faster.' },
  storage: { name: 'Depot', size: 1, cost: { metal: 70 }, time: 5, hp: 160, energy: 0, workers: 0, store: 500, desc: '+500 storage for every resource per level.' },
  turret: { name: 'Defense Turret', size: 1, cost: { metal: 60, crystal: 10 }, time: 6, hp: 170, energy: -1, workers: 1, gun: { range: 3.3, dmg: 14, cd: .7 }, desc: 'Fast laser that shoots raider drones in range.' },
  hangar: { name: 'Hangar', size: 2, cost: { metal: 160, crystal: 30 }, time: 10, hp: 240, energy: -2, workers: 3, unique: true, reqHQ: 2, desc: 'Launch attacks on rival outposts. Needed for the campaign.' },
  lab: { name: 'Research Lab', size: 1, cost: { metal: 220, crystal: 40 }, time: 12, hp: 140, energy: -3, workers: 3, unique: true, reqHQ: 3, boost: .06, desc: 'Research new technologies. Also gives +6% output per level.' },
  missile: { name: 'Missile Battery', size: 1, cost: { metal: 180, crystal: 45 }, time: 10, hp: 200, energy: -2, workers: 2, reqHQ: 3, gun: { range: 4.6, dmg: 34, cd: 2.4, missile: true }, desc: 'Long range homing missiles with blast damage.' },
  hacker: { name: 'Hacker Center', size: 1, cost: { metal: 250, crystal: 60 }, time: 12, hp: 130, energy: -4, workers: 3, unique: true, reqHQ: 3, maxL: 8, desc: 'Hacks enemy defences before every battle: rival outposts and campaign sectors lose 5% power per level. Its crew enters hacker contests.' },
  reactor: { name: 'Fusion Reactor', size: 2, cost: { metal: 600, crystal: 120 }, time: 18, hp: 320, energy: 28, workers: 4, use: { water: .25 }, reqHQ: 4, desc: '+28 power per level. Uses water for cooling.' },
  bank: { name: 'Bank', size: 1, cost: { metal: 500, crystal: 100 }, time: 14, hp: 220, energy: -3, workers: 2, unique: true, reqHQ: 4, desc: 'Colonists pay taxes in credits. Trade resources on the market and keep savings safe from raids.' },
  railgun: { name: 'Railgun', size: 1, cost: { metal: 1400, crystal: 300 }, time: 22, hp: 300, energy: -6, workers: 3, reqHQ: 9, gun: { range: 6, dmg: 90, cd: 2.8 }, desc: 'Magnetic cannon that hits drones from far across the colony.' },
  elevator: { name: 'Space Elevator', size: 2, cost: { metal: 3000, crystal: 700 }, time: 30, hp: 500, energy: -10, workers: 6, unique: true, reqHQ: 10, prod: { metal: 2.5, crystal: .6 }, desc: 'A tether to orbit. Ships in metal and crystals from the asteroid belt.' },
  shieldgen: { name: 'Shield Generator', size: 1, cost: { metal: 4000, crystal: 900, credit: 400 }, time: 34, hp: 400, energy: -12, workers: 4, unique: true, reqHQ: 12, maxL: 10, desc: 'Domes the colony in a force field: drones deal 5% less damage per level.' },
  terraform: { name: 'Terraforming Plant', size: 2, cost: { metal: 6000, crystal: 1200, credit: 800 }, time: 38, hp: 500, energy: -16, workers: 6, unique: true, reqHQ: 14, prod: { water: 3, food: 2 }, desc: 'Turns dust into fertile ground: makes food and water, and Greenhouses grow 10% more per level.' },
  spaceport: { name: 'Spaceport', size: 2, cost: { metal: 9000, crystal: 2000, credit: 1200 }, time: 42, hp: 520, energy: -20, workers: 8, unique: true, reqHQ: 16, prod: { metal: 6, crystal: 1.5 }, use: { food: 1 }, desc: 'Trades food with other colonies for metal and crystals.' },
  ring: { name: 'Orbital Ring', size: 2, cost: { metal: 14000, crystal: 3000, credit: 2000 }, time: 46, hp: 600, energy: -28, workers: 8, unique: true, reqHQ: 18, store: 2500, gun: { range: 10, dmg: 160, cd: 3 }, desc: 'A station circling Mars: +2500 storage per level, long range guns and a stronger fleet.' },
  mirror: { name: 'Solar Mirror', size: 2, cost: { metal: 20000, crystal: 4500, credit: 3000 }, time: 50, hp: 650, energy: 120, workers: 6, unique: true, reqHQ: 20, boost: .08, desc: 'Mirrors in orbit focus the sun: +120 power and +8% output per level.' },
};
export const ORDER: BuildingType[] = ['solar', 'habitat', 'extractor', 'greenhouse', 'mine', 'drill', 'storage', 'fashion', 'turret', 'hangar', 'hacker', 'lab', 'missile', 'reactor', 'bank', 'railgun', 'elevator', 'shieldgen', 'terraform', 'spaceport', 'ring', 'mirror'];
export const RES: ResKey[] = ['metal', 'water', 'food', 'crystal'];
export const RNAME: Record<keyof Wallet, string> = { metal: 'metal', water: 'water', food: 'food', crystal: 'crystals', credit: 'credits' };
export const RANKS = ['Landing Site', 'Outpost', 'Settlement', 'Colony', 'Township', 'Frontier City', 'Capital', 'Metropolis', 'Megacity', 'Planetary Capital',
  'Orbital Hub', 'Continental Seat', 'Twin Moons Port', 'Terraformed World', 'Inner Belt Power', 'Blue Horizon', 'Solar Gateway', 'Ring World', 'Sun Harvester', 'Solar Dominion'];
/** what happens as the colony reaches levels 11 to 20 */
export const STORY: Record<number, string> = {
  11: 'Mars is quiet, but the drones still come. Their signal starts in orbit.',
  12: 'The engineers can fold a force field over the whole colony. Build it before the next wave.',
  13: 'Fast lancer drones dive from orbit. Whoever sends them has been watching us.',
  14: 'The first rain in a billion years falls on your greenhouses. Dust can become soil.',
  15: 'Other colonies call you for help. You are no longer just a settlement on the frontier.',
  16: 'Ships ask to land. A spaceport turns your food into metal, crystals and friends.',
  17: 'Siege drones break through the cloud deck. The enemy fleet is close now.',
  18: 'A ring of steel closes around Mars. From up here, you can finally see their fleet.',
  19: 'Admiral Vex hails you from Deimos: surrender the ring, or lose it.',
  20: 'Your mirrors turn the sunlight onto Mars. The colony that landed in the dust now rules the sky.',
};

export const RIV1 = ['Ferrite', 'Crimson', 'Ashen', 'Vela', 'Rustline', 'Cobalt', 'Hollow', 'Scarp', 'Ember', 'Dune', 'Basalt', 'Static'];
export const RIV2 = ['Syndicate', 'Outpost', 'Reach', 'Holdings', 'Camp', 'Works', 'Clan', 'Station'];
export const REGIONS = ['Tharsis Rim', 'Valles Deep', 'Hellas Basin', 'Martian Orbit'];
export const SECTORS = ['Gully Post', 'Red Wells', 'Scarp Camp', 'Ash Flats', 'Dust Gate', 'Iron Mesa', 'Rift Station', 'Warlord Kesh',
  'Canyon Works', 'Echo Ridge', 'Shard Hollow', 'Cinder Fort', 'Deep Relay', 'Basalt Keep', 'Storm Spire', 'Warlord Varn',
  'Crater Yard', 'Frost Pit', 'Rust Citadel', 'Glass Dunes', 'Black Vent', 'Ember Bastion', 'Sky Harbor', 'Overlord Saro',
  'Phobos Gate', 'Stickney Yard', 'Debris Belt', 'Silent Relay', 'Deimos Dock', 'Iron Armada', 'Void Bastion', 'Admiral Vex'];
export const SECT_N = SECTORS.length;
/** the colony's world in sentences, and what freeing the last surface region frees; lore.ts swaps them per world */
export const LORE = { name: 'Mars', home: 'the planet' };
/** how the colony's world plays (#35); worlds.ts sets each world's, lore.ts swaps them in. These are Mars: dust storms dim the solar arrays.
 * solar: sunlight on solar arrays and mirrors; fuel: other power plants; power: power use; build: build and upgrade costs; prod: output per resource; spread: the Bank's market spread */
export const RULES = { solar: 1, fuel: 1, power: 1, build: 1, storms: true, spread: .1, prod: {} as Partial<Record<ResKey, number>> };
export type Rules = typeof RULES;

export const BRANCHES = [{ n: 'Industry', c: '#ffb547' }, { n: 'Life Support', c: '#7dffa8' }, { n: 'Defense', c: '#5ff3ff' }, { n: 'Fleet', c: '#ff6ad5' }];
export const TIER = {
  1: { cost: { metal: 150, crystal: 30 }, time: 40, lab: 1 },
  2: { cost: { metal: 400, crystal: 80 }, time: 90, lab: 2 },
  3: { cost: { metal: 1000, crystal: 200 }, time: 180, lab: 4 },
  4: { cost: { metal: 2500, crystal: 450 }, time: 300, lab: 6 },
  5: { cost: { metal: 6000, crystal: 1000 }, time: 480, lab: 8 },
  6: { cost: { metal: 12000, crystal: 2000 }, time: 720, lab: 11 },
  7: { cost: { metal: 24000, crystal: 4000 }, time: 1000, lab: 14 },
} as const;
export const TECH: Tech[] = [
  { id: 'drills', br: 0, tier: 1, name: 'Deep Core Drills', fx: 'Ore mines dig 25% more metal.' },
  { id: 'reson', br: 0, tier: 2, name: 'Crystal Resonance', fx: 'Crystal drills produce 30% more.' },
  // after 'reson': techState takes the first tier-2 Industry tech as Nano Fabrication's prerequisite. Only on worlds with storms (lore.ts)
  { id: 'panels', br: 0, tier: 2, name: 'Self-Cleaning Panels', fx: 'Dust storms cut solar power to 70% instead of 40%.' },
  { id: 'nano', br: 0, tier: 3, name: 'Nano Fabrication', fx: 'Building and upgrading is 25% faster and 15% cheaper.' },
  { id: 'fusion', br: 0, tier: 4, name: 'Fusion Optimization', fx: 'Every power source gives 25% more power.' },
  { id: 'hydro', br: 1, tier: 1, name: 'Hydroponics', fx: 'Greenhouses grow 30% more food.' },
  { id: 'ice', br: 1, tier: 2, name: 'Ice Cracking', fx: 'Ice extractors melt 30% more water.' },
  { id: 'recycle', br: 1, tier: 3, name: 'Closed-Loop Recycling', fx: 'Colonists use 40% less food and water.' },
  { id: 'cryo', br: 1, tier: 4, name: 'Cryo Habitats', fx: 'Habitats house 50% more colonists.' },
  { id: 'pulse', br: 2, tier: 1, name: 'Pulse Lasers', fx: 'Turrets and the Command Center deal 30% more damage.' },
  { id: 'smart', br: 2, tier: 2, name: 'Smart Missiles', fx: 'Missiles deal 35% more damage and reach 15% further.' },
  { id: 'alloy', br: 2, tier: 3, name: 'Reinforced Alloys', fx: 'Buildings get 40% more health. Repairs cost half.' },
  { id: 'pdg', br: 2, tier: 4, name: 'Point Defense Grid', fx: 'All defenses fire 25% faster.' },
  { id: 'ion', br: 3, tier: 1, name: 'Ion Engines', fx: 'The fleet is ready again 40% sooner.' },
  { id: 'tact', br: 3, tier: 2, name: 'Tactical AI', fx: 'Fleet power +20%.' },
  { id: 'salvage', br: 3, tier: 3, name: 'Salvage Drones', fx: '40% more loot from battles and raids.' },
  { id: 'quantum', br: 3, tier: 4, name: 'Quantum Storage', fx: 'Storage for every resource +50%.' },
  { id: 'auto', br: 0, tier: 5, name: 'Autonomous Foundries', fx: 'Every production building makes 20% more.' },
  { id: 'terra', br: 1, tier: 5, name: 'Atmosphere Seeding', fx: 'Colonists use another 25% less food and water.' },
  { id: 'shield', br: 2, tier: 5, name: 'Plasma Shields', fx: 'Buildings get 30% more health.' },
  { id: 'warp', br: 3, tier: 5, name: 'Warp Drive', fx: 'Fleet power +25%.' },
  { id: 'belt', br: 0, tier: 6, name: 'Asteroid Mining', fx: 'The Space Elevator and Spaceport bring in 50% more.' },
  { id: 'forge', br: 0, tier: 7, name: 'Matter Forges', fx: 'Building and upgrading is another 15% cheaper.' },
  { id: 'gene', br: 1, tier: 6, name: 'Gene Crops', fx: 'Greenhouses grow 50% more food.' },
  { id: 'bio', br: 1, tier: 7, name: 'Open Biosphere', fx: 'Habitats house another 30% more colonists.' },
  { id: 'hyper', br: 2, tier: 6, name: 'Hypervelocity Rounds', fx: 'Railguns deal 50% more damage.' },
  { id: 'aegis', br: 2, tier: 7, name: 'Aegis Lattice', fx: 'Drones deal another 15% less damage.' },
  { id: 'carrier', br: 3, tier: 6, name: 'Carrier Wings', fx: 'Fleet power +30%.' },
  { id: 'sing', br: 3, tier: 7, name: 'Singularity Core', fx: 'Fleet power +40%.' },
];
