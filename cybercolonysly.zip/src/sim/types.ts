export type ResKey = 'metal' | 'water' | 'food' | 'crystal';
export type Resources = Record<ResKey, number>;
/** what a colony holds: the stored resources, plus credits, which have no storage limit */
export type Wallet = Resources & { credit: number };
export type Cost = Partial<Wallet>;
/** resources that can be handed out as rewards; these respect storage */
export type Goods = Partial<Resources>;

export type BuildingType =
  | 'hq' | 'habitat' | 'solar' | 'extractor' | 'greenhouse' | 'mine' | 'drill'
  | 'fashion' | 'storage' | 'turret' | 'hangar' | 'lab' | 'missile' | 'reactor' | 'railgun' | 'elevator' | 'hacker'
  | 'bank' | 'shieldgen' | 'terraform' | 'spaceport' | 'ring' | 'mirror';

export interface Gun { range: number; dmg: number; cd: number; missile?: boolean }

export interface BuildingDef {
  name: string;
  size: 1 | 2;
  cost: Cost;
  time: number;
  hp: number;
  energy: number;
  workers: number;
  popCap?: number;
  prod?: Goods;
  use?: Goods;
  gun?: Gun;
  store?: number;
  boost?: number;
  rock?: boolean;
  needs?: 'crystal';
  unique?: boolean;
  reqHQ?: number;
  /** highest useful building level, when it stops short of MAXL */
  maxL?: number;
  desc: string;
}

export type BuildingState = 'active' | 'building' | 'repair' | 'damaged';

export interface Building {
  id: number;
  type: BuildingType;
  gx: number;
  gy: number;
  lvl: number;
  state: BuildingState;
  prog: number;
  hp: number;
  /** seconds left on a running upgrade; 0 = none */
  upg: number;
  cd: number;
  ang: number;
  style?: string;
  salvo?: number;
}

export type TileKind = 'dust' | 'rock' | 'crystal';
export interface Tile { t: TileKind; sh: number; plant: number }
export type Tiles = Tile[][];

export interface Rival { name: string; power: number; loot: Goods }
export interface Sector extends Rival { i: number; region: string; boss: boolean }

export interface ResearchJob { id: string; left: number; total: number }

export interface Tech { id: string; br: number; tier: 1 | 2 | 3 | 4 | 5 | 6 | 7; name: string; fx: string }

export interface ContestResult { rival: string; score: number; rivalScore: number; win: boolean }
/** Hacker Center contests: everything that outlives a single contest. */
export interface Contests {
  /** seconds until the next contest */
  cool: number;
  /** contests played; also picks the next rival */
  n: number;
  wins: number;
  /** a won contest takes 10% off the enemy in the next fight */
  hacked: boolean;
  last: ContestResult | null;
  /** best scores, highest first */
  board: ContestResult[];
}
/** A contest being played. Not saved: the fee and cooldown are, so reloading forfeits it. */
export interface Contest {
  rival: string;
  rivalScore: number;
  reward: Goods;
  code: number[];
  tries: { code: number[]; exact: number; near: number }[];
  left: number;
  time: number;
}

/** The save game. Field names match the original `dustfall-colony-v1` JSON exactly, so old saves load. */
export interface State {
  /** 1: the 16x16 map; 2: the 26x26 map (see parseSave) */
  v: 2;
  seed: number;
  res: Wallet;
  pop: number;
  b: Building[];
  nid: number;
  quest: number;
  /** story dialogues played so far */
  beat: number;
  wave: number;
  raidT: number;
  raidOn: boolean;
  wins: number;
  raids: number;
  /** fleet cooldown in seconds */
  cool: number;
  rivals: Rival[];
  /** tiles cleared of plants, as x*N+y */
  cleared: number[];
  grow: number;
  starve: number;
  t: number;
  stage: number;
  tech: Record<string, 1>;
  rs: ResearchJob | null;
  contests: Contests;
  /** credits deposited in the Bank; the wallet is res.credit */
  bank: { saved: number };
  /** avatar; owned by the UI layer */
  av: unknown;
  saved: number;
  rate: Resources;
  // derived each tick by step(); persisted only because the whole object is saved
  eP?: number;
  eU?: number;
  work?: number;
  cap?: number;
  fe?: number;
  fw?: number;
  boost?: number;
}

export type DroneKind = 'scout' | 'heavy' | 'boss' | 'lancer' | 'siege';
export interface Drone {
  x: number; y: number; hp: number; max: number; kind: DroneKind; size: number; dmg: number; sp: number;
  tgt: Building | null; cd: number; orb: number; life: number; bob: number; flash: number; ang?: number;
}
export interface Missile {
  x: number; y: number; z: number; tgt: Drone | null; lx: number; ly: number; lz?: number;
  dmg: number; t: number; vz: number; a?: number;
}
export interface Mission { kind: 'camp' | 'sk'; i: number; t: number; x: number; y: number; name: string }

/** Transient objects that live only while the page is open. */
export interface Live { drones: Drone[]; missiles: Missile[]; mission: Mission | null; contest?: Contest | null }

/** A visual effect record; the sim creates them, the renderer interprets them. */
export type Fx = { k: string } & Record<string, unknown>;

/** How the simulation reports side effects without knowing about rendering or the DOM. */
export interface Hooks {
  toast(msg: string): void;
  fx(e: Fx): void;
  boom(x: number, y: number, z: number, scale: number): void;
  shake(v: number): void;
  weld(b: Building): void;
  sparkle(b: Building): void;
  floater(b: Building, txt: string, t: number): void;
  save(): void;
}

export type Rand = () => number;
