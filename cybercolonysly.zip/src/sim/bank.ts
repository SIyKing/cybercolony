import { DEF, RES, RULES } from './defs';
import { canPay, caps, pay, stats, tech } from './economy';
import { labSpeed } from './research';
import type { Building, Cost, ResKey, State } from './types';

/** share of the wallet a drone escapes with; deposits are safe */
const THEFT = .1;
/** savings interest per minute */
export const INTEREST = .01;
const BASE: Record<ResKey, number> = { metal: 1, water: 1, food: 1.5, crystal: 8 };
const PHASE: Record<ResKey, number> = { metal: 0, water: 1.7, food: 3.1, crystal: 4.6 };

export const newBank = () => ({ saved: 0 });
export const bankLvl = (S: State) => S.b.find(b => b.type === 'bank' && b.state === 'active')?.lvl ?? 0;

/** 0 to 1: a third each for colonists being fed, watered and housed */
export const happiness = (S: State) => ((S.res.food > 0 ? 1 : 0) + (S.res.water > 0 ? 1 : 0) + (S.pop <= stats(S).cap ? 1 : 0)) / 3;
/** credits per colonist per minute: 0.5 at level 1 with a happy colony, half that with an unhappy one */
export const taxRate = (lvl: number, happy: number) => lvl ? .5 * (1 + .25 * (lvl - 1)) * (.5 + .5 * happy) : 0;
/** credits the whole colony pays per minute */
export const taxIncome = (S: State) => S.pop * taxRate(bankLvl(S), happiness(S));
export const vaultCap = (lvl: number) => 1000 * lvl;

/** Taxes go to the wallet, interest to the savings, up to the vault's size. Also used for offline progress. */
export function tickBank(S: State, dt: number) {
  const L = bankLvl(S); if (!L) return;
  S.res.credit += taxIncome(S) * dt / 60;
  S.bank.saved = Math.max(S.bank.saved, Math.min(vaultCap(L), S.bank.saved * (1 + INTEREST * dt / 60)));
}

/** the middle price moves up to 30% either way, on a 10 minute and a 3 minute swell; the colony's clock drives it, so there's nothing to save */
const midPrice = (S: State, k: ResKey) => BASE[k] * (1 + .2 * Math.sin(S.t / 97 + PHASE[k]) + .1 * Math.sin(S.t / 31 + 2 * PHASE[k]));
export const sellPrice = (S: State, k: ResKey) => midPrice(S, k) * (1 - RULES.spread);
export const buyPrice = (S: State, k: ResKey) => midPrice(S, k) * (1 + RULES.spread);
/** one market trade: 100 units, or 10 crystals, per Bank level */
export const lotSize = (k: ResKey, lvl: number) => (k === 'crystal' ? 10 : 100) * lvl;

/** Sells up to n units. Returns the credits earned; 0 means no trade. */
export function sell(S: State, k: ResKey, n: number): number {
  n = Math.min(n, Math.floor(S.res[k]));
  if (!bankLvl(S) || n <= 0) return 0;
  const got = Math.floor(n * sellPrice(S, k));
  S.res[k] -= n; S.res.credit += got;
  return got;
}

/** Buys up to n units, as many as the credits and storage allow. Returns the units bought; 0 means no trade. */
export function buy(S: State, k: ResKey, n: number): number {
  const p = buyPrice(S, k);
  n = Math.min(n, Math.floor(caps(S)[k] - S.res[k]), Math.floor(Math.floor(S.res.credit) / p));
  if (!bankLvl(S) || n <= 0) return 0;
  const cost = Math.ceil(n * p); if (cost > S.res.credit) return 0;
  S.res[k] += n; S.res.credit -= cost;
  return n;
}

/** Moves credits to savings, as many as the vault has room for. Returns the amount. */
export function deposit(S: State, n: number): number {
  n = Math.min(n, S.res.credit, vaultCap(bankLvl(S)) - S.bank.saved);
  if (n <= 0) return 0;
  S.res.credit -= n; S.bank.saved += n;
  return n;
}

/** Moves savings back to the wallet. Returns the amount. */
export function withdraw(S: State, n: number): number {
  n = Math.min(n, S.bank.saved);
  if (n <= 0) return 0;
  S.bank.saved -= n; S.res.credit += n;
  return n;
}

/** A drone that gets away takes a share of the wallet, not of the savings. Returns the credits stolen. */
export function stealCredits(S: State): number {
  const lost = Math.floor(S.res.credit * THEFT);
  S.res.credit -= lost;
  return lost;
}

/** what a cost is worth in credits at the market's base prices; the other way to pay for clothes and contest fees */
export const creditPrice = (c: Cost): Cost => ({ credit: Math.ceil(RES.reduce((sum, k) => sum + (c[k] ?? 0) * BASE[k], 0)) });

/** finishing early costs 1 credit per 3 seconds left */
export const rushCost = (seconds: number): Cost => ({ credit: Math.ceil(seconds / 3) });

/** seconds until a building is finished or upgraded; 0 if neither is running */
export const buildLeft = (S: State, b: Building) =>
  b.upg > 0 ? b.upg : b.state === 'building' ? (1 - b.prog) * DEF[b.type].time * (tech(S, 'nano') ? .75 : 1) : 0;

/** Pays to finish a building or upgrade on the next step. Returns false if there's nothing to rush or it can't be paid. */
export function rushBuilding(S: State, b: Building): boolean {
  const left = buildLeft(S, b), c = rushCost(left);
  if (left <= 0 || !canPay(S, c)) return false;
  pay(S, c);
  if (b.upg > 0) b.upg = .001; else b.prog = 1;
  return true;
}

/** seconds until the running research is done; 0 if none is running or the lab is down */
export const researchLeft = (S: State) => { const sp = labSpeed(S); return S.rs && sp > 0 ? S.rs.left / sp : 0; };

/** Pays to finish the running research on the next step. Returns false if there's nothing to rush or it can't be paid. */
export function rushResearch(S: State): boolean {
  const left = researchLeft(S), c = rushCost(left);
  if (left <= 0 || !canPay(S, c)) return false;
  pay(S, c);
  S.rs!.left = 0;
  return true;
}
