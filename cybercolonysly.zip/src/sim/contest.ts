import { creditPrice } from './bank';
import { winChance } from './campaign';
import { RNAME } from './defs';
import { canPay, caps, keys, lootOf, pay } from './economy';
import type { Contest, ContestResult, Contests, Hooks, Live, Rand, Rival, State } from './types';

export const CODE_LEN = 4;
export const SYMBOLS = 6;
export const MAX_TRIES = 8;
/** seconds between contests */
export const CONTEST_EVERY = 300;
const BOARD_SIZE = 5;

const WIN_LINES = [
  'The crew is dancing on the server racks.',
  '"Their firewall was held up with tape," says the night shift.',
  'The crew left a rude message on their main screen.',
];
const LOSE_LINES = [
  'The crew blames the coffee rations.',
  '"Next time," mutters the night shift, already rewriting the script.',
  'The crew is reading the logs in silence.',
];

export const newContests = (): Contests => ({ cool: 0, n: 0, wins: 0, hacked: false, last: null, board: [] });

/** level of the active Hacker Center; 0 means no contests */
export const hackerLvl = (S: State) => S.b.find(b => b.type === 'hacker' && b.state === 'active')?.lvl ?? 0;
/** the rivals take turns */
export const contestRival = (S: State): Rival => S.rivals[S.contests.n % S.rivals.length];
export const contestFee = (r: Rival) => ({ crystal: Math.max(5, Math.round((r.loot.crystal ?? 0) / 2)) });
/** the same fee, paid in credits */
export const contestCreditFee = (r: Rival) => creditPrice(contestFee(r));
/** 4 minutes at level 1, so people have time to think; each level up to 8 adds 15 s */
export const contestTime = (lvl: number) => 225 + 15 * Math.min(lvl, 8);
/** 300 to 550: the stronger the rival is against the colony, the higher it scores */
export const rivalScore = (S: State, r: Rival) => Math.round(300 + 250 * (1 - winChance(S, r.power)));
/** a cracked code scores 400, +50 per try to spare, +1 per second to spare; an uncracked one scores 0.
 *  Played by people (about 30 s a guess, a few wasted guesses), that wins about 4 in 5 contests, 3 in 5 against the strongest rivals */
export const contestScore = (triesLeft: number, secondsLeft: number) => 400 + 50 * triesLeft + Math.ceil(secondsLeft);

/** Pays the fee and starts a contest. Returns null if the colony can't enter. */
export function startContest(S: State, rand: Rand = Math.random, inCredits = false): Contest | null {
  const lvl = hackerLvl(S), r = contestRival(S), fee = inCredits ? contestCreditFee(r) : contestFee(r);
  if (!lvl || S.contests.cool > 0 || !canPay(S, fee)) return null;
  pay(S, fee);
  const time = contestTime(lvl);
  S.contests.cool = CONTEST_EVERY;
  return {
    rival: r.name, rivalScore: rivalScore(S, r), reward: lootOf(S, r.loot),
    code: Array.from({ length: CODE_LEN }, () => Math.floor(rand() * SYMBOLS)), tries: [], left: time, time,
  };
}

/** Mastermind feedback: exact = right symbol in the right place, near = right symbol in the wrong place. */
export function feedback(code: number[], guess: number[]) {
  let exact = 0, hits = 0;
  code.forEach((s, i) => { if (guess[i] === s) exact++; });
  for (let s = 0; s < SYMBOLS; s++) hits += Math.min(code.filter(x => x === s).length, guess.filter(x => x === s).length);
  return { exact, near: hits - exact };
}

function settle(S: State, c: Contest, score: number, h: Hooks) {
  const x = S.contests, win = score > c.rivalScore, result: ContestResult = { rival: c.rival, score, rivalScore: c.rivalScore, win };
  x.last = result; x.n++;
  if (score > 0) x.board = [...x.board, result].sort((a, b) => b.score - a.score).slice(0, BOARD_SIZE);
  if (win) {
    const cap = caps(S), got: string[] = [];
    for (const k of keys(c.reward)) {
      const before = S.res[k]; S.res[k] = Math.min(cap[k], S.res[k] + c.reward[k]!);
      got.push('+' + Math.floor(S.res[k] - before) + ' ' + RNAME[k]);
    }
    x.wins++; x.hacked = true;
    h.toast('Contest won against ' + c.rival + '! ' + got.join(', ') + '. Your next fight is hacked. ' + WIN_LINES[x.n % WIN_LINES.length]);
  } else h.toast('Contest lost to ' + c.rival + '. ' + LOSE_LINES[x.n % LOSE_LINES.length]);
  h.save();
}

/** Plays one guess. Returns true when that ends the contest. */
export function submitGuess(S: State, c: Contest, code: number[], h: Hooks): boolean {
  const fb = feedback(c.code, code);
  c.tries.push({ code, ...fb });
  const triesLeft = MAX_TRIES - c.tries.length;
  if (fb.exact === CODE_LEN) { settle(S, c, contestScore(triesLeft, c.left), h); return true; }
  if (triesLeft === 0) { settle(S, c, 0, h); return true; }
  return false;
}

export function tickContests(S: State, live: Live, dt: number, h: Hooks) {
  if (S.contests.cool > 0) S.contests.cool = Math.max(0, S.contests.cool - dt);
  const c = live.contest; if (!c) return;
  c.left -= dt;
  if (c.left <= 0) { live.contest = null; settle(S, c, 0, h); }
}
