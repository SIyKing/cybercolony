/** The words of each world (#31): rank names, story lines, campaign regions and sectors, and the dialogue.
 * defs.ts and story.ts hold the Mars text; useWorld swaps another world's text into those same tables, once, before the game starts. */
import { DEF, LORE, RANKS, REGIONS, RULES, SECTORS, STORY, TECH } from './defs';
import { BEATS, CAST, type Beat } from './story';
import { WORLDS, type WorldId } from './worlds';

interface Lore {
  /** the name used in sentences, and what the last campaign region frees */
  name: string; home: string;
  /** rank names that differ from Mars, by index */
  ranks: Record<number, string>;
  story: Record<number, string>;
  regions: string[]; sectors: string[];
  beats: Beat[];
}

/** the first 24 sectors of the outer worlds: names that fit any rock without air or dust storms */
const OUTER = ['Landing Ridge', 'Salt Wells', 'Scarp Camp', 'Pale Flats', 'Frost Gate', 'Iron Mesa', 'Rift Station', 'Warlord Kesh',
  'Canyon Works', 'Echo Ridge', 'Shard Hollow', 'Cinder Fort', 'Deep Relay', 'Basalt Keep', 'Ice Spire', 'Warlord Varn',
  'Crater Yard', 'Frost Pit', 'Steel Citadel', 'Glass Plains', 'Black Vent', 'Cold Bastion', 'Sky Harbor', 'Overlord Saro'];

/** the dialogue after landing on the outer worlds: the crew finds out it is not alone */
const outerBeats = (chapter: string, landing: [string, string, string]): Beat[] => [
  { title: 'Touchdown', at: 0, chapter, lines: [['eng', landing[0]], ['cmd', landing[1]], ['eng', landing[2]]] },
  { title: 'The cracked dome', at: 1, lines: [
    ['eng', 'Water is flowing. Now the bad news: the hard landing cracked the greenhouse dome.', 'worried'],
    ['eng', 'We need a new Greenhouse before anyone goes hungry.'],
  ] },
  { title: 'Not alone out here', at: 4, lines: [
    ['tavi', 'Commander, something is on the long-range scope. Small, fast and heading for us.'],
    ['tavi', 'The same drones as back home. Whoever sends them followed us all the way out here.'],
    ['eng', 'Then they get the same welcome. Build a Defense Turret.'],
  ] },
];

/** a world further out: its name, its four regions, the eight orbit sectors and the landing dialogue */
function outer(name: string, regions: string[], orbit: string[], dock: string, chapter: string, landing: [string, string, string]): Lore {
  return {
    name, home: name, ranks: { 12: name + ' Port', 13: 'Domed World' }, regions, sectors: [...OUTER, ...orbit], beats: outerBeats(chapter, landing),
    story: {
      11: name + ' is quiet, but the drones still come. Their signal starts in orbit.',
      13: 'Fast lancer drones dive from orbit. Whoever sends them has been watching us.',
      14: 'Sealed domes hold warm air for the first time. Dust can become soil.',
      17: 'Siege drones drop over the horizon. The enemy fleet is close now.',
      18: 'A ring of steel closes around ' + name + '. From up here, you can finally see their fleet.',
      19: 'Admiral Vex hails you from ' + dock + ': surrender the ring, or lose it.',
      20: 'Your mirrors turn the far, weak sunlight onto ' + name + '. The colony that landed on the ice now rules the sky.',
    },
  };
}

const LORES: Partial<Record<WorldId, Lore>> = {
  moon: {
    name: 'the Moon', home: 'the Moon',
    ranks: { 9: 'Lunar Capital', 10: 'Cislunar Hub', 11: 'Mare Seat', 12: 'Earthrise Port', 13: 'Sealed Crater World', 15: 'Earthlight City' },
    story: {
      11: 'The Moon is quiet, but the drones still come. Their signal starts behind the far side.',
      13: 'Fast lancer drones drop out of lunar orbit. Whoever sends them has been watching us.',
      14: 'Air holds under the first sealed crater dome. Grey dust can become soil.',
      15: 'The Earth stations call you for help. You are no longer just a camp on the frontier.',
      16: 'Ships from Earth ask to land. A spaceport turns your food into metal, crystals and friends.',
      17: 'Siege drones rise over the horizon. The enemy fleet is close now.',
      18: 'A ring of steel closes around the Moon. From up here, you can see Earth and their fleet.',
      19: 'Admiral Rourke hails you from the L1 station: surrender the ring, or lose it.',
      20: 'Your mirrors light the dark polar craters. The colony that landed in the dust now rules the sky between Earth and Moon.',
    },
    regions: ['Shackleton Rim', 'Mare Imbrium', 'Far Side', 'Earth Orbit'],
    sectors: ['Peak of Light', 'Ice Pit', 'Ridge Camp', 'Regolith Flats', 'Shadow Gate', 'Rille Works', 'Polar Relay', 'Director Kade',
      'Copernicus Yard', 'Basalt Sea', 'Lava Tube', 'Kepler Fort', 'Tranquil Relay', 'Plato Keep', 'Apennine Spire', 'Baroness Imre',
      'Tsiolkovsky Pit', 'Silent Dish', 'Moscoviense Works', 'Daedalus Array', 'Apollo Basin', 'Hertz Bastion', 'Farside Harbor', 'Overseer Lune',
      'L1 Gate', 'Gateway Yard', 'Debris Halo', 'Comsat Relay', 'L2 Dock', 'Iron Armada', 'Void Bastion', 'Admiral Rourke'],
    beats: [
      { title: 'Touchdown', at: 0, chapter: 'Chapter 1: Landing', lines: [
        ['eng', 'Commander, we are down by the south pole. The lander will never fly again, and the tanks hold a few days of water.', 'worried'],
        ['ctrl', 'Lander, this is Earth Control. We see you, and we are glad you are alive. The next supply flight is months out.', 'worried'],
        ['chief', 'Mara Lind, Shackleton station. Welcome to the pole, Commander. The craters here never see the sun, and they are full of ice.'],
        ['eng', 'Then give me an Ice Extractor and I will keep this crew alive.'],
      ] },
      { title: 'The cracked dome', at: 1, lines: [
        ['eng', 'Water is flowing. Now the bad news: a boulder rolled into the greenhouse dome when we came down.', 'worried'],
        ['cmd', 'How long will the rations last?'],
        ['eng', 'Not long. We need a new Greenhouse before anyone goes hungry.'],
      ] },
      { title: 'Something on the scope', at: 4, lines: [
        ['tavi', 'Commander, Tavi Rao, comms and anything with a circuit in it. Something is coming over the horizon.'],
        ['tavi', 'Small, fast and low over the craters. Rocks do not fly.', 'worried'],
        ['ctrl', 'Nothing of ours is up there, Commander. Whatever it is, it is not friendly.', 'worried'],
        ['cmd', 'Ines, can you build me a gun?'],
        ['eng', 'A Defense Turret, yes. Build it before they get here.'],
      ] },
      { title: 'No markings', at: 7, lines: [
        ['eng', 'We held. The wrecks are mining drones with guns bolted on, and every logo is scraped off.'],
        ['tavi', 'Their radios point at the far side, where Earth cannot hear a thing. Someone wants this ice for themselves.'],
        ['chief', 'There is only one base over there: a mining company that stopped answering our calls last year.', 'worried'],
        ['cmd', 'Then let us look like a colony that plans to stay.'],
      ] },
      { title: 'A voice from the far side', at: 12, lines: [
        ['tavi', 'I got a drone core talking. Every order it took came from a mining base on the far side.'],
        ['kesh', 'This is Director Kade. That ice belongs to my company, Commander. Pack up, or my drones will do it for you.'],
        ['ctrl', 'Earth Control to all stations: that company has no claim to the pole. But we cannot reach you in time.', 'angry'],
        ['eng', 'Then nobody stops them but us. The landing is over. Now we have to hold the pole.'],
      ] },
    ],
  },
  ceres: outer('Ceres', ['Occator Rim', 'Salt Plains', 'Dark Hemisphere', 'The Belt'],
    ['Belt Gate', 'Vesta Yard', 'Rubble Ring', 'Silent Relay', 'Pallas Dock', 'Iron Armada', 'Void Bastion', 'Admiral Vex'], 'Pallas',
    'Chapter 1: The Belt', ['We are down on Ceres, Commander. Gravity is so low a jump could put you in orbit.',
      'And water?', 'Not a drop on the surface, only salt and metal. Put an Ice Extractor on the bright spots and we will squeeze out what we can.']),
  europa: outer('Europa', ['Conamara Chaos', 'Ice Rafts', 'Thera Macula', 'Jovian Orbit'],
    ['Io Gate', 'Ganymede Yard', 'Radiation Belt', 'Silent Relay', 'Callisto Dock', 'Iron Armada', 'Void Bastion', 'Admiral Vex'], 'Callisto',
    'Chapter 1: The Ice', ['We are down on Europa, Commander. Jupiter fills half the sky, and the cold eats power like nothing else.',
      'And under us?', 'An ocean, under a few kilometres of ice. Give me an Ice Extractor and we will never be thirsty again.']),
  titan: outer('Titan', ['Kraken Shore', 'Shangri-La Dunes', 'Xanadu Highlands', 'Saturn Orbit'],
    ['Rhea Gate', 'Enceladus Yard', 'Ring Debris', 'Silent Relay', 'Iapetus Dock', 'Iron Armada', 'Void Bastion', 'Admiral Vex'], 'Iapetus',
    'Chapter 1: The Haze', ['We are down on Titan, Commander. The sky is orange, the sun is a dim coin, and it rains methane.',
      'Can we use any of that?', 'The methane burns, if we bring our own oxygen. First water: there is ice under the dunes. Build an Ice Extractor.']),
};

/** Swaps the world's rules and words into the shared tables. Mars keeps the text in defs.ts and story.ts. */
export function useWorld(w: WorldId) {
  Object.assign(RULES, WORLDS[w].rules);
  // no storms, nothing to clean: Self-Cleaning Panels leaves the tech tree
  if (!RULES.storms) { const i = TECH.findIndex(T => T.id === 'panels'); if (i >= 0) TECH.splice(i, 1); }
  const L = LORES[w]; if (!L) return;
  for (const [i, r] of Object.entries(L.ranks)) RANKS[+i] = r;
  Object.assign(STORY, L.story);
  REGIONS.splice(0, REGIONS.length, ...L.regions);
  SECTORS.splice(0, SECTORS.length, ...L.sectors);
  BEATS.splice(0, BEATS.length, ...L.beats);
  LORE.name = L.name; LORE.home = L.home;
  CAST.kesh = w === 'moon' ? { ...CAST.kesh, name: 'Director Kade', role: 'Far side mining base', bust: 'kade' } : { ...CAST.kesh, role: L.regions[0] };
  for (const d of Object.values(DEF)) d.desc = d.desc.replace(/\bMars\b/g, L.name);
}
