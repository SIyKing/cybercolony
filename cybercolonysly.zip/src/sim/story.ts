import type { State } from './types';

export type Mood = 'calm' | 'worried' | 'angry';
/** bust: the drawn portrait (ui/cast.ts), none for the commander, who uses the player's avatar; fx: the comm screen, a clean hologram, a glitch as the line starts, or a red flickering signal; mood: the face when a line names none */
export interface Speaker { name: string; role: string; col: string; bust?: string; fx: 'holo' | 'glitch' | 'enemy'; mood?: Mood }

export const CAST: Record<string, Speaker> = {
  cmd: { name: 'You', role: 'Commander', col: '#ffc94a', fx: 'holo' },
  eng: { name: 'Ines Okoro', role: 'Chief engineer', col: '#2fc0b8', bust: 'eng', fx: 'holo' },
  tavi: { name: 'Tavi Rao', role: 'Hacker crew lead', col: '#a98bff', bust: 'tavi', fx: 'glitch' },
  kesh: { name: 'Warlord Kesh', role: 'Tharsis Rim', col: '#ff5a5f', bust: 'kesh', fx: 'enemy', mood: 'angry' },
  /** the Moon's own voices */
  chief: { name: 'Mara Lind', role: 'Station chief, Shackleton', col: '#7fb0ff', bust: 'chief', fx: 'holo' },
  ctrl: { name: 'Dev Okafor', role: 'Earth Control', col: '#ffd2a6', bust: 'ctrl', fx: 'holo' },
};

export interface Beat { title: string; /** plays once S.quest has reached this goal */ at: number; chapter?: string; lines: [speaker: keyof typeof CAST, text: string, mood?: Mood][] }

/** append only and in order of `at`: saves store how many have played */
export const BEATS: Beat[] = [
  { title: 'Touchdown', at: 0, chapter: 'Chapter 1: Landing', lines: [
    ['eng', 'Commander, we are down. The ship will never fly again, and the tanks hold a few days of water.'],
    ['cmd', 'Then we find more. What is under this dust?'],
    ['eng', 'Ice, if the survey was right. Give me an Ice Extractor and I will keep this crew alive.'],
  ] },
  { title: 'The cracked dome', at: 1, lines: [
    ['eng', 'Water is flowing. Now the bad news: the storm on the way down cracked the greenhouse dome.', 'worried'],
    ['cmd', 'How long will the rations last?'],
    ['eng', 'Not long. We need a new Greenhouse before anyone goes hungry.'],
  ] },
  { title: 'Something on the scope', at: 4, lines: [
    ['tavi', 'Commander, Tavi Rao, comms and anything with a circuit in it. Something is on the long-range scope.'],
    ['tavi', 'Small, fast and heading straight for us. Meteors do not change course.', 'worried'],
    ['cmd', 'Ines, can you build me a gun?'],
    ['eng', 'A Defense Turret, yes. Build it before they get here.'],
  ] },
  { title: 'No markings', at: 7, lines: [
    ['eng', 'We held. The wrecks are drones, and they carry no markings at all.'],
    ['tavi', 'They do not fly alone, either. Someone sent them, and someone is listening to see how we did.'],
    ['cmd', 'Then let us look like a colony that plans to stay.'],
  ] },
  { title: 'A signal in the wrecks', at: 12, lines: [
    ['tavi', 'I got a drone core talking. Every order it took came from the Tharsis Rim.'],
    ['kesh', 'Little colony. You have been shooting my property. This rock pays tribute to Kesh, or it burns.'],
    ['cmd', 'Ines, how much of that was a bluff?'],
    ['eng', 'None of it, I think. The landing is over. Now we have to survive the neighbours.', 'worried'],
  ] },
];

/** The dialogue waiting to play, if any. */
export function dueBeat(S: State): Beat | null {
  const b = BEATS[S.beat];
  return b && b.at <= S.quest ? b : null;
}

/** Saves from before the story skip what they have already passed; the log still shows it. */
export const beatsPassed = (quest: number) => BEATS.filter(b => b.at <= quest).length;
