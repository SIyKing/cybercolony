/** Cargo ships between colonies (#41): a frigate carries one load from one world to another in real time */
import { RES } from './defs';
import { caps, clamp } from './economy';
import type { ResKey, State } from './types';
import { saveKey, WORLD_ORDER, type WorldId } from './worlds';

/** shipments in flight belong to no single colony, so they live beside the saves */
export const CARGO_KEY = 'dustfall-cargo';
export interface Shipment { from: WorldId; to: WorldId; res: ResKey; n: number; at: number }
type Get = (key: string) => string | null;
type Set = (key: string, v: string) => void;

/** distance from the Sun in AU; the trip takes 2 minutes plus 2 minutes per AU between the worlds */
const AU: Record<WorldId, number> = { moon: 1, mars: 1.5, ceres: 2.8, europa: 5.2, titan: 9.5 };
export const tripSecs = (a: WorldId, b: WorldId) => Math.round(120 + 120 * Math.abs(AU[a] - AU[b]));

type Port = { type: string; lvl: number; state: string };
/** cargo hold of a colony: 200 per Hangar level, 1000 per Spaceport level, the bigger one counts; 0 = no port */
export function hold(b: Port[]): number {
  let h = 0;
  for (const x of b) if (x.state === 'active') h = Math.max(h, x.type === 'hangar' ? 200 * x.lvl : x.type === 'spaceport' ? 1000 * x.lvl : 0);
  return h;
}

export function inFlight(get: Get): Shipment[] {
  try { const l = JSON.parse(get(CARGO_KEY) || '[]'); return Array.isArray(l) ? l : []; } catch { return []; }
}

/** worlds other than here whose saved colony has a port to land at */
export function ports(here: WorldId, get: Get): WorldId[] {
  return WORLD_ORDER.filter(w => {
    if (w === here) return false;
    try { const s = JSON.parse(get(saveKey(w)) || 'null'); return !!(s && s.b && hold(s.b) > 0); } catch { return false; }
  });
}

/** loads up to a full hold of one resource and sends it; one frigate per colony, so one trip at a time. Returns why not, or null when sent */
export function send(S: State, from: WorldId, to: WorldId, res: ResKey, get: Get, set: Set, now = Date.now()): string | null {
  const h = hold(S.b), l = inFlight(get), n = Math.floor(Math.min(h, S.res[res]));
  if (!h) return 'Build a Hangar or Spaceport first';
  if (l.some(x => x.from === from)) return 'The frigate is already out';
  if (!ports(from, get).includes(to)) return 'That colony has no Hangar or Spaceport';
  if (n < 1) return 'Nothing to load';
  S.res[res] -= n;
  l.push({ from, to, res, n, at: now + tripSecs(from, to) * 1000 });
  set(CARGO_KEY, JSON.stringify(l));
  return null;
}

/** unloads what fits in storage from every shipment for this world that has arrived; the rest waits in the hold. Returns what was unloaded */
export function land(S: State, here: WorldId, get: Get, set: Set, now = Date.now()): Shipment[] {
  const l = inFlight(get), c = caps(S), got: Shipment[] = [];
  for (const x of l) {
    if (x.to !== here || x.at > now || !RES.includes(x.res)) continue;
    const n = Math.floor(Math.min(x.n, c[x.res] - S.res[x.res]));
    if (n < 1) continue;
    S.res[x.res] = clamp(S.res[x.res] + n, 0, c[x.res]); x.n -= n; got.push({ ...x, n });
  }
  if (got.length) set(CARGO_KEY, JSON.stringify(l.filter(x => x.n > 0)));
  return got;
}
