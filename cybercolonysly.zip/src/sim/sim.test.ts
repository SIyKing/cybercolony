import { describe, expect, it } from 'vitest';
import { buildLeft, buy, buyPrice, creditPrice, deposit, happiness, INTEREST, lotSize, researchLeft, rushBuilding, rushCost, rushResearch, sell, sellPrice, stealCredits, taxIncome, taxRate, tickBank, vaultCap, withdraw } from './bank';
import { enemyPower, sector, launch, makeRivals, resolveMission, winChance } from './campaign';
import { CONTEST_EVERY, contestCreditFee, contestFee, contestRival, contestScore, contestTime, feedback, rivalScore, startContest, submitGuess } from './contest';
import { addB, area, bCost, fleetPower, maxLvl, caps, rates, repCost, rng, shieldM, stats, techMul, upCost } from './economy';
import { startRaid, updRaid } from './raids';
import { labSpeed, startResearch, techState, tickResearch } from './research';
import { applyOffline, fmt, newGame, parseSave } from './save';
import { step } from './step';
import { genTerrain } from './terrain';
import { DEF, MAXL, N, N0, OFF, ORDER, RANKS, RES, SECT_N, STORY, TECH, TIER } from './defs';
import { QUESTS } from './quests';
import { BEATS, CAST, dueBeat } from './story';
import type { Hooks, Live, State, Tiles } from './types';

const tech = (id: string) => TECH.find(t => t.id === id)!;
/** genTerrain(42) from before the map grew: tile kind and plant, by column */
const OLD_TERRAIN_42 = 'd0d0d0d0d0d0d0d0d0d0d0d0d0r0r0r0|c0d0d0d0d0d0d0d0d0d0d0d0d0r0r0r0|d0c0d0d0d0d0d0d0d0d0r0r0r0r0r0r0|d0d0d0d0d0d0d0d0d0r0r0r0r0d0r0r0|d0c0d0d0d1d0d0d0d0r0c0r0r0c0d0d0|d0d1d1d0d0d0d0d0d0d1r0r0d0d0d0d0|d0d0d0c0d2d0d0d0d0d0d0d0d0d0d0c0|d0d2d0d0d1d0d0d0d0d0d0d1d0d0d0d0|d0d0d0c0d2d0d0d0d0d0d0d0d0d0d0d0|d0d2d0d0d0d0d0d0d0d0d0r0r0r0r0d0|d0d0d0d0d0d0d0d0d0d0d0r0r0r0r0d0|r0r0d0d0d0d0c0d0d0d1d0r0r0r0r0d0|r0r0r0d0d0d0d0d0c0d0d0d0r0r0d1d0|r0r0r0d0d0d0d0d0d0d0d0d0d0d0d0d0|r0r0d0c0d0d0d2d0d0d0d0d2d2d0d0d0|c0d2d0d0d0d0d0d0d2d2d0d0c0d0d0d0';

function game(seed = 1): { S: State; tiles: Tiles; live: Live; h: Hooks; toasts: string[] } {
  const { S, tiles } = newGame({}, rng(seed));
  const toasts: string[] = [];
  const h: Hooks = {
    toast: m => toasts.push(m), fx() {}, boom() {}, shake() {}, weld() {}, sparkle() {}, floater() {}, save() {},
  };
  return { S, tiles, live: { drones: [], missiles: [], mission: null }, h, toasts };
}

describe('economy', () => {
  it('starts with HQ, solar and habitat, and their power, housing and rates', () => {
    const { S, tiles } = game();
    expect(S.b.map(b => b.type)).toEqual(['hq', 'solar', 'habitat']);
    const st = stats(S);
    expect([st.eP, st.eU, st.cap, st.fe, st.fw]).toEqual([11, 1, 12, 1, 1]);
    const r = rates(S, tiles, st);
    expect(r.metal).toBeCloseTo(.6);
    expect(r.food).toBeCloseTo(-.2); // 4 colonists eat .05/s each
  });

  it('grows storage with depots, colony level and Quantum Storage', () => {
    const { S, tiles } = game();
    expect(caps(S)).toEqual({ metal: 600, water: 600, food: 600, crystal: 250 });
    addB(S, tiles, 'storage', 5, 5, 2, true);
    S.b[0].lvl = 2;
    expect(caps(S)).toEqual({ metal: 2000, water: 2000, food: 2000, crystal: 950 });
    S.tech.quantum = 1;
    expect(caps(S).crystal).toBe(1425);
  });

  it('prices upgrades on a 1.5·L^1.5 curve; Nano Fabrication takes 15% off', () => {
    const { S } = game();
    const [hq, solar] = S.b;
    expect(upCost(S, hq)).toEqual({ metal: 250, crystal: 25 });
    expect(upCost(S, solar)).toEqual({ metal: 45, crystal: 6 });
    S.tech.nano = 1;
    expect(bCost(S, 'solar')).toEqual({ metal: 26 });
  });

  it('doubles mine output on rock', () => {
    const { S, tiles } = game();
    S.pop = 20;
    const m = addB(S, tiles, 'mine', 5, 5, 1, true);
    tiles[5][5].t = 'dust';
    const dust = rates(S, tiles, stats(S)).metal;
    tiles[5][5].t = 'rock';
    expect(rates(S, tiles, stats(S)).metal - dust).toBeCloseTo(1);
    expect(m.state).toBe('active');
  });
});

describe('step', () => {
  it('finishes construction after the build time and then pays the quest reward', () => {
    const { S, tiles, live, h, toasts } = game();
    const b = addB(S, tiles, 'extractor', 5, 5);
    step(S, tiles, live, 3, h);
    expect(b.state).toBe('building');
    const metal = S.res.metal;
    step(S, tiles, live, 3, h);
    expect(b.state).toBe('active');
    step(S, tiles, live, .01, h); // quest check sees the extractor on the next tick
    expect(S.quest).toBe(1);
    expect(S.res.metal).toBeGreaterThan(metal + 59);
    expect(toasts).toContain('Ice Extractor is ready');
  });

  it('clamps resources to storage and never below zero', () => {
    const { S, tiles, live, h } = game();
    S.res.metal = 599;
    S.res.food = .1;
    step(S, tiles, live, 10, h);
    expect(S.res.metal).toBe(600);
    expect(S.res.food).toBe(0);
  });

  it('adds colonists while there is food, water and room', () => {
    const { S, tiles, live, h } = game();
    for (let i = 0; i < 400; i++) step(S, tiles, live, .1, h);
    expect(S.pop).toBe(12);
  });
});

describe('research', () => {
  it('needs a lab, the previous tier and enough lab levels', () => {
    const { S, tiles } = game();
    expect(techState(S, tech('drills'))).toBe('nolab');
    addB(S, tiles, 'lab', 5, 5, 1, true);
    expect(techState(S, tech('drills'))).toBe('ok');
    expect(techState(S, tech('reson'))).toBe('pre');
    S.tech.drills = 1; S.tech.reson = 1;
    expect(techState(S, tech('nano'))).toBe('lvl');
  });

  it('charges the tier cost and completes after the research time', () => {
    const { S, tiles, h, toasts } = game();
    addB(S, tiles, 'lab', 5, 5, 1, true);
    expect(startResearch(S, 'drills')).toBe('cost');
    S.res.crystal = 100;
    expect(startResearch(S, 'drills')).toBe(tech('drills'));
    expect(S.res).toMatchObject({ metal: 70, crystal: 70 });
    expect(labSpeed(S)).toBe(1);
    tickResearch(S, 39, h);
    expect(S.tech.drills).toBeUndefined();
    tickResearch(S, 1, h);
    expect(S.tech.drills).toBe(1);
    expect(toasts[0]).toMatch(/^Research complete: Deep Core Drills/);
  });
  it('gates tier 5 behind lab level 8, colony levels 9 and 10 unlock new buildings', () => {
    const { S, tiles } = game();
    const lab = addB(S, tiles, 'lab', 5, 5, 7, true);
    for (const id of ['drills', 'reson', 'nano', 'fusion']) S.tech[id] = 1;
    expect(techState(S, tech('auto'))).toBe('lvl');
    lab.lvl = 8;
    expect(techState(S, tech('auto'))).toBe('ok');
    S.b[0].lvl = 9;
    expect(maxLvl(S, lab)).toBe(10);
    expect([DEF.railgun.reqHQ, DEF.elevator.reqHQ, RANKS.length]).toEqual([9, 10, MAXL]);
  });
});

describe('campaign', () => {
  it('has 24 sectors in 3 regions with a boss every 8th', () => {
    expect(sector(0)).toMatchObject({ power: 9, loot: { metal: 150, crystal: 15 }, boss: false, region: 'Tharsis Rim' });
    expect(sector(7).boss).toBe(true);
    expect(sector(8).region).toBe('Valles Deep');
  });

  it('needs a hangar; a win conquers the sector, a loss changes nothing', () => {
    const { S, tiles } = game();
    expect(launch(S, null, 'camp', 0)).toBeNull();
    addB(S, tiles, 'hangar', 4, 4, 1, true);
    const m = launch(S, null, 'camp', 0)!;
    expect(S.cool).toBe(60);
    expect(launch(S, m, 'camp', 0)).toBeNull();
    expect(resolveMission(S, m, () => .99)).toBe('Defeat at Gully Post. The fleet limped home.');
    expect(S.stage).toBe(0);
    expect(resolveMission(S, m, () => 0)).toMatch(/^Sector 1 conquered: Gully Post/);
    expect([S.stage, S.wins]).toEqual([1, 1]);
  });

  it('a Hacker Center weakens enemies by 5% per level, at most 40%', () => {
    const { S, tiles } = game();
    const before = winChance(S, 100);
    const h = addB(S, tiles, 'hacker', 4, 4, 3, true);
    expect(enemyPower(S, 100)).toBe(85);
    expect(winChance(S, 100)).toBeGreaterThan(before);
    h.lvl = 12;
    expect(enemyPower(S, 100)).toBe(60);
    h.state = 'damaged';
    expect(enemyPower(S, 100)).toBe(100);
  });

  it('replaces a skirmish rival after every fight', () => {
    const { S } = game();
    makeRivals(S, rng(5));
    const old = S.rivals[1];
    resolveMission(S, { kind: 'sk', i: 1, t: 0, x: 0, y: 0, name: old.name }, rng(9));
    expect(S.rivals[1]).not.toBe(old);
  });
});

describe('levels 11 to 20', () => {
  it('has 20 ranks, and a story and a goal for every new level', () => {
    expect(MAXL).toBe(20);
    expect(RANKS.length).toBe(20);
    expect(new Set(RANKS).size).toBe(20);
    for (let L = 11; L <= 20; L++) {
      expect(STORY[L]).toBeTruthy();
      expect(QUESTS.find(q => q.t === 'Reach colony level ' + L)?.story).toBe(STORY[L]);
    }
  });

  it('keeps the Command Center curve, and every step is payable with depots', () => {
    const { S, tiles } = game();
    for (let x = 0; x < 12; x++) addB(S, tiles, 'storage', x, 0, 3, true);
    for (let L = 10; L < MAXL; L++) {
      S.b[0].lvl = L;
      const c = upCost(S, S.b[0]), cap = caps(S);
      expect(c.metal).toBe(Math.round(250 * Math.pow(L, 1.5)));
      expect(c.metal!).toBeLessThanOrEqual(cap.metal);
      expect(c.crystal!).toBeLessThanOrEqual(cap.crystal);
    }
    expect(fmt(22360)).toBe('22.4k');
    expect(fmt(9999)).toBe('9999');
    expect(fmt(1234567)).toBe('1.2M');
  });

  it('grows the land every level, to the whole map at 20', () => {
    const { S } = game();
    const size = () => { const A = area(S); return A.b - A.a; };
    S.b[0].lvl = 1; expect(area(S)).toEqual({ a: OFF + 4, b: OFF + 12 });
    S.b[0].lvl = 10; expect(size()).toBe(N0);
    for (let L = 11; L <= 20; L++) { const before = size(); S.b[0].lvl = L; expect(size()).toBe(before + 1); }
    expect(area(S)).toEqual({ a: 0, b: N });
  });

  it('unlocks a building at least every 2 levels', () => {
    for (const L of [11, 13, 15, 17, 19]) expect(ORDER.some(k => DEF[k].reqHQ === L || DEF[k].reqHQ === L + 1)).toBe(true);
    expect(ORDER.filter(k => DEF[k].reqHQ! > 10)).toEqual(['shieldgen', 'terraform', 'spaceport', 'ring', 'mirror']);
    const { S, tiles } = game();
    const lab = addB(S, tiles, 'lab', 5, 5, 1, true);
    S.b[0].lvl = 15;
    expect(maxLvl(S, lab)).toBe(16);
    expect(maxLvl(S, addB(S, tiles, 'hacker', 5, 6, 8, true))).toBe(8);
    expect(maxLvl(S, S.b[0])).toBe(20);
  });

  it('new buildings do what they say', () => {
    const { S, tiles } = game();
    S.pop = 200;
    expect(shieldM(S)).toBe(1);
    addB(S, tiles, 'shieldgen', 5, 5, 4, true);
    expect(shieldM(S)).toBeCloseTo(.8);
    S.tech.aegis = 1;
    expect(shieldM(S)).toBeCloseTo(.68);
    addB(S, tiles, 'terraform', 3, 3, 2, true);
    expect(techMul(S, 'greenhouse')).toBeCloseTo(1.2);
    const cap = caps(S).metal;
    const fleet = fleetPower(S);
    addB(S, tiles, 'ring', 1, 1, 1, true);
    expect(caps(S).metal).toBe(cap + 2500);
    expect(fleetPower(S)).toBe(fleet + 25);
    const power = stats(S).eP, boost = stats(S).boost;
    addB(S, tiles, 'mirror', 1, 3, 1, true);
    expect(stats(S).eP - power).toBe(120);
    expect(stats(S).boost - boost).toBeCloseTo(.08);
    const metal = rates(S, tiles, stats(S)).metal, food = rates(S, tiles, stats(S)).food;
    addB(S, tiles, 'spaceport', 3, 1, 1, true);
    expect(rates(S, tiles, stats(S)).metal).toBeGreaterThan(metal);
    expect(rates(S, tiles, stats(S)).food).toBeLessThan(food);
  });

  it('gates research tiers 6 and 7 behind lab levels 11 and 14', () => {
    expect(TECH.length).toBe(29);
    expect(TECH.filter(t => t.tier >= 6).length).toBe(8);
    const { S, tiles } = game();
    const lab = addB(S, tiles, 'lab', 5, 5, 10, true);
    for (const id of ['drills', 'reson', 'nano', 'fusion', 'auto']) S.tech[id] = 1;
    expect(techState(S, tech('belt'))).toBe('lvl');
    expect(techState(S, tech('forge'))).toBe('pre');
    lab.lvl = TIER[6].lab;
    expect(techState(S, tech('belt'))).toBe('ok');
    S.tech.belt = 1;
    expect(techState(S, tech('forge'))).toBe('lvl');
    lab.lvl = TIER[7].lab;
    expect(techState(S, tech('forge'))).toBe('ok');
    const before = bCost(S, 'railgun').metal!;
    S.tech.forge = 1;
    expect(bCost(S, 'railgun').metal).toBe(Math.ceil(1400 * .85 * .85));
    expect(before).toBe(Math.ceil(1400 * .85));
  });

  it('raids bring new drones from levels 13 and 17 and leave lower levels as they were', () => {
    const { S, live, h } = game();
    S.wave = 12;
    const kinds = (L: number) => { S.b[0].lvl = L; live.drones.length = 0; startRaid(S, live.drones, h, rng(1)); return live.drones.map(d => d.kind); };
    const low = kinds(10), hpLow = live.drones[0].hp;
    expect(new Set(low)).toEqual(new Set(['scout', 'heavy']));
    expect(hpLow).toBe(26 + 12 * 9);
    expect(kinds(13)).toContain('lancer');
    expect(kinds(13)).not.toContain('siege');
    expect(kinds(17)).toContain('siege');
    S.b[0].lvl = 20; live.drones.length = 0; startRaid(S, live.drones, h, rng(1));
    expect(live.drones[0].hp).toBe(hpLow * 3.5);
  });

  it('a Shield Generator softens drone hits', () => {
    const hit = (shielded: boolean) => {
      const { S, tiles, live, h } = game();
      if (shielded) addB(S, tiles, 'shieldgen', 0, 0, 10, true);
      const t = S.b[0], hp = t.hp;
      S.raidOn = true;
      live.drones.push({ x: t.gx + 1, y: t.gy + 1, hp: 1e6, max: 1e6, kind: 'scout', size: 1, dmg: 10, sp: 1, tgt: t, cd: 0, orb: 0, life: 80, bob: 0, flash: 0 });
      updRaid(S, live, .01, h);
      return hp - t.hp;
    };
    expect(hit(false)).toBe(10);
    expect(hit(true)).toBe(5);
  });

  it('ends the campaign in a fourth region, against Admiral Vex', () => {
    expect(SECT_N).toBe(32);
    expect(sector(24).region).toBe('Martian Orbit');
    expect(sector(31)).toMatchObject({ name: 'Admiral Vex', boss: true });
    const { S } = game();
    S.stage = 23;
    expect(resolveMission(S, { kind: 'camp', i: 0, t: 0, x: 0, y: 0, name: '' }, () => 0)).toMatch(/^The planet is free!/);
    S.stage = 31;
    expect(resolveMission(S, { kind: 'camp', i: 0, t: 0, x: 0, y: 0, name: '' }, () => 0)).toMatch(/^The sky above Mars is yours!/);
  });

  it('tells the story of a level when its goal is the one being finished', () => {
    const { S, tiles, live, h, toasts } = game();
    S.quest = 32; S.b[0].lvl = 10; S.b[0].upg = .01;
    step(S, tiles, live, .02, h);
    expect(S.b[0].lvl).toBe(11);
    expect(S.quest).toBe(33);
    expect(toasts.at(-1)).toContain(STORY[11]);
  });

  it('adds goals after the old ones, so old saves keep their place', () => {
    expect(QUESTS[31].t).toBe('Research all 20 technologies');
    expect(QUESTS[32].t).toBe('Reach colony level 11');
  });
});

describe('raids', () => {
  it('grows waves and sends a mothership every 5th wave from wave 4', () => {
    const { S, live, h } = game();
    startRaid(S, live.drones, h, rng(1));
    expect(live.drones.map(d => d.kind)).toEqual(['scout', 'scout']);
    live.drones.length = 0; S.wave = 4;
    startRaid(S, live.drones, h, rng(1));
    expect(live.drones.map(d => d.kind)).toEqual(['scout', 'scout', 'heavy', 'scout', 'scout', 'heavy', 'boss']);
  });

  it('pays crystals and schedules the next raid once every drone is gone', () => {
    const { S, live, h, toasts } = game();
    S.raidOn = true;
    updRaid(S, live, .1, h);
    expect(S).toMatchObject({ raidOn: false, wave: 1, raids: 1, raidT: 230 });
    expect(S.res.crystal).toBe(40);
    expect(toasts).toEqual(['Raid beaten! +20 crystals']);
  });

  it('a drone that runs out of time escapes with 10% of the metal', () => {
    const { S, live, h } = game();
    S.raidOn = true;
    startRaid(S, live.drones, h, rng(1));
    for (const d of live.drones) d.life = .05;
    updRaid(S, live, .1, h);
    expect(S.res.metal).toBe(220 - 22 - 19);
  });
});

describe('save', () => {
  it('generates the same map from the same seed', () => {
    expect(genTerrain(42)).toEqual(genTerrain(42));
    const inner = genTerrain(42).slice(OFF + 4, OFF + 12).flatMap(col => col.slice(OFF + 4, OFF + 12)).filter(t => t.t === 'crystal');
    expect(inner.length).toBeGreaterThanOrEqual(2);
  });

  it('round-trips through JSON and fills fields that old saves lack', () => {
    const { S } = game();
    const old = JSON.parse(JSON.stringify(S));
    delete old.stage; delete old.tech; delete old.rs; delete old.av;
    const r = parseSave(JSON.stringify(old), () => ({ hair: 1 }))!;
    expect(r.S).toMatchObject({ stage: 0, tech: {}, rs: null, av: { hair: 1 }, seed: S.seed });
    expect(r.tiles).toEqual(genTerrain(S.seed).map((col, x) => col.map((t, y) => S.cleared.includes(x * N + y) ? { ...t, plant: 0 } : t)));
    expect(parseSave('{broken', () => ({}))).toBeNull();
    expect(parseSave(JSON.stringify({ ...S, v: 3 }), () => ({}))).toBeNull();
    expect(parseSave(null, () => ({}))).toBeNull();
  });

  it('keeps the ground of the old 16x16 map, in the middle of the new one', () => {
    const inner = genTerrain(42).slice(OFF, OFF + N0).map(col => col.slice(OFF, OFF + N0).map(t => t.t[0] + t.plant).join('')).join('|');
    expect(inner).toBe(OLD_TERRAIN_42);
    expect(genTerrain(42).length).toBe(N);
  });

  it('loads a v1 save with every building where it was, and everything else unchanged', () => {
    const v1 = {
      ...game().S, v: 1, quest: 31, stage: 24, wave: 40, res: { metal: 12345, water: 1, food: 2, crystal: 3 }, cleared: [7 * 16 + 7, 15 * 16 + 15],
      b: [{ id: 1, type: 'hq', gx: 7, gy: 7, lvl: 10, state: 'active', prog: 1, hp: 2200, upg: 0, cd: 0, ang: 0 }, { id: 2, type: 'solar', gx: 0, gy: 15, lvl: 3, state: 'active', prog: 1, hp: 160, upg: 0, cd: 0, ang: 0 }],
    };
    const r = parseSave(JSON.stringify(v1), () => ({}))!;
    expect(r.S.v).toBe(2);
    expect(r.S.b.map(b => [b.gx - OFF, b.gy - OFF, b.lvl])).toEqual([[7, 7, 10], [0, 15, 3]]);
    expect(r.S).toMatchObject({ quest: 31, stage: 24, wave: 40, res: v1.res });
    expect(r.S.cleared).toEqual([12 * N + 12, 20 * N + 20]);
    // level 10 still builds exactly the old map
    expect(area(r.S)).toEqual({ a: OFF, b: OFF + N0 });
    // saving and loading again moves nothing
    expect(parseSave(JSON.stringify(r.S), () => ({}))!.S.b[0].gx).toBe(12);
    expect(sector(23).name).toBe('Overlord Saro');
    expect(QUESTS[25].ok(r.S)).toBe(true); // Overlord Saro stays beaten
  });

  it('gives at most 4 hours of offline progress and finishes construction', () => {
    const { S, tiles, h } = game();
    const b = addB(S, tiles, 'solar', 5, 5);
    S.rate.metal = .01;
    S.raidOn = true; S.raidT = 10;
    expect(applyOffline(S, 10 * 3600, h)).toEqual(['+144 metal']);
    expect(S.res.metal).toBeCloseTo(364);
    expect(b.state).toBe('active');
    expect([S.raidOn, S.raidT]).toEqual([false, 90]);
    expect(applyOffline(S, 20, h)).toBeNull();
  });
});

describe('hacker contests', () => {
  function withHacker(lvl = 1) {
    const g = game();
    addB(g.S, g.tiles, 'hacker', 5, 5, lvl, true);
    g.S.res.crystal = 200;
    return g;
  }
  type Started = NonNullable<ReturnType<typeof startContest>>;
  const solve = (g: ReturnType<typeof game>, c: Started) => submitGuess(g.S, c, c.code, g.h);
  const wrong = (c: Started) => c.code.map(s => (s + 1) % 6);

  it('gives Mastermind feedback, counting repeated symbols once', () => {
    expect(feedback([0, 1, 2, 3], [0, 1, 2, 3])).toEqual({ exact: 4, near: 0 });
    expect(feedback([0, 1, 2, 3], [3, 2, 1, 0])).toEqual({ exact: 0, near: 4 });
    expect(feedback([0, 0, 1, 2], [0, 3, 0, 0])).toEqual({ exact: 1, near: 1 });
    expect(feedback([0, 1, 2, 3], [4, 4, 5, 5])).toEqual({ exact: 0, near: 0 });
  });

  it('needs an active Hacker Center, the fee and no cooldown', () => {
    const g = game(); g.S.res.crystal = 200;
    expect(startContest(g.S)).toBeNull();
    const b = addB(g.S, g.tiles, 'hacker', 5, 5);
    expect(startContest(g.S)).toBeNull(); // still under construction
    b.state = 'active';
    const fee = contestFee(contestRival(g.S)).crystal;
    g.S.res.crystal = fee - 1;
    expect(startContest(g.S)).toBeNull();
    g.S.res.crystal = fee + 3;
    const c = startContest(g.S, rng(3))!;
    expect(c.code).toHaveLength(4);
    expect(c.code.every(s => s >= 0 && s < 6)).toBe(true);
    expect(g.S.res.crystal).toBe(3);
    expect(g.S.contests.cool).toBe(CONTEST_EVERY);
    g.S.res.crystal = 200;
    expect(startContest(g.S)).toBeNull();
  });

  it('runs the cooldown in step and while away', () => {
    const g = withHacker();
    g.S.contests.cool = 100;
    step(g.S, g.tiles, g.live, 10, g.h);
    expect(g.S.contests.cool).toBe(90);
    applyOffline(g.S, 60, g.h);
    expect(g.S.contests.cool).toBe(30);
    applyOffline(g.S, 3600, g.h);
    expect(g.S.contests.cool).toBe(0);
  });

  it('gives 4 minutes, and 15 s more per Hacker Center level up to 8', () => {
    expect(contestTime(1)).toBe(240);
    expect(contestTime(8)).toBe(345);
    expect(contestTime(20)).toBe(345);
    expect(contestScore(1, 19.2)).toBe(470);
  });

  it('scores rivals by their power', () => {
    const g = withHacker();
    const r = contestRival(g.S);
    const low = rivalScore(g.S, { ...r, power: 1 }), high = rivalScore(g.S, { ...r, power: 1000 });
    expect(low).toBeLessThan(high);
    expect(low).toBeGreaterThanOrEqual(300);
    expect(high).toBeLessThanOrEqual(550);
  });

  it('pays the reward, arms Hacked and records the win', () => {
    const g = withHacker();
    const first = contestRival(g.S).name, second = g.S.rivals[1].name;
    const c = startContest(g.S, rng(3))!;
    c.rivalScore = 500;
    const metal = g.S.res.metal, crystal = g.S.res.crystal;
    expect(solve(g, c)).toBe(true);
    expect(g.S.res.metal).toBe(metal + c.reward.metal!);
    expect(g.S.res.crystal).toBe(crystal + c.reward.crystal!);
    expect(g.S.contests).toMatchObject({ n: 1, wins: 1, hacked: true, last: { rival: first, win: true } });
    expect(g.S.contests.board).toHaveLength(1);
    expect(g.toasts.at(-1)).toContain('Contest won');
    expect(contestRival(g.S).name).toBe(second);
  });

  it('caps the reward by storage', () => {
    const g = withHacker();
    const c = startContest(g.S, rng(3))!;
    c.rivalScore = 500; c.reward = { metal: 1e6 };
    solve(g, c);
    expect(g.S.res.metal).toBe(caps(g.S).metal);
  });

  it('loses when the score does not beat the rival, and pays nothing', () => {
    const g = withHacker();
    const c = startContest(g.S, rng(3))!;
    c.rivalScore = 9999;
    const metal = g.S.res.metal;
    solve(g, c);
    expect(g.S.res.metal).toBe(metal);
    expect(g.S.contests).toMatchObject({ n: 1, wins: 0, hacked: false, last: { win: false } });
    expect(g.S.contests.board).toHaveLength(1); // a cracked code still makes the leaderboard
  });

  it('ends after eight wrong guesses with no score', () => {
    const g = withHacker();
    const c = startContest(g.S, rng(3))!;
    for (let i = 0; i < 7; i++) expect(submitGuess(g.S, c, wrong(c), g.h)).toBe(false);
    expect(submitGuess(g.S, c, wrong(c), g.h)).toBe(true);
    expect(g.S.contests.last).toMatchObject({ score: 0, win: false });
    expect(g.S.contests.board).toEqual([]);
  });

  it('can be won by a player who thinks: about 30 s a guess, and every guess fits the clues so far', () => {
    const all = Array.from({ length: 6 ** 4 }, (_, i) => [0, 1, 2, 3].map(j => Math.floor(i / 6 ** j) % 6));
    const same = (a: { exact: number; near: number }, b: { exact: number; near: number }) => a.exact === b.exact && a.near === b.near;
    let wins = 0;
    for (let k = 0; k < 40; k++) {
      const g = withHacker(), c = startContest(g.S, rng(k + 1))!, pick = rng(k + 100);
      c.rivalScore = 425; // a rival as strong as the colony
      let cand = all, done = false;
      while (!done) {
        const guess = c.tries.length ? cand[Math.floor(pick() * cand.length)] : [0, 0, 1, 1];
        c.left -= 30; done = submitGuess(g.S, c, guess, g.h);
        const t = c.tries.at(-1)!; cand = cand.filter(x => same(feedback(x, guess), t));
      }
      if (g.S.contests.wins) wins++;
    }
    expect(wins).toBeGreaterThanOrEqual(36);
  });

  it('ends when the clock runs out', () => {
    const g = withHacker();
    g.live.contest = startContest(g.S, rng(3));
    step(g.S, g.tiles, g.live, 1, g.h);
    expect(g.live.contest!.left).toBeCloseTo(239);
    step(g.S, g.tiles, g.live, 240, g.h);
    expect(g.live.contest).toBeNull();
    expect(g.S.contests.last).toMatchObject({ score: 0, win: false });
  });

  it('keeps the five best scores, highest first', () => {
    const g = withHacker();
    for (let i = 0; i < 7; i++) {
      g.S.contests.cool = 0; g.S.res.crystal = 200;
      const c = startContest(g.S, rng(i + 1))!;
      c.left = 10 * i + 1;
      solve(g, c);
    }
    const scores = g.S.contests.board.map(r => r.score);
    expect(scores).toHaveLength(5);
    expect(scores).toEqual([...scores].sort((a, b) => b - a));
    expect(scores[0]).toBe(contestScore(7, 61));
  });

  it('Hacked takes 10% off the next fight only', () => {
    const g = withHacker();
    g.S.b = g.S.b.filter(b => b.type !== 'hacker'); // no Hacker Center discount, to see the effect alone
    addB(g.S, g.tiles, 'hangar', 5, 5, 1, true);
    expect(enemyPower(g.S, 100)).toBe(100);
    g.S.contests.hacked = true;
    expect(enemyPower(g.S, 100)).toBe(90);
    const m = launch(g.S, null, 'sk', 0)!;
    expect(g.S.contests.hacked).toBe(true); // holds while the fleet is in flight
    resolveMission(g.S, m, rng(1));
    expect(g.S.contests.hacked).toBe(false);
    expect(enemyPower(g.S, 100)).toBe(100);
  });

  it('saves results, and old saves load without any', () => {
    const g = withHacker();
    solve(g, startContest(g.S, rng(3))!);
    const back = parseSave(JSON.stringify(g.S), () => ({}))!.S;
    expect(back.contests).toEqual(g.S.contests);
    const { contests: _, ...old } = g.S;
    const loaded = parseSave(JSON.stringify(old), () => ({}))!.S;
    expect(loaded.contests).toEqual({ cool: 0, n: 0, wins: 0, hacked: false, last: null, board: [] });
    expect(enemyPower(loaded, 100)).toBe(95);
  });
});

describe('bank', () => {
  function withBank(lvl = 1) {
    const g = game();
    g.S.b[0].lvl = 4;
    addB(g.S, g.tiles, 'bank', 5, 5, lvl, true);
    return g;
  }

  it('unlocks at colony level 4 as a unique building with no credits at the start', () => {
    expect(DEF.bank).toMatchObject({ unique: true, reqHQ: 4 });
    expect(ORDER).toContain('bank');
    expect(game().S.res.credit).toBe(0);
  });

  it('collects taxes that rise with the Bank level and happiness', () => {
    expect(taxRate(0, 1)).toBe(0);
    expect(taxRate(1, 1)).toBeCloseTo(.5);
    expect(taxRate(5, 1)).toBeCloseTo(1);
    expect(taxRate(1, 0)).toBeCloseTo(.25);
    const g = withBank(), { S } = g;
    S.pop = 10; S.res.food = 100; S.res.water = 100;
    expect(happiness(S)).toBe(1);
    expect(taxIncome(S)).toBeCloseTo(5);
    tickBank(S, 60);
    expect(S.res.credit).toBeCloseTo(5);
    S.res.food = 0; expect(happiness(S)).toBeCloseTo(2 / 3);
    S.res.water = 0; expect(happiness(S)).toBeCloseTo(1 / 3);
    S.pop = stats(S).cap + 1; expect(happiness(S)).toBe(0);
  });

  it('collects nothing unless the Bank is working', () => {
    const g = withBank(), { S } = g;
    S.bank.saved = 100; S.b.find(b => b.type === 'bank')!.state = 'damaged';
    tickBank(S, 600);
    expect([S.res.credit, S.bank.saved]).toEqual([0, 100]);
  });

  it('moves market prices over time, within limits, with buying always dearer than selling', () => {
    const { S } = withBank(); const seen = new Set<string>();
    for (const k of RES) for (S.t = 0; S.t < 3600; S.t += 7) {
      expect(buyPrice(S, k)).toBeGreaterThan(sellPrice(S, k));
      seen.add(k + buyPrice(S, k).toFixed(3));
    }
    expect(seen.size).toBeGreaterThan(100);
    S.t = 0; const a = sellPrice(S, 'metal'); S.t = 100;
    expect(sellPrice(S, 'metal')).not.toBeCloseTo(a);
  });

  it('pays when selling high and buying low, but a same-moment round trip always loses', () => {
    const { S } = withBank(); S.res.metal = 500; S.res.credit = 1000;
    let lo = 0, hi = 0;
    for (let t = 0; t < 3600; t++) { S.t = t; if (buyPrice(S, 'metal') < buyPrice({ ...S, t: lo } as State, 'metal')) lo = t; if (sellPrice(S, 'metal') > sellPrice({ ...S, t: hi } as State, 'metal')) hi = t; }
    S.t = hi; const earned = sell(S, 'metal', 100);
    S.t = lo; const c0 = S.res.credit; buy(S, 'metal', 100);
    expect(earned).toBeGreaterThan(c0 - S.res.credit);
    const before = S.res.credit; sell(S, 'metal', 100); buy(S, 'metal', 100);
    expect(S.res.credit).toBeLessThan(before);
    expect(S.res.metal).toBe(500);
  });

  it('limits trades to stock, storage and credits, and never overdraws', () => {
    const g = game(); g.S.res.metal = 100; g.S.res.credit = 1000;
    expect(sell(g.S, 'metal', 100)).toBe(0); // no Bank
    expect(buy(g.S, 'metal', 100)).toBe(0);
    const { S } = withBank(); S.res.metal = 30;
    expect(sell(S, 'metal', 100)).toBeGreaterThan(0);
    expect(S.res.metal).toBe(0);
    expect(sell(S, 'metal', 100)).toBe(0);
    S.res.credit = 1000; S.res.metal = caps(S).metal - 5;
    expect(buy(S, 'metal', 100)).toBe(5);
    S.res.metal = 0; S.res.credit = 10.5;
    expect(buy(S, 'metal', 100)).toBeGreaterThan(0);
    expect(S.res.credit).toBeGreaterThanOrEqual(0);
    S.res.credit = 0;
    expect(buy(S, 'metal', 100)).toBe(0);
    expect(lotSize('metal', 3)).toBe(300);
    expect(lotSize('crystal', 3)).toBe(30);
  });

  it('pays interest on savings, capped by the Bank level', () => {
    const { S } = withBank(2); S.res.credit = 5000;
    expect(vaultCap(2)).toBe(2000);
    expect(deposit(S, 5000)).toBe(2000);
    expect([S.res.credit, S.bank.saved]).toEqual([3000, 2000]);
    expect(deposit(S, 1)).toBe(0);
    tickBank(S, 600);
    expect(S.bank.saved).toBe(2000);
    expect(withdraw(S, 1500)).toBe(1500);
    S.pop = 0; const w = S.res.credit;
    tickBank(S, 60);
    expect(S.bank.saved).toBeCloseTo(500 * (1 + INTEREST));
    expect(S.res.credit).toBe(w);
    expect(withdraw(S, 1e9)).toBeCloseTo(500 * (1 + INTEREST));
    expect(S.bank.saved).toBe(0);
  });

  it('lets an escaping raid drone steal from the wallet but not the savings', () => {
    const g = withBank(), { S, h, toasts } = g; S.res.credit = 200; S.bank.saved = 500; S.res.metal = 100; S.raidOn = true;
    startRaid(S, g.live.drones, h, rng(1));
    g.live.drones.length = 1; g.live.drones[0].life = 0;
    updRaid(S, g.live, .01, h, rng(1));
    expect(S.res.credit).toBe(180);
    expect(S.bank.saved).toBe(500);
    expect(toasts.join()).toContain('10 metal and 20 credits');
    expect(stealCredits(S)).toBe(18);
  });

  it('adds taxes and interest while offline, with the same 4 hour cap', () => {
    const { S, h } = (() => { const g = withBank(); g.S.pop = 10; g.S.res.food = 100; g.S.res.water = 100; g.S.bank.saved = 100; return g; })();
    const got = applyOffline(S, 3600, h)!;
    expect(S.res.credit).toBeCloseTo(300);
    expect(S.bank.saved).toBeCloseTo(160);
    expect(got).toContain('+300 credits');
    expect(got).toContain('+60 credits interest');
    const b = withBank(); b.S.pop = 10; b.S.res.food = 100; b.S.res.water = 100;
    applyOffline(b.S, 100 * 3600, b.h);
    expect(b.S.res.credit).toBeCloseTo(1200);
  });

  it('runs taxes through the main step', () => {
    const g = withBank(); g.S.pop = 10; g.S.res.food = 100; g.S.res.water = 100;
    step(g.S, g.tiles, g.live, 1, g.h);
    expect(g.S.res.credit).toBeGreaterThan(0);
  });

  it('finishes construction and upgrades early for credits', () => {
    const g = withBank(), { S, tiles, live, h } = g;
    const b = addB(S, tiles, 'solar', 1, 1);
    expect(buildLeft(S, b)).toBe(4);
    expect(rushCost(4)).toEqual({ credit: 2 });
    expect(rushBuilding(S, b)).toBe(false); // no credits
    S.res.credit = 10;
    expect(rushBuilding(S, b)).toBe(true);
    expect(S.res.credit).toBe(8);
    step(S, tiles, live, .01, h);
    expect(b.state).toBe('active');
    expect(rushBuilding(S, b)).toBe(false); // nothing left to rush
    S.res.credit = 100; b.upg = 30;
    expect(rushBuilding(S, b)).toBe(true);
    step(S, tiles, live, .01, h);
    expect(b.lvl).toBe(2);
  });

  it('finishes research early for credits, but not while the lab is down', () => {
    const g = withBank(), { S, tiles, h } = g;
    const lab = addB(S, tiles, 'lab', 1, 1, 1, true);
    S.rs = { id: 'drills', left: 40, total: 40 };
    S.res.credit = 13;
    expect(researchLeft(S)).toBe(40);
    expect(rushResearch(S)).toBe(false);
    S.res.credit = 14; lab.state = 'damaged';
    expect(rushResearch(S)).toBe(false);
    lab.state = 'active';
    expect(rushResearch(S)).toBe(true);
    expect(S.res.credit).toBe(0);
    tickResearch(S, .01, h);
    expect(S.tech.drills).toBe(1);
    expect(rushResearch(S)).toBe(false);
  });

  it('takes contest fees in credits', () => {
    const g = withBank(), { S, tiles } = g;
    addB(S, tiles, 'hacker', 1, 1, 1, true);
    S.res.crystal = 0;
    const fee = contestCreditFee(contestRival(S)).credit!;
    expect(fee).toBe(contestFee(contestRival(S)).crystal * 8);
    S.res.credit = fee - 1;
    expect(startContest(S, rng(1), true)).toBeNull();
    S.res.credit = fee;
    expect(startContest(S, rng(1), true)).not.toBeNull();
    expect(S.res.credit).toBe(0);
  });

  it('prices clothes in credits at the base prices', () => {
    expect(creditPrice({ metal: 220, crystal: 20 })).toEqual({ credit: 380 });
  });

  it('charges credits for the buildings of levels 11 to 20, but not to repair them', () => {
    const { S, tiles } = game();
    for (const k of ORDER.filter(k => DEF[k].reqHQ! > 10)) expect(bCost(S, k).credit).toBeGreaterThan(0);
    expect(bCost(S, 'railgun').credit).toBeUndefined();
    const b = addB(S, tiles, 'shieldgen', 5, 5, 1, true);
    expect(upCost(S, b).credit).toBeGreaterThan(0);
    expect(repCost(S, b).credit).toBeUndefined();
  });

  it('loads old saves with 0 credits and no savings', () => {
    const { S } = game();
    const old = JSON.parse(JSON.stringify(S));
    delete old.res.credit; delete old.bank;
    const loaded = parseSave(JSON.stringify(old), () => ({}))!.S;
    expect(loaded.res.credit).toBe(0);
    expect(loaded.bank).toEqual({ saved: 0 });
    S.res.credit = 7; S.bank.saved = 8;
    const kept = parseSave(JSON.stringify(S), () => ({}))!.S;
    expect([kept.res.credit, kept.bank.saved]).toEqual([7, 8]);
  });
});

describe('story', () => {
  it('plays each dialogue once, in order, when its goal is reached', () => {
    const { S } = game();
    expect(dueBeat(S)).toBe(BEATS[0]);
    S.beat = 1;
    expect(dueBeat(S)).toBeNull();
    S.quest = 1;
    expect(dueBeat(S)).toBe(BEATS[1]);
    S.beat = BEATS.length; S.quest = 999;
    expect(dueBeat(S)).toBeNull();
    for (let i = 1; i < BEATS.length; i++) expect(BEATS[i].at).toBeGreaterThanOrEqual(BEATS[i - 1].at);
    for (const b of BEATS) for (const [k, t] of b.lines) { expect(CAST[k]).toBeDefined(); expect(t).not.toBe(''); }
  });

  it('does not replay dialogues an old save has already passed', () => {
    const { S } = game();
    const old = JSON.parse(JSON.stringify(S));
    delete old.beat; old.quest = 8;
    const loaded = parseSave(JSON.stringify(old), () => ({}))!.S;
    expect(dueBeat(loaded)).toBeNull();
    expect(loaded.beat).toBe(BEATS.filter(b => b.at <= 8).length);
    loaded.quest = 12;
    expect(dueBeat(loaded)?.title).toBe('A signal in the wrecks');
  });

  it('gives every chapter 1 goal a reason', () => {
    const end = BEATS[BEATS.length - 1].at; // the last beat plays once "Reach colony level 3" is done
    expect(QUESTS[end - 1].t).toBe('Reach colony level 3');
    for (const q of QUESTS.slice(0, end)) expect(q.why).toBeTruthy();
  });

  it('flies the goal reward up from the Command Center', () => {
    const { S, tiles, live, h } = game();
    const got: string[] = []; h.floater = (b, txt) => { got.push(b.type + ' ' + txt); };
    S.b.push({ ...S.b[0], id: 99, type: 'extractor', state: 'active' });
    step(S, tiles, live, .01, h);
    expect(S.quest).toBe(1);
    expect(got).toContain('hq +60 metal');
  });
});

describe('worlds', () => {
  it('opens later worlds by the best colony level of any save, and keeps Mars on the old key', async () => {
    const { bestLevel, colonyLevel, isOpen, saveKey } = await import('./worlds');
    const { KEY } = await import('./save');
    expect(saveKey('mars')).toBe(KEY);
    expect(saveKey('moon')).toBe(KEY + '-moon');
    const store: Record<string, string> = { [KEY + '-moon']: JSON.stringify({ b: [{ type: 'hq', lvl: 9 }] }), [KEY]: '{broken' };
    const best = bestLevel(k => store[k] ?? null);
    expect(best).toBe(9);
    expect(colonyLevel(k => store[k] ?? null, 'moon')).toBe(9);
    expect(colonyLevel(k => store[k] ?? null, 'mars')).toBe(0); // broken save: no colony
    expect(colonyLevel(k => store[k] ?? null, 'titan')).toBe(0);
    expect(isOpen('moon', 0)).toBe(true);
    expect(isOpen('ceres', best)).toBe(true);
    expect(isOpen('europa', best)).toBe(false);
  });
});
