import type { Rules } from './defs';
import { KEY } from './save';

export type WorldId = 'moon' | 'mars' | 'ceres' | 'europa' | 'titan';
type RGB = [number, number, number];

export interface World {
  name: string;
  /** one line for the Solar System map */
  blurb: string;
  /** colony level some colony must reach before this world opens; 0 = open from the start */
  unlock: number;
  /** ground colours: dust, dark rock, the haze at the map edge, and the rock sprites' light, mid, dark shades */
  sand: RGB; rock: RGB; haze: RGB; rockC: [string, string, string];
  /** colour of the planet's disc on the map, as CSS */
  disc: string;
  /** has an atmosphere: wind ripples and dunes in the dust; airless worlds get sharp craters instead */
  air: boolean;
  /** how it plays, where it differs from Mars (#35), and that in a few words for the map */
  rules: Partial<Rules>; perk: string;
}

export const WORLDS: Record<WorldId, World> = {
  moon: { name: 'Moon', blurb: 'Grey regolith, three days from Earth. Ice hides in the polar craters.', unlock: 0,
    sand: [170, 170, 176], rock: [92, 92, 100], haze: [16, 18, 28], rockC: ['#b9b9c0', '#76767e', '#34343a'], disc: 'radial-gradient(circle at 35% 30%,#f2f2f4,#9a9aa2 55%,#3c3c44)', air: false,
    rules: { storms: false, prod: { water: 1.3 }, spread: .04 }, perk: 'No storms · +30% water from polar ice · cheap trade with Earth' },
  mars: { name: 'Mars', blurb: 'The red frontier: thin air, dust storms and ice under the sand.', unlock: 0,
    sand: [208, 130, 88], rock: [132, 72, 52], haze: [190, 126, 94], rockC: ['#c9876a', '#94553a', '#4a2618'], disc: 'radial-gradient(circle at 35% 30%,#ffb08a,#c4502a 55%,#5a1a0c)', air: true,
    rules: {}, perk: 'Dust storms cover the solar arrays' },
  ceres: { name: 'Ceres', blurb: 'A dwarf planet in the asteroid belt, rich in metal and salt.', unlock: 8,
    sand: [128, 120, 112], rock: [70, 64, 60], haze: [18, 16, 22], rockC: ['#9a928a', '#5e5852', '#2a2624'], disc: 'radial-gradient(circle at 35% 30%,#c8c0b6,#6e6660 55%,#24201e)', air: false,
    rules: { storms: false, build: .8, prod: { metal: 1.4, water: .5 } }, perk: '+40% metal · low gravity: 20% cheaper building · half the water' },
  europa: { name: 'Europa', blurb: 'An ice moon of Jupiter with an ocean under the crust.', unlock: 12,
    sand: [214, 222, 230], rock: [160, 128, 108], haze: [14, 22, 40], rockC: ['#e6eef6', '#a8b8c8', '#5a6878'], disc: 'radial-gradient(circle at 35% 30%,#ffffff,#c9b8a4 55%,#5a4636)', air: false,
    rules: { storms: false, prod: { water: 1.6 }, power: 1.3 }, perk: '+60% water from the ocean · the cold costs 30% more power' },
  titan: { name: 'Titan', blurb: "Saturn's hazy moon: methane lakes under an orange sky.", unlock: 16,
    sand: [196, 150, 84], rock: [112, 82, 44], haze: [168, 120, 60], rockC: ['#d2a86a', '#8a6230', '#3e2a12'], disc: 'radial-gradient(circle at 35% 30%,#ffd88a,#c88a3a 55%,#5a3a12)', air: true,
    rules: { storms: false, solar: .4, fuel: 1.4 }, perk: 'Dim sun: solar at 40% · methane fuel: reactors +40%' },
};
export const WORLD_ORDER = Object.keys(WORLDS) as WorldId[];

/** which world this device shows; a device's choice, so it lives beside the saves, not in them */
export const WORLD_KEY = 'dustfall-world';
/** Mars keeps the original save key, so existing colonies stay on Mars */
export const saveKey = (w: WorldId) => (w === 'mars' ? KEY : KEY + '-' + w);
export const isWorld = (w: unknown): w is WorldId => typeof w === 'string' && w in WORLDS;

/** the colony level on one world, 0 when there is no colony there; get reads a save by key */
export function colonyLevel(get: (key: string) => string | null, w: WorldId): number {
  try {
    const s = JSON.parse(get(saveKey(w)) || 'null');
    const hq = s && s.b && s.b.find((b: { type: string }) => b.type === 'hq');
    return hq ? hq.lvl : 0;
  } catch { return 0; /* unreadable save: it counts as no colony */ }
}
/** the highest colony level of any saved colony */
export const bestLevel = (get: (key: string) => string | null) => Math.max(0, ...WORLD_ORDER.map(w => colonyLevel(get, w)));
export const isOpen = (w: WorldId, best: number) => best >= WORLDS[w].unlock;
